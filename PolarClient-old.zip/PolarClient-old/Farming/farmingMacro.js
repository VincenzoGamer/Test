let { keyBind } = global.exports
let { LeftClick, Shift, WalkBackward, WalkForward, WalkLeft, WalkRight, polarPrefix, setPitch, setYaw, setting } = global.exports

const configGardenMacro = new global.configModuleClass(
    "Garden Macro",
    "Farming",
    false,
    [
        new global.settingSelector("Farming Crop", 0, [
            "Wheat",
            "NetherWart",
            "Carrot",
            "Potato",
            "Mushroom",
            "Melon",
            "Pumpkin",
            "CocoBeans",
            "Cactus",
            "SugerCane"
        ], false),
        new global.settingSelector("Start Direction", 0, [
            "Right",
            "Left"
        ], false),
        new global.settingToggle("40bps", false)
    ],
    [
        "&bWORK IN PROGRESS",
        "Farms crops for you in the garden"
    ]
)

global.modules.push(configGardenMacro)

class farmingMacroClass {
    constructor() {
        this.configName = "Garden Macro"

        this.toggle = false
        this.toggleFarming = false

        this.blocks = {
            "Wheat": 59,
            "NetherWart": 115,
            "Carrot": 141,
            "Potato": 142,
            "Mushroom": [39,40],
            "Melon": 103,
            "Pumpkin": 86,
            "CocoBeans": 127,
            "Cactus": 81,
            "SugerCane": 83
        }

        keyBind.keyBindFarmingMacro.registerKeyPress(() => {this.toggleMacro()})

        register("tick", () => {
            if(!this.toggle) return
            let crop = this.blocks[global.exports.settingGet.getSetting(this.configName, "Farming Crop")]
        })

        register("command", (x,y) => {
            if(x === undefined || y === undefined) {
                ChatLib.chat(polarPrefix + " Usage /setangle <yaw> <pitch>")
                return
            }
            let yaw = parseFloat(x).toFixed(2)
            let pitch = parseFloat(y).toFixed(2)
            setYaw(yaw)
            setPitch(pitch)
        }).setName("setangle")
    }

    toggleMacroFarming() {
        this.toggleFarming = !this.toggleFarming
        if(this.toggleFarming) {
            ChatLib.chat(polarPrefix + " Started Farming")
        } else {
            ChatLib.chat(polarPrefix + " Stopped Farming")
            this.setWalkState(false, false, false, false)
            LeftClick.setState(false)
        }
    }

    toggleMacro() {
        this.toggle = !this.toggle
        if(this.toggle) {
            ChatLib.chat(polarPrefix + " Farming Macro: " + this.toggle)
        } else {
            ChatLib.chat(polarPrefix + " Farming Macro: " + this.toggle)
        }
    }

    setPitchYaw(ms) {
        new Thread(() => {
            let yaw = parseInt(setting("Farming","Starting Yaw"))
            let pitch = setting("Farming","Starting Pitch")
            let plyYaw = Player.getYaw()
            let plyPitch = Player.getPitch()
            let dPitch = plyPitch - pitch
            let dYaw = plyYaw - yaw
            if(dYaw > 180) {
                dYaw -= 360
            } 
            if(dYaw < -180) {
                dYaw += 360
            }
            for(let i = 0; i < ms; i++) {
                if(!this.toggleFarming) return
                Player.getPlayer()?.field_70177_z -= dYaw/ms
                Player.getPlayer()?.field_70125_A -= dPitch/ms
                Thread.sleep(1)
            }
            if(this.toggleFarming) {
                setYaw(yaw)
                setPitch(pitch)
                this.setWalkState(false, false, true, false)
                Thread.sleep(300)
                this.setWalkState(false, false, false, false)
            }
        }).start()
    }

    setWalkState(left, right, forward, backward) {
        if(left != undefined) {WalkLeft.setState(left)}
        if(right != undefined) {WalkRight.setState(right)}
        if(forward != undefined) {WalkForward.setState(forward)}
        if(backward != undefined) {WalkBackward.setState(backward)}
    }
}

global.exports.farmingMacro = new farmingMacroClass()