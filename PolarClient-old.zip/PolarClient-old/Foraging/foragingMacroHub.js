import RenderLib from "RenderLib";
let { keyBind } = global.exports
let { disToPly, disToPlyFlat, disFrToFrY } = global.exports
let { fillJavaArray } = global.exports
let { lookAt, lookAt2 } = global.exports
let { C07PacketPlayerDigging, C0APacketAnimation, EnumFacing, sendPacket, Shift, WalkForward, WalkJump, mc, Sprint, setting, polarPrefix } = global.exports
let { degreeRannge } = global.exports
let { toBlockPos } = global.exports
let { finder, rotationUtils } = global.exports
import Skyblock from "BloomCore/Skyblock";

const configForagingMacro = new global.configModuleClass(
    "Foraging Macro",
    "Foraging",
    false,
    [
        new global.settingSelector("Foraging mining type",0,[
            "Legit",
            "Nuker",
            "No Rotation"
        ], false),
        new global.settingToggle("Rod Swap (Only Works when Legit mode is Enabled)",false)
    ],
    [
        "&bForaging Macro Hub",
        "Forage in the Hub, Rod Swap makes it use the Rod everytime after it mines"
    ]
)

global.modules.push(configForagingMacro)

var foragingjson = FileLib.read("PolarConfig", "cordsForaging.json");
var foraging = JSON.parse(foragingjson)

let rightClick = mc.getClass().getDeclaredMethod("func_147121_ag")
rightClick.setAccessible(true)

class foragingMacro1 {
    constructor() {
        this.configName = "Foraging Macro"

        this.toggle = false

        this.walking = false

        this.reachedSpot = false

        this.current = 0

        this.cords = []

        this.previous = undefined

        this.whiteList = fillJavaArray([1,1])

        this.useNuker = false

        this.inHub = false

        keyBind.keyBindHubForagingMacro.registerKeyPress(() => {this.toggleMacro()})

        register("step", () => {
            if(this.toggle) {
                if(this.walking) {
                    if(disToPlyFlat(this.walkX + 0.5, this.walkZ + 0.5) < 2 && disFrToFrY(this.walkY, Player.getY()) < 1) {
                        Sprint.setState(false)
                        Shift.setState(true)
                        lookAt(this.walkX, Player.getY() + 1.6, this.walkZ, 1, false, false)
                        if(disToPlyFlat(this.walkX + 0.5, this.walkZ + 0.5) < 1.5) {
                            WalkForward.setState(false)
                            Shift.setState(false)
                            this.reachedSpot = true
                            //this.walking = false
                        }
                    } else {
                        Sprint.setState(true)
                        WalkForward.setState(true)
                        Shift.setState(false)
                    }
                }
            }
        })

        register("step", () => {
            this.shouldRender = global.exports.settingGet.getSetting("Route Rendering","Foraging Macro Route")
        }).setFps(1)

        register("renderWorld", () => {
            if(!this.shouldRender || this.toggle) return
            this.render()
        })

        register("tick", () => {
            if(this.previous != undefined) {
                //sendPacket(new C0APacketAnimation())
                //mc.field_71439_g.func_71038_i()
                sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.previous, EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
                this.previous = undefined
            }

            this.callCords()
            if(this.toggle) {

                if(this.useNuker && Player.getPlayer().field_70122_E) {
                    this.woodNuker()
                }

                if(this.walking) {
                    this.callCords()
                    let found = false
                    for(let x = -2; x < 2; x++) {
                        for(let z = -2; z < 2; z++) {
                            if(World.getBlockAt(this.plyX + x, Player.getY(), this.plyZ + z).type.getID() != 0.0 && World.getBlockAt(this.plyX + x, this.plyY, this.plyZ + z).type.getID() != 31.0 && degreeRannge(this.plyX + x + 0.5, Player.getY() + 0.5, this.plyZ + z + 0.5) < 60 && disToPlyFlat(this.plyX + x + 0.5, this.plyZ + z + 0.5) < 1) {
                                //ChatLib.chat(World.getBlockAt(this.plyX + x, Player.getY(), this.plyZ + z).type.getID())
                                found = true
                            }
                        }
                    }

                    if(found) {
                        WalkJump.setState(true)
                    } else {
                        WalkJump.setState(false)
                    }
                }

                if(this.reachedSpot) {
                    this.current += 1
                    if(this.current === this.cords.length) {
                        this.current = 0
                    }

                    this.walktoCords(this.cords[this.current][0], this.cords[this.current][1],this.cords[this.current][2])
                    this.reachedSpot = false

                }
            }
        })

        register("step", () => {
            this.cords = foraging.HubCords1
            if(Skyblock.area === "Hub") {
                this.inHub = true
            } else {
                this.inHub = false
            }
        }).setFps(1)

        register("step", () => {
            if(this.walking && !this.reachedSpot && this.toggle) {
                rotationUtils.onStopRotation()
                rotationUtils.doPolarRotation({x: this.walkX, y: Player.getY() + 1.6, z: this.walkZ}, 250, false)
            }
        }).setFps(5)
    }

    toggleMacro() {
        this.toggle = !this.toggle


        if(this.toggle) {
            if(this.currentCords() && this.inHub && finder.axe() && (!global.exports.settingGet.getSetting(this.configName,"Rod Swap (Only Works when Legit mode is Enabled)") || finder.rod())) {
                ChatLib.chat("Foraging Macro: " + this.toggle)
                if(global.exports.settingGet.getSetting(this.configName,"Foraging mining type") === "Nuker") {
                    this.useNuker = true
                } else {
                    this.useNuker = false
                }

                this.walking = true
                this.reachedSpot = true

                Player.setHeldItemIndex(finder.slotAxe)

            } else {
                ChatLib.chat(polarPrefix + " Missing:")
                if(!this.inHub) {
                    ChatLib.chat("Not in the Hub")
                }
                if(!this.currentCords()) {
                    ChatLib.chat("Not in range of a waypoint!")
                }

                if(!finder.axe()) {
                    ChatLib.chat("- Axe")
                }

                if(global.exports.settingGet.getSetting(this.configName,"Rod Swap (Only Works when Legit mode is Enabled)") && finder.rod()) {
                    ChatLib.chat("- Rod")
                }

                this.walking = false
                this.reachedSpot = false
                this.toggle = false
            }
        } else {
            ChatLib.chat("Foraging Macro: " + this.toggle)
            this.walking = false
            this.reachedSpot = false
            Shift.setState(false)
            WalkForward.setState(false)
            WalkJump.setState(false)
        }
    }

    walktoCords(x,y,z) {
        let block = this.nukeWood()
        if(block != undefined) {
            if(global.exports.settingGet.getSetting(this.configName,"Foraging mining type") === "Legit") {
                rotationUtils.onStopRotation()
                rotationUtils.doPolarRotation({x: block.getX() + 0.5, y: block.getY() + 0.5, z: block.getZ() + 0.5}, 300, false)
            }
            if(global.exports.settingGet.getSetting(this.configName,"Foraging mining type") != "Nuker") {
                //ChatLib.chat("START")
                sendPacket(new C0APacketAnimation())
                mc.field_71439_g.func_71038_i()
                sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, toBlockPos(block), EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
                this.previous = toBlockPos(block)
            }
        }

        this.walkX = x
        this.walkY = y
        this.walkZ = z
        if(global.exports.settingGet.getSetting(this.configName,"Foraging mining type") === "Legit") {
            this.reachedSpot = false
            this.walking = false
            new Thread(() => {
                Thread.sleep(200)
                this.walking = true
                lookAt2(x,Player.getY() + 1.6, z, 150, false, false)
            }).start()
        } else {
            this.walking = true
        }

        if(global.exports.settingGet.getSetting(this.configName,"Rod Swap (Only Works when Legit mode is Enabled)") && global.exports.settingGet.getSetting(this.configName,"Foraging mining type") === "Legit") {
            //ChatLib.chat("here")
            new Thread(() => {
                Thread.sleep(100)
                if(!this.toggle) return
                Player.setHeldItemIndex(finder.slotRod)
                Thread.sleep(200)
                if(!this.toggle) return
                rightClick.invoke(mc)
                Thread.sleep(100)
                if(!this.toggle) return
                Player.setHeldItemIndex(finder.slotAxe)
            }).start()
        } else {
            Player.setHeldItemIndex(finder.slotAxe)
        }

    }

    currentCords() {
        for(let i = 0; i < this.cords.length; i++) {
            if(disToPly(this.cords[i][0], this.cords[i][1], this.cords[i][2]) < 10) {
                this.current = i
                return true
            }
        }
        return false
    }

    render() {
        if(this.inHub) {
            for(let i = 0; i < this.cords.length; i++) {
                Tessellator.drawString(i + 1,this.cords[i][0], this.cords[i][1] + 1, this.cords[i][2])
                RenderLib.drawEspBox(this.cords[i][0], this.cords[i][1], this.cords[i][2], 1, 0.1, 0, 1, 0, 1, true)
            }
        }
    }

    callCords() {
        this.plyX = Math.floor(Player.getX())
        this.plyY = Player.getY()
        this.plyZ = Math.floor(Player.getZ())
    }

    nukeWood() {
        this.callCords()
        for(let x = -6; x < 6; x++) {
            for(let z = -6; z < 6; z++) {
                for(let y = 1; y > -1; y--) {
                    if(World.getBlockAt(this.plyX + x, this.plyY + y, this.plyZ + z).type.getID() === 17.0 && disToPly(this.plyX + x + 0.5, this.plyY + y + 0.5 , this.plyZ + z + 0.5) < 4.5) {
                        return World.getBlockAt(this.plyX + x, this.plyY + y, this.plyZ + z)
                    }
                }
            }
        }
        return undefined
    }

    woodNuker() {
        this.callCords()
        let closest = undefined
        let blocks = []
        for(let x = -6; x < 6; x++) {
            for(let z = -6; z < 6; z++) {
                for(let y = -1; y < 6; y++) {
                    let block = World.getBlockAt(this.plyX + x, this.plyY + y, this.plyZ + z)
                    if(block.type.getID() === 17.0 && !this.whiteList.contains(toBlockPos(block)) && disToPly(this.plyX + x + 0.5, this.plyY + y + 0.5 , this.plyZ + z + 0.5) < 4.5) {
                        blocks.push(block)
                    }
                }
            }
        }

        for(let i = 0; i < blocks.length; i++) {
            if(closest === undefined) {
                closest = blocks[i]
            } else if(disToPly(closest.getX(), closest.getY(), closest.getZ()) > disToPly(blocks[i].getX(), blocks[i].getY(), blocks[i].getZ())) {
                closest = blocks[i]
            }
        }

        if(closest != undefined) {
            if(this.whiteList.size() > 20) {
                this.whiteList.remove(0)
            }
            this.previous = toBlockPos(closest)
            this.whiteList.add(this.previous)

            //ChatLib.chat("START")
            sendPacket(new C0APacketAnimation())
            mc.field_71439_g.func_71038_i()
            sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, this.previous, EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
            return true
        } else {
            return false
        }
    }
}

global.exports.foragingMacroHub = new foragingMacro1()