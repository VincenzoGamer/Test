// import ASM_1 from "./block_ASM/renderBlock_ASM.js";
// import ASM_2 from "./block_ASM/shouldSideBeRendered_ASM.js";
// import ASM_3 from "./block_ASM/setOpaqueCube_ASM.js";

import ASM_4 from "./player_ASM/onUpdateWalkingPlayerPre_ASM.js"
import ASM_5 from "./player_ASM/onUpdateWalkingPlayerPost_ASM.js"
 
export default ASM => {
    const {} = ASM;

    /*
        X-Ray
    */
    //ASM_1(ASM)
    //ASM_2(ASM)
    //ASM_3(ASM)

    /*
        Serverside Rotations
    */
    // ASM_4(ASM)
    // ASM_5(ASM)
}
