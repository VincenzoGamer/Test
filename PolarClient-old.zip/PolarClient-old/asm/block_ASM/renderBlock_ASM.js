/*
    RenderBlock ASM, used to filter out the good blocks that are allowed to render
*/
export default ASM_1 = (ASM) => {

    const { desc, L, OBJECT, JumpCondition, BOOLEAN } = ASM;

    ASM.injectBuilder(
        "net/minecraft/client/renderer/BlockRendererDispatcher",
        "renderBlock",
        desc("Z",L("net/minecraft/block/state/IBlockState"),L("net/minecraft/util/BlockPos"), L("net/minecraft/world/IBlockAccess"), L("net/minecraft/client/renderer/WorldRenderer")),
        ASM.At(ASM.At.HEAD)
    )
    .methodMaps({
        func_175018_a: "renderBlock",
    })
    .instructions(($) => {
        $.array(1, OBJECT, $ => {
            $.aadd($ => {
                $.aload(1);
            })
        }).invokeJS("blockCheck")

        $.ifClause([JumpCondition.INSTANCE_OF, BOOLEAN], ($) => {
            $.checkcast(BOOLEAN)
            $.invokeVirtual(BOOLEAN, "booleanValue", desc("Z"))
            $.ifClause([JumpCondition.FALSE], ($) => {
                $.int(0).ireturn()
            });
        });
    })
    .execute()
}
