/*
  setOpaqueCube ASM
*/
export default ASM_3 = (ASM) => {

    const { desc, L, OBJECT, JumpCondition, BOOLEAN } = ASM;

    ASM.injectBuilder(
        "net/minecraft/client/renderer/chunk/VisGraph",
        "setOpaqueCube",
        desc("V", L("net/minecraft/util/BlockPos")),
        ASM.At(ASM.At.HEAD)
    )
    .methodMaps({
        func_178606_a: "setOpaqueCube"
    })
    .instructions(($) => {
        $.array(0, OBJECT, $ => {
        }).invokeJS("XRayToggled")

        $.ifClause([JumpCondition.NULL], ($) => {
            $.pop()
        });

        $.checkcast(BOOLEAN).invokeVirtual(BOOLEAN, "booleanValue", desc("Z"))
        .ifClause([JumpCondition.FALSE], ($) => {
            $.methodReturn()
        })

        $.methodReturn()
    })
    .execute()
}