/*
    ShouldSideBeRendered ASM, renders the full block    
*/
export default ASM_2 = (ASM) => {

    const { desc, L, OBJECT, JumpCondition, BOOLEAN } = ASM;

    ASM.injectBuilder(
        "net/minecraft/block/Block",
        "shouldSideBeRendered",
        desc("Z",L("net/minecraft/world/IBlockAccess"), L("net/minecraft/util/BlockPos"), L("net/minecraft/util/EnumFacing")),
        ASM.At(ASM.At.HEAD)
    )
    .methodMaps({
        func_176225_a: "shouldSideBeRendered",
    })
    .instructions(($) => {
        $.array(0, OBJECT, $ => {
        }).invokeJS("XRayToggled")
        .checkcast(BOOLEAN).invokeVirtual(BOOLEAN, "booleanValue", desc("Z"))
        .ifClause([JumpCondition.FALSE], ($) => {
            $.int(1).ireturn()
        })
    })
    .execute()
}