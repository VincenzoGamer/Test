export default ASM_4 = (ASM) => {
    const { desc, OBJECT } = ASM;

    ASM.injectBuilder(
        "net/minecraft/client/entity/EntityPlayerSP",
        "onUpdateWalkingPlayer",
        desc("V"),
        ASM.At(ASM.At.HEAD)
    )
    .methodMaps({
        func_175161_p: "onUpdateWalkingPlayer"
    })
    .instructions(($) => {
        $.array(0, OBJECT, $ => {
        }).invokeJS("preUpdatePlayer").pop()
    })
    .execute()
}