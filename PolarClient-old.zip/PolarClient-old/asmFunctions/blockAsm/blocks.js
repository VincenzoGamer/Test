export default (a) => {
    if(global.exports?.xrayconfig?.toggle != true) return false
    let b = a.func_177230_c()
    if(global.exports.xrayconfig.blocks.contains(b)) return false
    return true
}