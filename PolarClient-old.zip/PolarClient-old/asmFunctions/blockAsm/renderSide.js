export default () => {
    if(global.exports?.xrayconfig?.toggle != true) return false
    return true
}