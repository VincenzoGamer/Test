export default () => {
    if(global?.exports?.serversideRotations?.toggle === true) {
        Player.getPlayer().field_70177_z = global.exports.serversideRotations.prevYaw
        Player.getPlayer().field_70125_A = global.exports.serversideRotations.prevPitch
        return false
    } else {
        return false
    }
}