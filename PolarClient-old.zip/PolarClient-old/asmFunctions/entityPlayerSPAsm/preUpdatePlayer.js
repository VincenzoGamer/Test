export default () => {
    if(global?.exports?.serversideRotations?.toggle === true) {
        global.exports.serversideRotations.prevYaw = Player.getPlayer().field_70177_z
        global.exports.serversideRotations.prevPitch = Player.getPlayer().field_70125_A
        Player.getPlayer().field_70177_z = global.exports.serversideRotations.yaw
        Player.getPlayer().field_70125_A = global.exports.serversideRotations.pitch
        return false
    } else {
        return false
    }
}