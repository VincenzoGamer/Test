let { finder } = global.exports
let { BP , C09PacketHeldItemChange, mc, polarPrefix, sendPacket, setting, RClickItem } = global.exports

const configAutoKatana = new global.configModuleClass(
    "Auto Katana",
    "Combat",
    false,
    [
        new global.settingToggle("Auto Katana Active", false)
    ],
    [
        "&bAuto Katana",
        "Automattically uses you katana when a Slayer Boss is spawned"
    ]
)

global.modules.push(configAutoKatana)

class autoKatanaClass {
    constructor() {

        this.configName = "Auto Katana"

        this.cooldown = false

        register("step", () => {
            this.toggle = global.exports.settingGet.getSetting(this.configName,"Auto Katana Active")
        }).setFps(1)

        register("tick", () => {
            //ChatLib.chat(this.toggle)
            if(this.toggle) {

                if(!finder.katana()) {
                    ChatLib.chat(polarPrefix + " No Katana in your hotbar")
                    return
                }

                if(!this.isBossSpawned()) return

                if(Client.currentGui.getClassName() != "null") return

                let atomsplitItem = Player?.getInventory()?.getStackInSlot(finder.slotKatana)
                let heldItemName = Player?.getHeldItem()?.getName()
                //ChatLib.chat(atomsplitItem.getName())
                if(heldItemName?.includes("Katana") || heldItemName?.includes("Terminator")) {
                    if(atomsplitItem?.getID() === 276 && !this.cooldown) {
                        let current = Player.getHeldItemIndex()
                        if(heldItemName.includes("Katana")) {
                            ChatLib.chat(polarPrefix + " used Katana")
                            RClickItem()
                            this.cooldown = true
                            new Thread(() => {
                                Thread.sleep(500)
                                this.cooldown = false
                            }).start()
                        }
                        else if(heldItemName.includes("Terminator")) {
                            ChatLib.chat(polarPrefix + " used Terminator")
                            sendPacket(new C09PacketHeldItemChange(finder.slotKatana))
                            sendPacket(new net.minecraft.network.play.client.C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(finder.slotKatana).getItemStack(), 0, 0, 0))
                            if(Player.getHeldItemIndex() != finder.slotKatana) {
                                sendPacket(new C09PacketHeldItemChange(current))
                            }
                            this.cooldown = true
                            new Thread(() => {
                                Thread.sleep(500)
                                this.cooldown = false
                            }).start()
                        }
                    }
                }
            }
        })
    }

    isBossSpawned() {
        let lines = Scoreboard?.getLines()
        for(let i = 0; i < lines.length; i++) {
            if(lines[i].getName().toString().includes("the boss!")) {
                return true
            }
        }
        return false
    }
}

global.exports.autoKatana = new autoKatanaClass()