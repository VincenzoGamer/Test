let { itemMacro, mc, polarPrefix, setting, WalkBackward } = global.exports

const configAutoMaddox = new global.configModuleClass(
    "Auto Maddox",
    "Combat",
    false,
    [
        new global.settingToggle("Auto Maddox Active", false),
        new global.settingToggle("Only use on Death", false),
        new global.settingSelector("Boss Type", 0, [
            "Revenant",
            "Tarantula",
            "Sven",
            "Voidgloom",
            "Inferno"
        ], false),
        new global.settingSelector("Slayer Tier", 0, [
            "1","2","3","4","5"
        ], false)
    ],
    [
        "&bAuto Maddox",
        "Automattically uses your Maddox Batphone when you kill a slayer boss"
    ]
)

global.modules.push(configAutoMaddox)

class autoMaddoxClass {
    constructor() {

        this.configName = "Auto Maddox"

        this.toggle = false

        this.settingType = undefined
        this.settingTier = undefined

        this.clicking = false

        register("chat", () => {
            if(global.exports.settingGet.getSetting(this.configName,"Only use on Death")) return
            this.activate()
        }).setCriteria("NICE! SLAYER BOSS SLAIN!").setContains()

        register("chat", () => {
            this.activate()
        }).setCriteria("SLAYER QUEST FAILED!").setContains()

        register("chat", (theMsg) => {
            let gtheMsg = ChatLib.getChatMessage(theMsg, false)
            if(gtheMsg.includes("[OPEN MENU]") && this.toggle) {
                let sibling = theMsg.message.func_150253_a();
                let style = sibling[2].func_150256_b().func_150235_h().func_150668_b()
                mc.field_71439_g.func_71165_d(style)
            }
        })

        // register("command", () => {
        //     this.activate()
        // }).setName("yey")

        register("tick", () => {
            //ChatLib.chat(Client.currentGui.getClassName())
            if(this.toggle) {
                if (Player.getContainer().getName() === "Slayer" && !this.clicking) {
                    this.clicking = true
                    let windowId = Player.getPlayer().field_71070_bA.field_75152_c
                    new Thread(() => {
                            //if(Player.getContainer().getStackInSlot(13).getID() === 159.0) {
                                mc.field_71442_b.func_78753_a(windowId, 13, 2, 3, Player.getPlayer())
                                windowId++
                            //}
                            Thread.sleep(100)
                            switch(this.settingType) {
                                case "Revenant":
                                    mc.field_71442_b.func_78753_a(windowId, 10, 2, 3, Player.getPlayer())
                                    break;
                                case "Tarantula":
                                    mc.field_71442_b.func_78753_a(windowId, 11, 2, 3, Player.getPlayer())
                                    break;
                                case "Sven":
                                    mc.field_71442_b.func_78753_a(windowId, 12, 2, 3, Player.getPlayer())
                                    break;
                                case "Voidgloom":
                                    mc.field_71442_b.func_78753_a(windowId, 13, 2, 3, Player.getPlayer())
                                    break;
                                case "Inferno":
                                    mc.field_71442_b.func_78753_a(windowId, 14, 2, 3, Player.getPlayer())
                                    break;
                            }
                            windowId++
                            Thread.sleep(100)
                            //while(!Player.getOpenedInventory()?.getContainer()?.func_85151_d()?.func_145748_c_()?.func_150260_c()?.toLowerCase()?.includes(this.settingType.toLowerCase()) && Client.currentGui.getClassName().toString() != "null") {Thread.sleep(20); ChatLib.chat("open Thread 1")};
                            //ChatLib.chat(this.settingTier)
                            switch(this.settingTier.toString()) {
                                case "1":
                                    //ChatLib.chat("here 1")
                                    mc.field_71442_b.func_78753_a(windowId, 11, 2, 3, Player.getPlayer())
                                    //Player.getOpenedInventory()?.click(11, false, "LEFT")
                                    break;
                                case "2":
                                    //ChatLib.chat("here 2")
                                    mc.field_71442_b.func_78753_a(windowId, 12, 2, 3, Player.getPlayer())
                                    //Player.getOpenedInventory()?.click(12, false, "LEFT")
                                    break;
                                case "3":
                                    //ChatLib.chat("here 3")
                                    mc.field_71442_b.func_78753_a(windowId, 13, 2, 3, Player.getPlayer())
                                    //Player.getOpenedInventory()?.click(13, false, "LEFT")
                                    break;
                                case "4":
                                    //ChatLib.chat("here 4")
                                    mc.field_71442_b.func_78753_a(windowId, 14, 2, 3, Player.getPlayer())
                                    //Player.getOpenedInventory()?.click(14, false, "LEFT")
                                    break;
                                case "5":
                                    mc.field_71442_b.func_78753_a(windowId, 15, 2, 3, Player.getPlayer())
                                    break;
                            }
                            windowId++
                            Thread.sleep(100)
                            //while(!Player.getOpenedInventory()?.getContainer()?.func_85151_d()?.func_145748_c_()?.func_150260_c()?.includes("Confirm") && Client.currentGui.getClassName().toString() != "null") {Thread.sleep(20); ChatLib.chat("open Thread 2")};
                            //Player.getOpenedInventory()?.click(11, false, "LEFT")
                            mc.field_71442_b.func_78753_a(windowId, 11, 2, 3, Player.getPlayer())
                    }).start()
                }
            }
        })
    }

    activate() {
        //ChatLib.chat("here")
        if(!global.exports.settingGet.getSetting(this.configName,"Auto Maddox Active")) return
        let foundPhone = itemMacro("Maddox Batphone")
        if(foundPhone) {
            this.toggle = true
            this.clicking = false
            this.settingType = global.exports.settingGet.getSetting(this.configName,"Boss Type")
            this.settingTier = global.exports.settingGet.getSetting(this.configName,"Slayer Tier")
        } else {
            this.toggle = false
        }
    }
}

global.exports.autoMaddox = new autoMaddoxClass()