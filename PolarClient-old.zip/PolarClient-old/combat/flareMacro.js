import RenderLib from "RenderLib";
import Skyblock from "BloomCore/Skyblock";
let { polarPrefix, getClosest, disToPly, lookAt, mc, RClickItem, disFrToFr, fillJavaArray, sendPacket, finder, radians_to_degrees, movePlayer } = global.exports

const configFlareMacro = new global.configModuleClass(
    "Flare Macro",
    "Combat",
    false,
    [
        new global.settingToggle("Use Fire Veil", false)
    ],
    [
        "&bFlare Macro",
        "Grinds Flare's in the crimson isle, you need good gear for this!"
    ]
)

global.modules.push(configFlareMacro)

class flareMacro {
    constructor() {
        this.configName = "Flare Macro"

        this.toggle = false

        this.current = 0

        this.previous = -1
        
        this.lastClick = new Date().getTime()

        this.lastFireVeil = new Date().getTime()    

        this.delayHype = false

        this.flareList = fillJavaArray([0.0])

        this.flareCords = [ 
            [-358, 77, -762], [-348, 76, -761], [-338, 80, -764], [-332, 85, -767], [-328, 87, -776], [-322, 80, -783], [-320, 78, -792], [-317, 77, -801], [-314, 75, -811], [-312, 73, -822], [-315, 70, -831], [-324, 73, -835], [-331, 78, -840], [-337, 83, -845], [-345, 81, -853], [-351, 78, -861], [-357, 75, -868], [-367, 74, -865], [-376, 76, -859], [-384, 79, -854], [-394, 81, -850], [-403, 80, -846], [-413, 80, -842], [-422, 77, -839], [-432, 77, -835], [-434, 78, -825], [-439, 80, -816], [-444, 81, -807], [-442, 79, -797], [-437, 80, -788], [-433, 82, -779], [-418, 79, -770], [-411, 76, -763], [-383, 79, -760], [-373, 76, -762]
        ]

        this.flareCordsClick = [
            0,1,2,3,5,8,13,16,20,24,26,30
        ]

        // register("renderWorld", () => {
        //     if(Skyblock.area != "Crimson Isle") return
        //     for(let i = 0; i < this.flareCords.length; i++) {
        //         RenderLib.drawEspBox(this.flareCords[i][0] + 0.5, this.flareCords[i][1], this.flareCords[i][2] + 0.5, 1, 1, 0, 1, 0, 1, true)
        //         Tessellator.drawString(i + 1, this.flareCords[i][0] + 0.5, this.flareCords[i][1] + 0.5, this.flareCords[i][2] + 0.5)
        //     }
        // })

        register("tick", () => {
            if(!this.toggle) return
            let cord = this.flareCords[this.current]
            if(disToPly(cord[0], cord[1], cord[2]) < 6) {
                if(this.current === (this.flareCords.length - 1)) this.current = 0
                else this.current += 1
                cord = this.flareCords[this.current]
            }

            lookAt(cord[0] + 0.5, cord[1] + 0.5, cord[2] + 0.5, 30, false, false)

            //let newCords = movePlayer(Player, 10)

            // let flares = World.getAllEntitiesOfType(net.minecraft.entity.monster.EntityBlaze)
            // let found = false
            // for(let i = 0; i < flares.length; i++) {
            //     if(this.delayHype) break
            //     let flare = flares[i]
            //     let dis = disFrToFr(newCords.newX, newCords.newY, newCords.newZ, flare.getX(), flare.getY(), flare.getZ())
            //     if(dis < 10 && dis > 6 && flare.entity.func_110143_aJ() > 1.1 && !this.flareList.contains(flare.entity.func_145782_y())) {
            //         this.flareList.add(flare.entity.func_145782_y())
            //         while(this.flareList.size() > 10) this.flareList.remove(0)
            //         found = true
            //     }
            // }

            if(/*found || */this.flareCordsClick.includes(this.current) && this.previous != this.current) {
                Player.setHeldItemIndex(finder.slotHyperion)
                this.delayHype = true
                this.previous = this.current
            }
            else if(!this.delayHype) Player.setHeldItemIndex(finder.slotWarp)

            if(new Date().getTime() - this.lastClick > 300) {
                this.lastClick = new Date().getTime()
                this.delayHype = false
                lookAt(cord[0] + 0.5, cord[1] + 0.5, cord[2] + 0.5, 1, true, false)
            }

            if(new Date().getTime() - this.lastFireVeil > 5800 && this.useFireVeil) {
                this.lastFireVeil = new Date().getTime()
                this.clickFireVeil()
            }
        })

        register("command", () => {
            this.toggleMacro()
        }).setName("flare")
    }

    toggleMacro() {
        this.toggle = !this.toggle

        this.useFireVeil = global.exports.settingGet.getSetting(this.configName, "Use Fire Veil")

        if(this.toggle) {
            if((!this.useFireVeil || finder.fireveil()) && finder.hyperion() && finder.etherwarp() && Skyblock.area === "Crimson Isle") {
                ChatLib.chat(polarPrefix + "Flare Macro: " + this.toggle)
                this.previous = -1
                this.current = getClosest(this.flareCords, "array", true)
                this.delayHype = false
                this.flareList = fillJavaArray([0.0])
            } else {
                this.toggle = false
                ChatLib.chat(polarPrefix + 'Flare Macro Missing: ')
                if(!finder.fireveil() && this.useFireVeil) ChatLib.chat("- FireVeil")
                if(!finder.hyperion()) ChatLib.chat("- Hyperion")
                if(!finder.etherwarp()) ChatLib.chat("- Etherwarp")
                if(Skyblock.area != "Crimson Isle") ChatLib.chat("- In the Crimson Isle")
            }
        }
        else if(!this.toggle) {
            ChatLib.chat(polarPrefix + "Flare Macro: " + this.toggle)
        }
    }

    clickFireVeil() {
        let current = Player.getHeldItemIndex()
        sendPacket(new global.exports.C09PacketHeldItemChange(finder.slotFireVeil))
        sendPacket(new net.minecraft.network.play.client.C08PacketPlayerBlockPlacement(new global.exports.BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(finder.slotFireVeil).getItemStack(), 0, 0, 0))
        sendPacket(new global.exports.C09PacketHeldItemChange(current))
    }
}

global.exports.flareMacro = new flareMacro()