import RenderLib from "RenderLib";
import { raytraceBlocks } from "Bloomcore/utils/Utils.js"
import Vector3 from "Bloomcore/utils/Vector3.js"
let { keyBind } = global.exports
let{ polarPrefix, mc, WalkForward, setting, sendPacket, C09PacketHeldItemChange, BP, Sprint, WalkRight, WalkLeft, ArrayLists, Shift} = global.exports
let { disToPly, disToPlyFlat } = global.exports
let { lookAt, lookAt2 } = global.exports
let { degreeRannge, degreeRanngeRaw } = global.exports
let { finder, RClickItem, disFrToFr, WalkJump, getClosest, rayTrace, getPointsOnBlock, WalkBackward, cancelWalk} = global.exports

const configGhostFarmer = new global.configModuleClass(
    "Ghost Macro",
    "Combat",
    false,
    [
        new global.settingSlider("Weapon Slot", 1, 1, 8),
        new global.settingToggle("Auto Wand", false),
        new global.settingToggle("Auto Sword of Bad Health", false),
        new global.settingToggle("Auto Tuba", false),
        new global.settingToggle("Auto Overflux (Legit)", false),
        new global.settingToggle("1 tap mode", false)
    ],
    [
        "&bGhost Macro",
        "Requirements: Attack Weapon, Etherwarp, Optional Items"
    ]
)

global.modules.push(configGhostFarmer)

let LClick = mc.getClass().getDeclaredMethod("func_147116_af")
LClick.setAccessible(true)

class ghostFarmer {
    constructor() {

        this.configName = "Ghost Macro"

        this.toggle = false

        this.toggleGhost = false

        this.click = false

        this.autoWand = false

        this.wandTicks = 119

        this.fluxTicks = 1180

        this.forgeCoolDown = 0

        this.current = 0
        this.first = false

        this.looked = false

        this.currentPlace = undefined

        this.currentGhost = undefined

        this.waitCount = 0

        this.waitAotv = 0

        this.tubaTick = 400

        this.swordOfBadHealthTick = 100

        this.swapTime = new Date().getTime()

        let ghostCords = [[0,165,-12,"North"],[33,201,-12,"East"],[83,199,-13,"West"],[138,195,-12,"West"],[137,189,43,"North"],[154,151,37,"Up"],[155,130,60,"Up"]]

        this.lastPacket = new Date().getTime()
        this.reScan = new Date().getTime()

        keyBind.keyBindGhostMacro.registerKeyPress(() => {this.toggleMacro()})

        register("command", () => {
            this.check = false
            ChatLib.chat(polarPrefix + "Detected Bedrock check!")

            new Thread(() => {
                for(let i = 0; i < 100; i++) {
                    Thread.sleep(50)
                    World.playSound('mob.ghast.scream', 1000, 100)
                }
            }).start()

            new Thread(() => {
                Thread.sleep(1000)
                this.toggleGhostMacro()
                if(this.toggle) {
                    failsafeGhost.checkType("bedrock")
                    failsafeGhost.toggleFailSafe()
                }
            }).start()
        }).setName("ghostong")  

        register("packetReceived", (packet, event) => {

            if(!this.toggleGhost) return 

            if(new Date().getTime() - this.lastPacket < 200 && this.check) {
                if(packet instanceof net.minecraft.network.play.server.S08PacketPlayerPosLook) {

                    /*
                        let x = packet.func_148932_c() //getX()
                        let y = packet.func_148928_d() //getY()
                        let z = packet.func_148933_e() //getZ()
                    */

                    this.check = false
                    ChatLib.chat(polarPrefix + "Detected Rotation check!")
    
                    new Thread(() => {
                        for(let i = 0; i < 100; i++) {
                            Thread.sleep(50)
                            World.playSound('mob.ghast.scream', 1000, 100)
                        }
                    }).start()
    
                    new Thread(() => {
                        Thread.sleep(1000)
                        this.toggleGhostMacro()
                        if(this.toggle) {
                            failsafeGhost.checkType("bedrock")
                            failsafeGhost.toggleFailSafe()
                        }
                    }).start()
                }
            }

            this.lastPacket = new Date().getTime()
        })

        register("Step", () => {
            if(this.currentGhost != undefined) {

                if(disToPlyFlat(this.currentGhost.getX(), this.currentGhost.getZ()) >= 3.0) {
                    let rawRange = degreeRanngeRaw(this.currentGhost.getX() + this.ofsetX, this.currentGhost.getY() + 1.5, this.currentGhost.getZ() + this.ofsetZ)
                    if(rawRange < -20 && rawRange > -50) { 
                        WalkRight.setState(false)
                        WalkLeft.setState(true)
                        WalkForward.setState(true)
                        WalkBackward.setState(false)
                    } else if(rawRange > 20 && rawRange < 50) {
                        WalkLeft.setState(false)
                        WalkRight.setState(true)
                        WalkForward.setState(true)
                        WalkBackward.setState(false)
                    }
                    else if(rawRange <= -50) { 
                        WalkRight.setState(false)
                        WalkLeft.setState(true)
                        WalkBackward.setState(true)
                        WalkForward.setState(false)
                    } else if(rawRange >= 50) {
                        WalkLeft.setState(false)
                        WalkRight.setState(true)
                        WalkBackward.setState(true)
                        WalkForward.setState(false)
                    } else {
                        WalkLeft.setState(false)
                        WalkRight.setState(false)
                        WalkForward.setState(true)
                        WalkBackward.setState(false)
                    }
                }

                let height = 0.6
                if(disToPly(this.currentGhost.getX(), this.currentGhost.getY() + height, this.currentGhost.getZ()) < 5) {
                    height = 1.5
                    this.ofsetX = 0.0
                    this.ofsetZ = 0.0
                }
                if(degreeRannge(this.currentGhost.getX(), this.currentGhost.getY() + height, this.currentGhost.getZ()) > 30) {
                    lookAt(this.currentGhost.getX() + this.ofsetX, this.currentGhost.getY() + height, this.currentGhost.getZ() + this.ofsetZ, 400, false, false)
                } else {
                    lookAt2(this.currentGhost.getX() + this.ofsetX, this.currentGhost.getY() + height, this.currentGhost.getZ() + this.ofsetZ, 90, false, false)
                }
            }
        }).setFps(10)

        register("Chat", (message) => {
            let msg = ChatLib.getChatMessage(message, false)
            if(msg.toString().includes("You were killed by Ghost")) {
                ChatLib.chat(polarPrefix + " You were kill by Ghost going back!")
                this.toggleGhostMacro()
            }
        })

        register("attackEntity", (daEntity, event) => {
            if(this.toggle && this.oneTap) {
                //ChatLib.chat("here")
                if(daEntity.getClassName().toLowerCase().includes("creeper") && disToPly(daEntity.getX(), daEntity.getY(), daEntity.getZ()) < 5 && !this.whitelist.contains(daEntity.entity.func_145782_y())) {
                    if(this.whitelist.size() > 2) {
                        this.whitelist.remove(0)
                    }
                    this.whitelist.add(daEntity.entity.func_145782_y())
                    this.currentId = undefined
                }
            }
        })

        register("Tick", () => {

            if(this.toggle) {

                if(World.getBlockAt(Math.floor(Player.getX()), Math.floor(Player.getY()) - 1, Math.floor(Player.getZ())).type.getID() === 7 && this.check) {
                    this.check = false
                    ChatLib.chat(polarPrefix + "Detected Bedrock check!")

                    new Thread(() => {
                        for(let i = 0; i < 100; i++) {
                            Thread.sleep(50)
                            World.playSound('mob.ghast.scream', 1000, 100)
                        }
                    }).start()

                    new Thread(() => {
                        Thread.sleep(1000)
                        this.toggleGhostMacro()
                        if(this.toggle) {
                            failsafeGhost.checkType("bedrock")
                            failsafeGhost.toggleFailSafe()
                        }
                    }).start()
                }

                this.callCords()

                if(this.currentPlace === "lobby") {
                    if(this.plyY < 70) {
                        this.waitCount += 1
                    } else {
                        this.waitCount = 0
                    }

                    if(this.waitCount === 40) {
                        this.currentPlace = "forge"
                        this.waitCount = 0
                        ChatLib.say("/skyblock")
                    }
                } else if(this.currentPlace === "forge") {
                    if(this.plyY > 148) {
                        this.waitCount += 1
                    } else {
                        this.waitCount = 0
                    }

                    if(this.waitCount === 40) {
                        this.currentPlace = "hub"
                        this.waitCount = 0
                        ChatLib.say("/warp hub")
                    }
                } else if(this.currentPlace === "hub") {
                    if(this.plyY < 71) {
                        this.waitCount += 1
                    } else {
                        this.waitCount = 0
                    }

                    if(this.waitCount === 40) {
                        this.currentPlace = undefined
                        this.toggleAotvMacro()
                    }
                }

                if(this.toggleAotv) {

                    if(this.first) {
                        if(this.atForge()) {
                            this.first = false
                        }
                    }
                    else if(this.current < ghostCords.length) {
                        if(!this.looked) {
                            if(this.current === (ghostCords.length - 1)) {
                                this.goToNextBlock(ghostCords[this.current][0], ghostCords[this.current][1], ghostCords[this.current][2], ghostCords[this.current][3], true, false)
                            } else {
                                this.goToNextBlock(ghostCords[this.current][0], ghostCords[this.current][1], ghostCords[this.current][2], ghostCords[this.current][3], true, true)
                            }
                            this.looked = true
                            this.waitAotv = 0
                        } else {
                            this.waitAotv += 1

                            if(this.current === (ghostCords.length - 1)) {

                                if(this.plyY < 78) {

                                    if(this.toggleAotv) {
                                        this.toggleAotvMacro()
                                    }

                                    if(this.allReadyAtSpot(78)) {
                                        //ChatLib.chat("here")
                                        ChatLib.say("/l")
                                        this.currentPlace = "lobby"
                                        this.waitCount = 0
                                    } else {
                                        this.toggleGhostMacro()
                                    }
                                }
                            }
                            else if(this.plyX === ghostCords[this.current][0] && this.plyY === (ghostCords[this.current][1] + 1) && this.plyZ === ghostCords[this.current][2]) {
                                this.looked = false
                                this.current += 1
                            }

                            if(this.waitAotv === 100 && this.current != (ghostCords.length - 1)) {
                                this.toggleAotvMacro()
                                this.currentPlace = "forge"
                                this.waitCount = 0
                            }
                        }
                    }
                    
                }

                if(this.toggleGhost && (this.fluxTicks <= 1180 || !this.autoFlux)) {  

                    if(new Date().getTime() - this.reScan > 100) this.currentGhost = this.closestGhost()?.ghost
                    //  ChatLib.chat(this.currentGhost)

                    if(this.plyY > 198) {
                        this.toggleGhostMacro()
                        ChatLib.chat(polarPrefix + " You Died :(")
                        ChatLib.chat(polarPrefix + 'Going Back')
                        new Thread(() => {
                            let count = 0
                            while(this.toggle && count < 180) {
                                Thread.sleep(50);
                                count += 1;
                            }
                            if(this.toggle) {
                                this.toggleAotvMacro()
                            }
                        }).start()
                    }

                    if(this.currentGhost != undefined) {
                        try {
                            if(disToPlyFlat(this.currentGhost.getX(), this.currentGhost.getZ()) > 3.0) {
                                if(disToPly(this.currentGhost.getX(), this.currentGhost.getY() + 1.5, this.currentGhost.getZ()) > 10) {
                                    Sprint.setState(true)
                                } else {
                                    if(!this.oneTap) Sprint.setState(false)
                                    else Sprint.setState(true)
                                }
                            } else {
                                if(!this.oneTap || disToPlyFlat(this.currentGhost.getX(), this.currentGhost.getZ()) < 3.0) WalkForward.setState(false)
                                if(!this.oneTap) Sprint.setState(false)
                                WalkLeft.setState(false)
                                WalkRight.setState(false)
                            }
                            if(disToPlyFlat(this.currentGhost.getX(), this.currentGhost.getZ()) < 10) {
                                this.click = !this.click
                                if(this.click) {
                                    new Thread(() => {
                                        let number = Math.random() * 100    
                                        Thread.sleep(number)
                                        if(Player.getHeldItemIndex() === this.weaponSlot) Client.scheduleTask(0, () => {LClick.invoke(mc)})
                                    }).start()
                                }
                            }
                        } catch(e) {
                            ChatLib.chat(e)
                        }
                    } else {
                        WalkForward.setState(false)
                        Sprint.setState(false)
                    }

                    if(this.autoWand && Player.getHP() < 16.0) {
                        this.wandTicks += 1
                        if(this.wandTicks >= 120) {
                            this.wandTicks = 0
                            new Thread(() => {
                                Player.setHeldItemIndex(finder.slotHealingWand)
                                Thread.sleep(200)
                                RClickItem()
                                Thread.sleep(200)
                                Player.setHeldItemIndex(this.weaponSlot)
                            }).start()
                        }
                    }

                    if(this.autoTuba) {
                        this.tubaTick += 1
                        if(this.tubaTick >= 420) {
                            this.tubaTick = 0
                            new Thread(() => {
                                Player.setHeldItemIndex(finder.slotWeirdTuba)
                                Thread.sleep(200)
                                RClickItem()
                                Thread.sleep(200)
                                Player.setHeldItemIndex(this.weaponSlot)
                            }).start()
                        }
                    }

                    if(this.autoSwordOfBadHealth) {
                        this.swordOfBadHealthTick += 1
                        if(this.swordOfBadHealthTick >= 120) {
                            this.swordOfBadHealthTick = 0
                            new Thread(() => {
                                Player.setHeldItemIndex(finder.slotSwordOfBadHealth)
                                Thread.sleep(200)
                                RClickItem()
                                Thread.sleep(200)
                                Player.setHeldItemIndex(this.weaponSlot)
                            }).start()
                        }
                    }

                    if(this.autoFlux) {
                        this.fluxTicks += 1
                        if(this.fluxTicks >= 1180) {
                            this.toggleGhostMacro()
                            new Thread(() => {
                                Player.setHeldItemIndex(finder.slotOverflux)
                                for(let i = 0; i < 200; i++) {
                                    Player.getPlayer()?.field_70177_z += -10/200
                                    if(Player.getYaw() < 45.0) Player.getPlayer()?.field_70125_A += 40/200
                                    Thread.sleep(1)
                                }
                                RClickItem()
                                Thread.sleep(200)
                                Player.setHeldItemIndex(this.weaponSlot)
                                this.fluxTicks = 0
                                this.toggleGhostMacro()
                            }).start()
                        }
                    }
                }
            }
        })

        register("renderWorld", () => {
            if(this.currentGhost != undefined) {
                RenderLib.drawEspBox(this.currentGhost.getX(), this.currentGhost.getY(), this.currentGhost.getZ(), 1, 2, 0, 0, 1, 1, true)
            }
        })
    }

    toggleMacro() {
        this.toggle = !this.toggle

        this.autoWand = global.exports.settingGet.getSetting(this.configName,"Auto Wand")
        this.autoTuba = global.exports.settingGet.getSetting(this.configName,"Auto Tuba")
        this.autoFlux = global.exports.settingGet.getSetting(this.configName,"Auto Overflux (Legit)")
        this.autoSwordOfBadHealth = global.exports.settingGet.getSetting(this.configName,"Auto Sword of Bad Health")
        this.weaponSlot = (parseInt(global.exports.settingGet.getSetting(this.configName,"Weapon Slot")) - 1)
        this.oneTap = global.exports.settingGet.getSetting(this.configName,"1 tap mode")
        this.whitelist = new ArrayLists

        if(this.toggle) {
            if((!this.autoWand || finder.healingWand()) && (!this.autoTuba || finder.weirdTuba()) && (!this.autoSwordOfBadHealth || finder.swordOfBadHealth()) && (!this.autoFlux || finder.overflux()) && finder.etherwarp()) {
                ChatLib.chat(polarPrefix + " Ghost Macro: " + this.toggle)

                this.wandTicks = 119
                this.fluxTicks = 1180
                this.tubaTick = 400
                this.swordOfBadHealthTick = 100

                if(Math.round(Player.getY()) === 76) {
                    this.toggleGhostMacro()
                } else {
                    this.toggleAotvMacro()
                }
            } else {
                ChatLib.chat(polarPrefix + " Missing Items: ")
                if(!finder.healingWand() && this.autoWand) {
                    ChatLib.chat("- Healing Wand")
                }
                if(!finder.overflux() && this.autoFlux) {
                    ChatLib.chat("- Power Orb")
                }
                if(!finder.swordOfBadHealth() && this.autoSwordOfBadHealth) {
                    ChatLib.chat("- Sword Of Bad Health")
                }
                if(!finder.weirdTuba() && this.autoTuba) {
                    ChatLib.chat("- Weird Tuba")
                }
                if(!finder.etherwarp()) {
                    ChatLib.chat("- Etherwarp")
                }
                this.toggle = false
            }

        } else {
            ChatLib.chat(polarPrefix + " Ghost Macro: " + this.toggle)

            if(this.toggleAotv) {
                this.toggleAotvMacro()
            }
            if(this.toggleGhost) {
                this.toggleGhostMacro()
            }
            if(failsafeGhost.toggle) {
                failsafeGhost.toggleFailSafe()
            }
        }
    }

    toggleAotvMacro() {
        this.toggleAotv = !this.toggleAotv
        if(this.toggleAotv) {
            ChatLib.chat(polarPrefix + " Started Etherwarping")
            ChatLib.say("/warp forge")
            this.looked = false
            this.current = 0
            this.first = true
        } else {
            ChatLib.chat(polarPrefix + " Stopped Etherwarping")
        }
    }

    toggleGhostMacro() {
        this.toggleGhost = !this.toggleGhost

        if(this.toggleGhost) {
            ChatLib.chat(polarPrefix + " Started Killing Ghosts")
            this.check = true
            Player.setHeldItemIndex(this.weaponSlot)
        } else {
            ChatLib.chat(polarPrefix + " Stopped Killing Ghosts")
            this.currentGhost = undefined
            WalkForward.setState(false)
            Sprint.setState(false)
            cancelWalk("none")
            Shift.setState(false)
        }
    }

    allReadyAtSpot(y) {
        let players = World.getAllPlayers()
        let ownName = Player.getName()
        for(let i = 0; i < players.length; i++) {
            if(players[i].getY() < y && players[i].getName() != ownName && players[i].getX() > 111) {
                return true
            }
        }
        return false
    }

    closestGhost() {
        let allCreepers = World.getAllEntitiesOfType(net.minecraft.entity.monster.EntityCreeper)
        let playerMP = Player.asPlayerMP()
        let allGhosts = []

        for(let i = 0; i < allCreepers.length; i++) {
            let creeper = allCreepers[i]

            if(creeper.entity.func_110143_aJ() < 1.1) {
                if(creeper.entity.func_145782_y() === this.currentId) this.currentId = undefined
                this.reScan = new Date().getTime()
                creeper.entity.func_70106_y()
            }

            let disM = 2.0
            let rangeM = 0.2
            let centerM = 0.0

            if(creeper.entity.func_145782_y() === this.currentId && this.currentId != undefined) return {
                ghost: creeper,
                dis: disToPly(creeper.getX(), creeper.getY(), creeper.getZ()) * disM,
                range: degreeRannge(creeper.getX(), creeper.getY(), creeper.getZ()) * rangeM,
                centerdis: disFrToFr(150.5,76,63.5,creeper.getX(), creeper.getY(), creeper.getZ()) * centerM,
                id: creeper.entity.func_145782_y()
            }

            if(creeper.entity.func_110143_aJ() > 1.1 && creeper.entity.func_110143_aJ() != 20.0 && creeper.getY() < 78.0 && creeper.getX() > 111 && playerMP.canSeeEntity(creeper) && !(creeper.getZ() > 76.5 && creeper.getX() < 122) && (creeper.entity.func_110143_aJ() < 2000001 || !this.ignoreRunic) && (!this.whitelist.contains(creeper.entity.func_145782_y()) || !this.oneTap)) { 
                let object = {
                    ghost: creeper,
                    dis: disToPly(creeper.getX(), creeper.getY(), creeper.getZ()) * disM,
                    range: degreeRannge(creeper.getX(), creeper.getY(), creeper.getZ()) * rangeM,
                    centerdis: disFrToFr(150.5,76,63.5,creeper.getX(), creeper.getY(), creeper.getZ()) * centerM,
                    id: creeper.entity.func_145782_y()
                }
                allGhosts.push(object)
            }
        }

        let closestGhost = undefined
        for(let i = 0; i < allGhosts.length; i++) {
            let ghost = allGhosts[i]
            if(closestGhost === undefined) closestGhost = ghost
            else if((ghost.range + ghost.dis) < (closestGhost.range + closestGhost.dis)) closestGhost = ghost
        }

        if(closestGhost != undefined) {
            this.ofsetX = -2 * Math.random() + 1
            this.ofsetZ = -2 * Math.random() + 1
            if(this.currentId === undefined) this.currentId = closestGhost.id
            return closestGhost.ghost
        } else {
            return undefined
        }
    }

    goToNextBlock(x1,y1,z1,direction,aotv,crouch) {
        Player.setHeldItemIndex(finder.slotWarp)
        let x = 0
        let y = 0
        let z = 0
        if(direction === "Up") {
            y = 1
            x = 0.5
            z = 0.5
        } else if(direction === "Down") {
            y = 0
            x = 0.5
            z = 0.5
        } else if(direction === "North") {
            y = 0.5
            z = 0
            x = 0.5
        } else if(direction === "South") {
            y = 0.5
            z = 1
            x = 0.5
        } else if(direction === "East") {
            y = 0.5
            z = 0.5
            x = 0
        } else if(direction === "West") {
            y = 0.5
            z = 0.5
            x = 1
        } else if(direction === "none") {
            x = 0.5
            y = 0.5
            z = 0.5
        }
        lookAt(x1 + x, y1 + y, z1 + z, 300, aotv, crouch)
    }

    atForge() {
        this.callCords()
        if(this.plyX === 0 && this.plyY === 149 && this.plyZ === -69) {
            if(this.forgeCoolDown < 20) {
                this.forgeCoolDown += 1
            } else {
                this.forgeCoolDown = 0
                return false
            }

            if(this.forgeCoolDown === 20) {
                this.forgeCoolDown = 0
                return true
            }
        } else {
            this.forgeCoolDown = 0
            return false
        }
    }

    callCords() {
        this.plyX = Math.floor(Player.getX())
        this.plyY = Player.getY()
        this.plyZ = Math.floor(Player.getZ())
    }
}

global.exports.ghostMacro = new ghostFarmer()

class failsafeGhostClass {
    constructor() {
        this.toggle = false

        register("tick", () => {
            if(!this.toggle || !global.exports.ghostMacro.toggle) return

            let timeDiff = new Date().getTime() - this.startAction
            if(this.type === "bedrock") {
                if(timeDiff > 890 && timeDiff < 950) {
                    ChatLib.say("hi hi lmao")
                    return;
                }

                if(timeDiff > 1200 && timeDiff < 1300) {
                    WalkRight.setState(false)
                    WalkForward.setState(true)
                    new Thread(() => {
                        for(let i = 0; i < 400; i++) {
                            Player.getPlayer()?.field_70177_z += 0.3
                            Player.getPlayer()?.field_70125_A += 0.2/10
                            Thread.sleep(1)
                        }
                    }).start()
                    return;
                }

                if(timeDiff > 1300 && timeDiff < 2000) {
                    WalkForward.setState(true)
                    WalkJump.setState(true)
                    return;
                }

                if(timeDiff > 2000 && timeDiff < 2100) {
                    WalkForward.setState(false)
                    return;
                }

                if(timeDiff > 2140 && timeDiff < 2200 && this.aotvSide) {
                    let spots = [[147,103,38],[149,102,38],[172,98,73]]
                    let plyX = global.exports.intToFloat(Player.getX())
                    let plyY = global.exports.intToFloat(Player.getY()) + 1.62
                    let plyZ = global.exports.intToFloat(Player.getZ())
                    for(let i = 0; i < spots.length; i++) {
                        let spot = spots[i]
                        let pos = new BP(spot[0], spot[1], spot[2])
                        getPointsOnBlock(pos).forEach(point => {
                            if(this.aotvSide) {
                                let dX = global.exports.intToFloat(point.field_72450_a) - plyX
                                let dY = global.exports.intToFloat(point.field_72448_b) - plyY
                                let dZ = global.exports.intToFloat(point.field_72449_c) - plyZ
                                let tempArray = raytraceBlocks([plyX, plyY, plyZ], new Vector3(dX,dY,dZ), 60, this.blockCheckFunc, true)
                                if(tempArray != null) { 
                                    if(tempArray[0] === spot[0] && tempArray[1] === spot[1] && tempArray[2] === spot[2]) {
                                        this.aotvSide = false
                                        lookAt(spot[0], spot[1], spot[2], 300, false, false)
                                        Player.setHeldItemIndex(5)
                                    }
                                }
                            }
                        })
                    }
                    return;
                }

                if(timeDiff > 2490 && timeDiff < 2550) {
                    WalkForward.setState(true)
                    this.aotvSide = true
                    new Thread(() => {
                        for(let i = 0; i < 6; i++) {
                            Thread.sleep(100 * Math.random() + 200)
                            RClickItem()
                        }
                    }).start()
                    return;
                }

                if(timeDiff > 4440 && timeDiff < 4500) {
                    WalkJump.setState(false)
                    WalkForward.setState(false)
                    return;
                }

                if(timeDiff > 5490 && timeDiff < 5550) {
                    ChatLib.say("LOL")
                    new Thread(() => {
                        Shift.setState(true)
                        WalkRight.setState(true)
                        Thread.sleep(400)
                        lookAt(147,86,65, 700, false, false)
                    }).start()
                    return;
                }

                if(timeDiff > 7340 && timeDiff < 7400) {
                    WalkRight.setState(false)
                    WalkJump.setState(false)
                    WalkForward.setState(true)
                    new Thread(() => {
                        for(let i = 0; i < 6; i++) {
                            Player.getPlayer().field_70177_z += (30 * Math.random() - 15)
                            Thread.sleep(100 * Math.random() + 200)
                            Client.scheduleTask(0, () => {LClick.invoke(mc)})
                        }
                    }).start()
                    return;
                }

                if(timeDiff > 9040 && timeDiff < 9100) {
                    WalkForward.setState(false)
                    return;
                }

                if(timeDiff > 9390 && timeDiff < 9450) {
                    Shift.setState(false)
                    return;
                }

                if(timeDiff > 20040 && timeDiff < 20100) {
                    WalkForward.setState(true)
                    new Thread(() => {
                        while(Math.round(Player.getY()) != 76 && this.toggle) Thread.sleep(200)

                        if(this.toggle) {
                            this.toggleFailSafe()
                            global.exports.ghostMacro.check = true
                            global.exports.ghostMacro.toggleGhostMacro()
                        }
                    }).start()
                    return;
                }
            }
        })
    }

    toggleFailSafe() {
        this.toggle = !this.toggle
        this.startAction = new Date().getTime()
        this.aotvSide = true
    }

    checkType(type) {
        this.type = type
    }

    blockCheckFunc(block) {
        if(World.getBlockAt(block.getX(), block.getY(), block.getZ()).type.getID() != 0.0) {
            return true
        }
        return false
    }
}

let failsafeGhost = new failsafeGhostClass()