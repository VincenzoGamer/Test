let { keyBind } = global.exports
let { C0BPacketEntityAction, Shift, mc, polarPrefix, sendPacket, setting } = global.exports

const configHelmetSwapper = new global.configModuleClass(
    "Helmet Swapper",
    "Combat",
    false,
    [
        new global.settingSelector("First Helmet", 0, [
            "Crimson"
        ], false),
        new global.settingSelector("Second Helmet", 0, [
            "Crimson"
        ], false),
        new global.settingToggle("Crouch and Swap Back after use", false),
        new global.settingSlider("Swapping Back Delay", 300, 1, 1000)
    ],
    [
        "&bHelmet Swapper",
        "Swaps between helmets really fast"
    ]
)

global.modules.push(configHelmetSwapper)

const configArmorSwapper = new global.configModuleClass(
    "Armor Swapper",
    "Combat",
    false,
    [
        new global.settingSelector("First Armor Set", 0, [
            "Crimson"
        ], false),
        new global.settingSelector("Second Armor Set", 0, [
            "Crimson"
        ], false),
    ],
    [
        "&bArmor Swapper",
        "Swaps between Armor Set's really fast"
    ]
)

global.modules.push(configArmorSwapper)

class helmetSwapperClass {
    constructor() {
        this.lastSwap = new Date().getTime()
        this.toggle = false

        keyBind.keyBindHelmetSwapper.registerKeyPress(() => {this.swapHelmet()})
        keyBind.keyBindArmorSwapper.registerKeyPress(() => {this.swapArmor()})

        register("guiMouseClick", (x,y,number,gui,event) => {
            if(!this.toggle) return
            if(gui.class.getSimpleName().toString() === "GuiChest" && (number === 0.0 || number === 1.0)) {
                cancel(event)
            }
            //ChatLib.chat(gui.class.getSimpleName())
            //ChatLib.chat(number)
        })

        // register("packetReceived", (packet,event) => {
        //     //let packettype = packet
        //     for(let i = 0; i < packet.length; i++) {
        //         ChatLib.chat(packet.get(i))
        //     }
        // }).setPacketClasses([net.minecraft.network.play.server.S2DPacketOpenWindow])
    }

    swapArmor() {
        if(new Date().getTime() - this.lastSwap > 500 && !this.toggle) {
            new Thread(() => {
                this.lastSwap = new Date().getTime()
                this.toggle = true
                let name1 = global.exports.settingGet.getSetting("Armor Swapper","First Armor Set").toLocaleLowerCase()
                let name2 = global.exports.settingGet.getSetting("Armor Swapper","Second Armor Set").toLocaleLowerCase()
                let swapBack = global.exports.settingGet.getSetting("Armor Swapper","Crouch and Swap Back after use")
                ChatLib.say("/equipment")
                let count = 0
                while(Player?.getContainer()?.getName() != "Your Equipment and Stats" && count < 20) {Thread.sleep(50); count += 1}
                if(count === 20) {ChatLib.chat(polarPrefix + " Took to long stopping"); this.lastSwap = new Date().getTime(); this.toggle = false;return}

                if(Player?.getContainer()?.getName() === "Your Equipment and Stats") {
                    let contItems = Player.getContainer().getItems()
                    let firstName = undefined
                    for(let i = 53; i < 89; i++) {
                        let name = contItems[i]?.getName()?.removeFormatting()?.toLocaleLowerCase()
                        if(name?.includes(name1)) {
                            firstName = name1
                            break
                        }
                        if(name?.includes(name2)) {
                            firstName = name2
                            break
                        }
                    }
                    let windowId = Player.getPlayer().field_71070_bA.field_75152_c
                    for(let i = 53; i < 89; i++) {
                        let name = contItems[i]?.getName()?.removeFormatting()?.toLocaleLowerCase()
                        if(name?.includes(firstName)) {
                            //if(windowId <= Player.getPlayer().field_71070_bA.field_75152_c) windowId = Player.getPlayer().field_71070_bA.field_75152_c
                            //Thread.sleep(60)
                            mc.field_71442_b.func_78753_a(windowId, i, 2, 3, Player.getPlayer())
                            windowId++
                        }
                    }
                }
                Client.scheduleTask(0, () => {Client.currentGui.close()})
                if(swapBack) {
                    let delayMs = global.exports.settingGet.getSetting("Armor Swapper","Swapping Back Delay")
                    let delaysCount = delayMs/10
                    let countShitt = 0
                    sendPacket(new C0BPacketEntityAction(mc.field_71439_g, C0BPacketEntityAction.Action.START_SNEAKING))
                    sendPacket(new C0BPacketEntityAction(mc.field_71439_g, C0BPacketEntityAction.Action.STOP_SNEAKING))
                    while(countShitt < delaysCount) {Thread.sleep(10); countShitt += 1}
                    this.lastSwap = new Date().getTime()
                    ChatLib.say("/equipment")
                    let count = 0
                    while(Player?.getContainer()?.getName() != "Your Equipment and Stats" && count < 20) {Thread.sleep(50); count += 1}
                    if(count === 20) {ChatLib.chat(polarPrefix + " Took to long stopping"); this.lastSwap = new Date().getTime(); this.toggle = false;return}

                    if(Player?.getContainer()?.getName() === "Your Equipment and Stats") {
                        let contItems = Player.getContainer().getItems()
                        let firstName = undefined
                        for(let i = 53; i < 89; i++) {
                            let name = contItems[i]?.getName()?.removeFormatting()?.toLocaleLowerCase()
                            if(name?.includes(name1)) {
                                firstName = name1
                                break
                            }
                            if(name?.includes(name2)) {
                                firstName = name2
                                break
                            }
                        }
                        let windowId = Player.getPlayer().field_71070_bA.field_75152_c
                        for(let i = 53; i < 89; i++) {
                            let name = contItems[i]?.getName()?.removeFormatting()?.toLocaleLowerCase()
                            if(name?.includes(firstName)) {
                                //if(windowId <= Player.getPlayer().field_71070_bA.field_75152_c) windowId = Player.getPlayer().field_71070_bA.field_75152_c
                                mc.field_71442_b.func_78753_a(windowId, i, 2, 3, Player.getPlayer())
                                windowId++
                            }
                        }
                    }
                }
                Client.scheduleTask(0, () => {Client.currentGui.close()})
                this.toggle = false
                this.lastSwap = new Date().getTime()
            }).start()
        } else {
            ChatLib.chat(polarPrefix + " On Cooldown")
        }
    }

    armorSlotsThere() {
        let count = 0
        let contItems = Player.getContainer().getItems()
        for(let i = 36; i < 45; i++) {
            if(contItems[i] != null) count += 1
        }

        if(count === 9) return true
        if(count < 9) return false
    }

    swapHelmet() {
        if(new Date().getTime() - this.lastSwap > 500 && !this.toggle) {
            new Thread(() => {
                this.lastSwap = new Date().getTime()
                this.toggle = true
                let item1 = global.exports.settingGet.getSetting("Helmet Swapper","First Helmet").toLocaleLowerCase()
                let item2 = global.exports.settingGet.getSetting("Helmet Swapper","Second Helmet").toLocaleLowerCase()
                ChatLib.say("/equipment")
                let count = 0
                while(Player?.getContainer()?.getName() != "Your Equipment and Stats" && count < 20) {Thread.sleep(50); count += 1}
                if(count === 20) {ChatLib.chat(polarPrefix + " Took to long stopping"); this.lastSwap = new Date().getTime(); this.toggle = false;return}

                if(Player?.getContainer()?.getName() === "Your Equipment and Stats") {
                    let contItems = Player.getContainer().getItems()
                    for(let i = 53; i < 89; i++) {
                        //ChatLib.chat(contItems[i]?.getName()?.removeFormatting()?.toLocaleLowerCase())
                        let name = contItems[i]?.getName()?.removeFormatting()?.toLocaleLowerCase()
                        if(name?.includes(item1) || name?.includes(item2)) {
                            //Thread.sleep(50)
                            Player.getContainer().click(i,false,"LEFT")
                            break
                        }
                    }
                }
                //Thread.sleep(100)
                Client.scheduleTask(0, () => {Client.currentGui.close()})
                this.toggle = false
                this.lastSwap = new Date().getTime()
                //ChatLib.chat("closest thread")
            }).start()
        } else {
            ChatLib.chat(polarPrefix + " On Cooldown")
        }
    }
}

global.exports.helmetSwapper = new helmetSwapperClass()