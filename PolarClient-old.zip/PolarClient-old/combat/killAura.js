let { polarPrefix, disToPly, mc, keyBind, degreeRanngeRaw, rotaPitchRangeRaw, serversideRotations } = global.exports

class killAura {
    constructor() {
        this.toggle = false
        this.shouldAttack = false

        keyBind.keyBindKillAura.registerKeyPress(() => {this.toggleMacro()})

        register("tick", () => {
            if(this.toggle) {
                let players = World.getAllPlayers()
                let found = false
                for(let i = 0; i < players.length; i++) {
                    let player = players[i]
                    if(disToPly(player.getX(), player.getY() + 1.5, player.getZ()) < 4 && player.getName() != Player.getName()) {
                        this.shouldAttack = true
                        this.player = player

                        let yawChange = degreeRanngeRaw(player.getX(), player.getY() + 1.5, player.getZ())
                        let pitchChange = rotaPitchRangeRaw(player.getX(), player.getY() + 1.5, player.getZ())
                        serversideRotations.setAngles(Player.getPlayer().field_70177_z + yawChange, Player.getPlayer().field_70125_A + pitchChange)
                        this.attackPlayer(this.player)
                        found = true
                        break
                    }
                }
                if(!found) {
                    serversideRotations.reset()
                }
            }
        })

        register("worldUnload", () => {
            if(this.toggle) this.toggleMacro()
        })

        register("packetSent", (packet,event) => {
            if(!this.shouldAttack) return
            this.shouldAttack = false
        }).setPacketClasses([net.minecraft.network.play.client.C03PacketPlayer])
    }

    toggleMacro() {
        this.toggle = !this.toggle
        if(this.toggle) {
            ChatLib.chat(polarPrefix + "Kill Aura: " + this.toggle)
        } else {
            this.shouldAttack = false
            serversideRotations.reset()
            ChatLib.chat(polarPrefix + "Kill Aura: " + this.toggle)
        }
    }

    attackPlayer(player) {
        Player.getPlayer().func_71038_i()
        //if(Math.random() > 0.6) {
            mc.field_71442_b.func_78764_a(Player.getPlayer(), player.getEntity())
        //}
    }
}

global.exports.killAura = new killAura()