let {keyBind} = global.exports
let { finder } = global.exports
let { BP, C09PacketHeldItemChange, checkMiningSpeed, mc, polarPrefix, sendPacket, setting } = global.exports

const configQolSwap = new global.configModuleClass(
    "Qol Swap",
    "Combat",
    false,
    [
        new global.settingToggle("Activate on Click", false),
        new global.settingSlider("Swap Delay", 50, 1, 300),
        new global.settingSlider("Slot item 1", 0, 0, 8),
        new global.settingSlider("Slot item 2", 0, 0, 8),
        new global.settingSlider("Slot item 3", 0, 0, 8)
    ],
    [
        "&bQol Swap",
        "Swap's between set hotbar slots very fast, 0 mean that it doens't get included in the swap"
    ]
)

global.modules.push(configQolSwap)

let vGuiContainer = Java.type("net.minecraft.client.gui.inventory.GuiContainer").class
let vSlot = Java.type("net.minecraft.inventory.Slot").class

class qolSwapClass {
    constructor() {

        this.configName = "Qol Swap"

        this.lastSwap = new Date().getTime()

        this.doneSwap = true

        this.lastSoulSwap = new Date().getTime()


        keyBind.keyBindQolSwap.registerKeyPress(() => {this.swap()})

        register("clicked",(mouseX, mouseY, button, isButtonDown) => {
            if(Client.currentGui.getClassName().toString() != "null") return
            if(global.exports.settingGet.getSetting(this.configName,"Activate on Click") && isButtonDown && button === 0.0) {
                this.swap()
            }
        })

        // register("clicked",(mouseX, mouseY, button, isButtonDown) => {
        //     if(Client.currentGui.getClassName().toString() != "null") return
        //     if(/*setting("Combat","Soul Whip Swap") &&*/ isButtonDown && button === 2.0) {
        //         this.soulSwap()
        //     }
        // })
    }

    // soulSwap() {
    //     if(new Date().getTime() - this.lastSoulSwap > 300) {
    //             this.lastSoulSwap = new Date().getTime()
    //             finder.soulWhip()
    //             if(finder.slotSoulWhip != false) {
    //                 ChatLib.chat(Player.getPlayer().field_71070_bA.field_75152_c)
    //                 //ChatLib.chat()
    //                 mc.field_71442_b.func_78753_a(Player.getPlayer().field_71070_bA.field_75152_c, finder.slotSoulWhip, mc.field_71439_g.field_71071_by.field_70461_c, 2, mc.field_71439_g)
    //                 sendPacket(new C08PacketPlayerBlockPlacement(Player.getHeldItem()))
    //                 mc.field_71442_b.func_78753_a(Player.getPlayer().field_71070_bA.field_75152_c, finder.slotSoulWhip, mc.field_71439_g.field_71071_by.field_70461_c, 2, mc.field_71439_g)
    //             } else {
    //                 ChatLib.chat(polarPrefix + " Didn't find your Soul Whip >:(")
    //             }
    //     }
    // }

    swap() {
        if((new Date().getTime() - this.lastSwap > 500) && !this.doneSwap) return
        //ChatLib.chat("swapped")
        let slot1 = (global.exports.settingGet.getSetting(this.configName,"Slot item 1") - 1)
        let slot2 = (global.exports.settingGet.getSetting(this.configName,"Slot item 2") - 1)
        let slot3 = (global.exports.settingGet.getSetting(this.configName,"Slot item 3") - 1)
        let delay = global.exports.settingGet.getSetting(this.configName,"Swap Delay")
        new Thread(() => {
            this.doneSwap = false
            let currentSlot = Player.getHeldItemIndex()
            //let used = false
            if(slot1 > -1) {
                //ChatLib.chat("swap 1")
                //if(currentSlot != slot1 || !used) 
                try {
                    Thread.sleep(delay)
                    sendPacket(new C09PacketHeldItemChange(slot1));
                    sendPacket(new net.minecraft.network.play.client.C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(slot1).getItemStack(), 0, 0, 0))
                } catch(e) {
                    ChatLib.chat(polarPrefix + " Didn't find an Item in Slot: " + (slot1 + 1))
                }
                //used = true
            }

            if(slot2 > -1) {
                //ChatLib.chat("swap 2")
                //if(currentSlot != slot2 || !used) 
                try {
                    Thread.sleep(delay)
                    sendPacket(new C09PacketHeldItemChange(slot2));
                    sendPacket(new net.minecraft.network.play.client.C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(slot2).getItemStack(), 0, 0, 0))
                } catch(e) {
                    ChatLib.chat(polarPrefix + " Didn't find an Item in Slot: " + (slot2 + 1))
                }
                ///used = true
            }

            if(slot3 > -1) {
                //ChatLib.chat("swap 3")
                //if(currentSlot != slot3 || !used) 
                try {
                    Thread.sleep(delay)
                    sendPacket(new C09PacketHeldItemChange(slot3));
                    sendPacket(new net.minecraft.network.play.client.C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(slot3).getItemStack(), 0, 0, 0))
                } catch(e) {
                    ChatLib.chat(polarPrefix + " Didn't find an Item in Slot: " + (slot3 + 1))
                }
                //used = true
            }
            //if(used)
            if(Player.getHeldItemIndex() === currentSlot) {
                Thread.sleep(delay)
                sendPacket(new C09PacketHeldItemChange(currentSlot));
            }
            this.doneSwap = true
        }).start()
    }
}

global.exports.qolSwap = new qolSwapClass()