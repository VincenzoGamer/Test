let { setting, BP, ArrayLists } = global.exports
let { keyBind } = global.exports

const configGhostBlocks = new global.configModuleClass(
    "Ghost Blocks",
    "Dungeons",
    false,
    [
        new global.settingToggle("Non removeable Ghost Blocks", false),
        new global.settingSelector("Creation Speed", 0, [
            "Semi",
            "Normal",
            "Speedy"
        ], false)
    ],
    [
        "&bGhost Blocks",
        "Creates Ghost Blocks where you are looking at"
    ]
)

global.modules.push(configGhostBlocks)

class ghostBlock {
    constructor() {

        this.configName = "Ghost Blocks"

        this.whitelist = new ArrayLists

        this.removeable = false//setting("Dungeons","Non removeable ghost blocks")

        this.cooldown = 0
        this.settingType = "Semi"

        register("Tick", () => {
            this.cooldown += 1
            if(this.cooldown === 20) {
                this.cooldown = 0
                this.settingType = global.exports.settingGet.getSetting(this.configName,"Creation Speed")
            }
        })

        register("step", () => {
            if(keyBind.keyBindGhostBlock.isKeyDown() && this.settingType === "Speedy") this.ghostBlocks()
        })

        keyBind.keyBindGhostBlock.registerKeyDown(() => {
            if(this.settingType === "Normal") this.ghostBlocks()
        })

        keyBind.keyBindGhostBlock.registerKeyPress(() => {
            if(this.settingType === "Semi") this.ghostBlocks()
        })

        register("worldLoad", () => {
            this.whitelist = new ArrayLists
        })

        register("step", () => {
            this.removeable = global.exports.settingGet.getSetting(this.configName,"Non removeable Ghost Blocks")
        }).setFps(1)

        register("packetReceived", (packet, event) => {
            if(this.whitelist.contains(packet.func_179827_b()) && this.removeable) cancel(event)
        }).setPacketClasses([net.minecraft.network.play.server.S23PacketBlockChange])
    }

    ghostBlocks() {
        let lookingAt = Player.lookingAt();
        if (lookingAt.getClass() === Block) {
            if (![
                "minecraft:lever",
                "minecraft:stone_button",
                "minecraft:chest",
                "minecraft:trapped_chest",
                "minecraft:skull",
                "minecraft:command_block",
                "minecraft:hopper"
            ].includes(lookingAt.type.getRegistryName())) {
                let pos = new BP(lookingAt.getX(), lookingAt.getY(), lookingAt.getZ());
                World.getWorld().func_175698_g(pos);
                this.whitelist.add(pos);
            }
        }
    }
}

global.exports.ghostBlocks = new ghostBlock()