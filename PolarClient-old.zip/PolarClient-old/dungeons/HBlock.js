let { keyBind } = global.exports
let { polarPrefix, BP, mc} = global.exports
let { fillJavaArray } = global.exports
let { toBlockPos } = global.exports

let ghostBlockExclude = fillJavaArray(["minecraft:lever","minecraft:stone_button","minecraft:chest","minecraft:trapped_chest","minecraft:skull","minecraft:command_block","minecraft:hopper","minecraft:fence","minecraft:air"])

class HBlock {
    constructor() {

        this.toggle = false
        this.ghostedBlocks = []
        this.ghostedPos = []

        register("Tick", () => {
            if(this.toggle) {
                this.callCords()
                for(let x = -2; x < 3; x++) {
                    for(let z = -2; z < 3; z++) {
                        for(let y = 0; y < 2; y++) {
                            let block = World.getBlockAt(this.plX + x, this.plY + y, this.plZ + z)
                            let registerName = block.type.getRegistryName()
                            if(!ghostBlockExclude.contains(registerName)) {
                                let pos = toBlockPos(block)
                                this.ghostedBlocks.push(block.getState())
                                this.ghostedPos.push(pos)
                                World.getWorld().func_175698_g(pos);
                            }
                        }
                    }
                }
            }
        })

        keyBind.keyBindHBlock.registerKeyPress(() => {this.toggleMacro()})
    }

    toggleMacro() {
        this.toggle = !this.toggle
        if(this.toggle) {
            ChatLib.chat(polarPrefix + " HBlock: " + this.toggle)
        } else {
            this.reStoreBlocks()
            ChatLib.chat(polarPrefix + " HBlock: " + this.toggle)
        }
    }

    reStoreBlocks() {
        for(let i = 0; i < this.ghostedBlocks.length; i++) {
            if(this.ghostedBlocks[i] != undefined && this.ghostedPos[i] != undefined) {
                World.getWorld().func_180501_a(this.ghostedPos[i], this.ghostedBlocks[i], 2)
            }
        }
        this.ghostedBlocks = []
        this.ghostedPos = []
    }

    callCords() {
        this.plX = Math.floor(Player.getX())
        this.plY = Math.ceil(Player.getY())
        this.plZ = Math.floor(Player.getZ())
    }
}

global.exports.hBlock = new HBlock()