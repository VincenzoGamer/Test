let { keyBind } = global.exports
let { polarPrefix, BP, mc } = global.exports
let { toBlockPos, disToPly } = global.exports

class VBlock {
    constructor() {
        keyBind.keyBindVBlock.registerKeyPress(() => {this.doVBlock()})
    }

    doVBlock() {
        this.callCords()
        this.direction()
        ChatLib.chat(polarPrefix + " VBlock: done")
        let stairs = []
        for(let x = -10; x < 11; x++) {
            for(let z = -10; z < 11; z++) {
                let array = [this.plX + x, this.plY, this.plZ + z]
                if(World.getBlockAt(array[0], array[1], array[2]).toString().includes("stair") && World.getBlockAt(this.plX, this.plY, this.plZ).toString().includes("wall") === false) {
                    stairs.push(array)
                }
            }
        }

        let closest = undefined
        for(let i = 0; i < stairs.length; i++) {
            if(closest === undefined) {
                closest = stairs[i]
            } else if(disToPly(stairs[i][0] + 0.5, stairs[i][1] + 0.5, stairs[i][2] + 0.5) < disToPly(closest[0] + 0.5, closest[1] + 0.5, closest[2] + 0.5)) {
                closest = stairs[i]
            }
        }

        if(closest != undefined) {
            this.create(closest[0], closest[2], true)
        } else {
            this.create(this.plX, this.plZ, false)
        }
    }

    create(x,z,first) {
        for(let i = 0; i < 9; i++) {
            if(!first) {
                // let yp = new BlockType(85)
                // World.getWorld().func_180501_a(toBlockPos(World.getBlockAt(x,Math.floor(Player.getY()) + 2,z)),yp.getDefaultState(),2)
                let pos = new BP(x, Math.floor(Player.getY()) - i - 1, z)
                if(mc.field_71441_e.func_180495_p(pos).func_177230_c().toString() === "Block{minecraft:air}") {
                    let pos2 = new BP(x, Math.floor(Player.getY()) - i - 2, z)
                    if(mc.field_71441_e.func_180495_p(pos2).func_177230_c().toString() === "Block{minecraft:air}") {
                        break
                    }
                } else {
                    World.getWorld().func_175698_g(pos);
                }
            } else {
                let yp = new BlockType(85)
                if(this.playerDirection === "West" || this.playerDirection === "East") {
                    World.getWorld().func_180501_a(toBlockPos(World.getBlockAt(x,Math.floor(Player.getY()) + 2,z + 1)),yp.getDefaultState(),2)
                    World.getWorld().func_180501_a(toBlockPos(World.getBlockAt(x,Math.floor(Player.getY()) + 2,z - 1)),yp.getDefaultState(),2)
                    // World.getWorld().func_180501_a(toBlockPos(World.getBlockAt(x,Math.floor(Player.getY() - 1) + 2,z + 1)),yp.getDefaultState(),2)
                    // World.getWorld().func_180501_a(toBlockPos(World.getBlockAt(x,Math.floor(Player.getY() - 1) + 2,z - 1)),yp.getDefaultState(),2)
                } else {
                    World.getWorld().func_180501_a(toBlockPos(World.getBlockAt(x + 1,Math.floor(Player.getY()) + 2,z)),yp.getDefaultState(),2)
                    World.getWorld().func_180501_a(toBlockPos(World.getBlockAt(x - 1,Math.floor(Player.getY()) + 2,z)),yp.getDefaultState(),2)
                    // World.getWorld().func_180501_a(toBlockPos(World.getBlockAt(x + 1,Math.floor(Player.getY() - 1) + 2,z)),yp.getDefaultState(),2)
                    // World.getWorld().func_180501_a(toBlockPos(World.getBlockAt(x - 1,Math.floor(Player.getY() - 1) + 2,z)),yp.getDefaultState(),2)
                }
                World.getWorld().func_180501_a(toBlockPos(World.getBlockAt(x,Math.floor(Player.getY()) + 2,z)),yp.getDefaultState(),2)
                let pos = new BP(x, Math.floor(Player.getY()) - i, z)
                if(mc.field_71441_e.func_180495_p(pos).func_177230_c().toString() === "Block{minecraft:air}") {
                    let pos2 = new BP(x, Math.floor(Player.getY()) - i - 1, z)
                    if(mc.field_71441_e.func_180495_p(pos2).func_177230_c().toString() === "Block{minecraft:air}") {
                        break
                    }
                } else {
                    World.getWorld().func_175698_g(pos);
                }
            }
        }
    }

    direction() {
        let plyYaw = Player.getYaw()
        if(plyYaw > 135 || plyYaw < -135) {
            this.playerDirection = "North"
        } else if(plyYaw > -135 && plyYaw < -45) {
            this.playerDirection = "East"
        } else if(plyYaw > -45 && plyYaw < 35) {
            this.playerDirection = "South"
        } else if(plyYaw > 35 && plyYaw < 135) {
            this.playerDirection = "West"
        }
    }

    callCords() {
        this.plX = Math.floor(Player.getX())
        this.plY = Math.floor(Player.getY())
        this.plZ = Math.floor(Player.getZ())
    }
}

global.exports.vBlock = new VBlock()