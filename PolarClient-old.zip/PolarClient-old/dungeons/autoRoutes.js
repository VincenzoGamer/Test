let { polarPrefix } = global.exports
import RenderLib from "RenderLib";

class autoRoute {
    constructor() {
        this.toggle = false

        this.bottem = undefined

        this.lmaoX = []
        this.lmaoZ = []

        register("Tick", () =>[
            this.callCords()
        ])
        register("Command", () => {
            ChatLib.chat(this.gettingBottem())
            this.gettingCorners()
        }).setName("autoroute")

        register("RenderWorld", () => {
            //if(this.lmaoX != undefined) {
                for(let i = 0; i < this.lmaoX.length; i++) {
                    RenderLib.drawBaritoneEspBox(this.lmaoX[i], this.bottem, this.lmaoZ[i], 1, 1, 0, 0, 0, 1, true)
                }
            //}
        })

        // register("packetSent", (packet, event) => {
        //     if(packet instanceof net.minecraft.network.play.client.C0FPacketConfirmTransaction) return
        //     ChatLib.chat(packet.class.getSimpleName())
        // })//.setPacketClasses([net.minecraft.network.play.client.C0CPacketInput])
    }

    gettingCorners() {
        let startX = this.plx
        let startZ = this.plz
        if(this.bottem != undefined) {
            let amount = 0
            let found = false
            while(!found) {
                if(World.getBlockAt(startX - 1, this.bottem, startZ).type.getID() === 7.0) {
                    amount += 1
                }
                if(World.getBlockAt(startX + 1, this.bottem, startZ).type.getID() === 7.0) {
                    amount += 1
                }
                if(World.getBlockAt(startX, this.bottem, startZ - 1).type.getID() === 7.0) {
                    amount += 1
                }
                if(World.getBlockAt(startX, this.bottem, startZ + 1).type.getID() === 7.0) {
                    amount += 1
                }

                if(amount < 3) {
                    ChatLib.chat(startX + "," + this.bottem + "," + startZ)
                    this.lmaoX.push(startX)
                    this.lmaoZ.push(startZ)
                    found = true
                } else {
                    ChatLib.chat("no")
                    amount = 0
                    startX += 1
                }
            }
        }
    }

    gettingBottem() {
        for(let y = 0; y < 70; y++) {
            if(World.getBlockAt(this.plx, this.ply - y, this.plz).type.getID() === 7.0) {

                let found = false
                let blocks = false
                if(World.getBlockAt(this.plx, this.ply - y, this.plz).type.getID() === 7.0) {
                    blocks = true
                }

                if(blocks) {
                    for(let i = 0; i < 20; i++) {
                        if(World.getBlockAt(this.plx, this.ply - y - i, this.plz).type.getID() != 0.0 && World.getBlockAt(this.plx, this.ply - y - i, this.plz).type.getID() != 7.0) {
                            found = true
                            break
                        }
                    }

                    if(!found) {
                        ChatLib.chat(/*this.plx + "," + */this.ply - y/* + "," + this.plz*/)
                        this.bottem = this.ply - y
                        return true
                    }
                }
            }
        }

        return false
    }

    toggleMacro() {
        this.toggle = !this.toggle
        if(this.toggle) {
            ChatLib.chat(polarPrefix + " Auto Routes: " + this.toggle)
        } else {
            ChatLib.chat(polarPrefix + " Auto Routes: " + this.toggle)
        }
    }

    callCords() {
        this.ply = Math.floor(Player.getY())
        this.plx = Math.floor(Player.getX())
        this.plz = Math.floor(Player.getZ())
    }
}

global.exports.autoRoutes = new autoRoute()