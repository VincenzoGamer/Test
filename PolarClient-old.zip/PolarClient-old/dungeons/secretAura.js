import RenderLib from "RenderLib";
let {keyBind} = global.exports
let { BP, polarPrefix, mc, ArrayLists, EnumFacing, sendPacket, C09PacketHeldItemChange, setting, dungeonFloor} = global.exports
let { toPosBlock } = global.exports

const configSecretAura = new global.configModuleClass(
    "Secret Aura",
    "Dungeons",
    false,
    [
        new global.settingSlider("Click Slot", 1, 1, 8),
    ],
    [
        "&bSecret Aura",
        "Gets Secrets around you without even looking at them"
    ]
)

global.modules.push(configSecretAura)

let BlockLever = Java.type("net.minecraft.block.BlockLever");

class secretAuraClass {
    constructor() {

        this.configName = "Secret Aura"

        this.toggle = false

        this.whitelist = new ArrayLists
        this.cooldown = 0

        register("tick", () => {
            if(this.toggle) {
                if(Player.getContainer().getName() === "Chest" || Player.getContainer().getName() === "Large Chest") {
                    Client.currentGui.close();
                }
                this.cooldown += 1
                if(this.cooldown === 3) {
                    this.scanDungeons()
                    this.cooldown = 0
                }
            }
        })

        register("worldLoad", () => {
            if(this.toggle) {this.toggleMacro()}
        })

        keyBind.keyBindSecretAura.registerKeyPress(() => {this.toggleMacro()})

        register("renderWorld", () => {
            if(this.toggle) {
                if(this.block === undefined) return
                RenderLib.drawInnerEspBox(this.block.getX() + 0.5, this.block.getY(), this.block.getZ() + 0.5, 1, 1, 0, 0, 1, 1, true)
            }
        })
    }

    scanDungeons() {
        this.block = undefined
        let pos = this.lever()
        if(pos === undefined) {pos = this.tileEntities()}
        if(pos === undefined) return
        this.whitelist.add(pos)
        //ChatLib.chat(polarPrefix + " Clicked At: " + pos)

        let currentItem = Player.getHeldItemIndex()
        sendPacket(new C09PacketHeldItemChange((global.exports.settingGet.getSetting(this.configName,"Click Slot") - 1)))
        mc.field_71442_b.func_178890_a(Player.getPlayer(), World.getWorld(), mc.field_71439_g.field_71071_by.func_70448_g(), pos, EnumFacing.func_176733_a(mc.field_71439_g.field_70177_z), new net.minecraft.util.Vec3(0.0, 0.0, 0.0));
        sendPacket(new C09PacketHeldItemChange(currentItem))
        this.block = toPosBlock(pos)
    }

    lever() {
        let plyX = Player.getX(); let plyY = Player.getY(); let plyZ = Player.getZ()
        for(let x = plyX - 6; x < plyX + 6; x++) {
            for(let y = plyY - 6; y < plyY + 6; y++) {
                for(let z = plyZ - 6; z < plyZ + 6; z++) {
                    let pos = new BP(x,y,z);
                    let block = mc.field_71441_e.func_180495_p(pos).func_177230_c();
                    if(mc.field_71439_g.func_70011_f(pos.func_177958_n(), pos.func_177956_o() - mc.field_71439_g.func_70047_e(), pos.func_177952_p()) < 4.5 && !this.whitelist.contains(pos)) {
                        if(block instanceof BlockLever) {
                            return pos
                        }
                    }
                }
            }
        }
        return undefined
    }

    tileEntities() {
        let listChests = World.getAllTileEntitiesOfType(net.minecraft.tileentity.TileEntityChest)

        //ChatLib.chat(listChests.length)
        for(let i = 0; i < listChests.length; i++) {
            let pos = new BP(listChests[i].getX(),listChests[i].getY(),listChests[i].getZ())
            if(!this.whitelist.contains(pos) && mc.field_71439_g.func_70011_f(pos.func_177958_n(), pos.func_177956_o() - mc.field_71439_g.func_70047_e(), pos.func_177952_p()) < 4.5) {
                return pos
            }
        }

        let listSkulls = World.getAllTileEntitiesOfType(net.minecraft.tileentity.TileEntitySkull)

        for(let i = 0; i < listSkulls.length; i++) {
            let pos = new BP(listSkulls[i].getX(),listSkulls[i].getY(),listSkulls[i].getZ())
            if(!this.whitelist.contains(pos) && mc.field_71439_g.func_70011_f(pos.func_177958_n(), pos.func_177956_o() - mc.field_71439_g.func_70047_e(), pos.func_177952_p()) < 4.5) {
                let property = listSkulls[i].tileEntity?.func_152108_a()?.getProperties()?.get("textures");
                if(property != undefined) {
                    if(property[0].value === "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzRkYjRhZGZhOWJmNDhmZjVkNDE3MDdhZTM0ZWE3OGJkMjM3MTY1OWZjZDhjZDg5MzQ3NDlhZjRjY2U5YiJ9fX0=") {
                        return pos
                    }
                }
            }
        }

        return undefined
    }

    toggleMacro() {
        this.toggle = !this.toggle
        if(this.toggle) {
            if(dungeonFloor() != undefined) {
                this.whitelist = new ArrayLists
                ChatLib.chat(polarPrefix + " Secret Aura: " + this.toggle)
            } else {
                this.toggle = false
                ChatLib.chat(polarPrefix + " You are not in a dungeon")
            }
        } else {
            ChatLib.chat(polarPrefix + " Secret Aura: " + this.toggle)
        }
    }
}

global.exports.secretAura = new secretAuraClass()