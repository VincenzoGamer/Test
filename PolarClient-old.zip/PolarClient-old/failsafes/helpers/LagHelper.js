let { TimeHelper } = global.export

// TODO improve this
class LagHelper {
    constructor() {
        this.lagTimer = new TimeHelper()
        this.LAG_THRESHOLD = 400

        register("packetReceived", () => this.lagTimer.reset()) //.setFilteredClass(net.minecraft.network.play.server.S03PacketTimeUpdate)
    }

    isLagging() {
        return this.lagTimer.hasReached(this.LAG_THRESHOLD)
    }   
}

global.export.LagHelper = new LagHelper()