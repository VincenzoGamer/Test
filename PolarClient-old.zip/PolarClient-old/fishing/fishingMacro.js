let { keyBind } = global.exports
import RenderLib from "RenderLib";
let { disFrToFr, disToPly, disToPlyFlat } = global.exports
let { polarPrefix, mc, cancelWalk, setYaw, setPitch, WalkBackward, WalkForward, WalkLeft, WalkRight, Shift, WalkJump, Attack } = global.exports
let { lookAt, lookAt2, lookAtRightClick, lookAtHori } = global.exports
let { degreeRannge } = global.exports
let { finder, RClickItem } = global.exports


let LClick = mc.getClass().getDeclaredMethod("func_147116_af")
LClick.setAccessible(true)

// let EntityFishingBobber = Java.type("net.minecraft.entity.projectile.EntityFishHook")
// let EntityMagmeCube = Java.type("net.minecraft.entity.monster.EntityMagmaCube")
// let EntitySlime = Java.type("net.minecraft.entity.monster.EntitySlime")
// let EntityPlayer = Java.type("net.minecraft.entity.player.EntityPlayer")

let fishingMobs = [
    net.minecraft.entity.monster.EntityIronGolem,
    net.minecraft.entity.monster.EntitySilverfish,
    net.minecraft.entity.monster.EntityZombie,
    net.minecraft.entity.monster.EntitySkeleton,
    net.minecraft.entity.monster.EntityGuardian,
    net.minecraft.entity.passive.EntityOcelot,
    net.minecraft.entity.monster.EntityWitch,
    net.minecraft.entity.passive.EntitySquid,
    net.minecraft.entity.passive.EntityChicken
]

// let EntityFishingBobber = Java.type("net.minecraft.entity.projectile.EntityFishHook")
// let fishX = EntityFishingBobber.getDeclaredField("field_146056_aC")
// fishX.setAccessible(true)

const configFishingMacro = new global.configModuleClass(
    "Fishing Macro",
    "Fishing",
    false,
    [
        new global.settingSlider("Weapon Slot", 1, 1, 8),
        new global.settingSelector("Fishing Location", 0,[
            "Hub - The Park Birch"
        ], false),
        new global.settingToggle("Right Click Attack", false),
        new global.settingToggle("Hyperion Mode", false),
        new global.settingToggle("Use particle detection", true),
        new global.settingToggle("Use sound detection", true)
    ],
    [
        "&bFishing Macro",
        "Macro's Fishing in the Hub",
        "Requirements: Rod, Weapon, Etherwarp"
    ]
)

global.modules.push(configFishingMacro)

class fishing {
    constructor() {

        this.configName = "Fishing Macro"

        this.ParkBirch = [
            ["left",-10.5,undefined,false,[-180.0,0.0]],
            ["forward",undefined,-47,true,[0.0,0.0]],
            [-38.5,70,-47.5],
            ["forward",-100,undefined,false,[75.0,0.0]],
            ["forward",-130,undefined,false,[90.0,0.0]],
            ["left",undefined,-28,true,[90.0,0.0]],
            ["forward",-204,undefined,false,[-211.5,75,-21.5]],
            [-222.5,73,-23.5],
            [-274.5,86,-6.5],
            [-282.5,83,-22.5],
            [-283.5,81,-32.5]
        ]
        this.walkingPos = 0

        this.lastTime = Date.now()

        this.toggle = false

        this.toggleFishing = false

        this.goingToSpot = false

        this.aotvClick = false

        this.attacking = false
        this.throw = false

        this.click = false

        this.up = true
        this.amountChangeYaw = 0
        this.amountChangePitch = 0

        this.walkAfk = false

        keyBind.keyBindFishingMacro.registerKeyPress(() => {this.toggleMacro()})

        register("step", () => {
            if(this.mob != undefined && !this.hyperionMode) {
                lookAt2(this.mob.getX(), this.mob.getY() + 1, this.mob.getZ(), 150, false, false)
            }
        }).setFps(6)

        register("step", () => {
            if(this.toggleFishing && this.closest != undefined) {
                if(Math.random() > 0.95) {
                    this.up = !this.up
                    if(this.up) {
                        this.amountChangeYaw = Math.random() * 2 - Math.random()
                        this.amountChangePitch = Math.random() * 1.5 - Math.random()
                        Player.getPlayer().field_70177_z += this.amountChangeYaw
                        Player.getPlayer().field_70125_A += this.amountChangePitch
                    } else {
                        Player.getPlayer().field_70177_z -= this.amountChangeYaw
                        Player.getPlayer().field_70125_A -= this.amountChangePitch
                    }
                }
            }
        }).setFps(5)

        register("Tick", () => {
            if(!this.toggle) return
            this.callCords()
            //code
            if(this.goingToSpot) {
                if(this.walkingPos < this.ParkBirch.length) {
                    if(this.walkingPos === 2.0 || this.walkingPos === 7.0 || this.walkingPos === 8.0 || this.walkingPos === 9.0 || this.walkingPos === 10.0) {
                        if(!this.aotvClick) {

                            let height = 0.5

                            if(this.walkingPos === 10.0) {height = 1}

                            this.cancelMovement()

                            this.aotvClick = true

                            new Thread(() => {
                                Player.setHeldItemIndex(finder.slotWarp)
                                while(this.toggle && (Player.getMotionX() != 0.0 || Player.getMotionZ() != 0.0)) {Thread.sleep(100)}

                                if(this.toggle) {
                                    lookAt(this.ParkBirch[this.walkingPos][0], this.ParkBirch[this.walkingPos][1] + height, this.ParkBirch[this.walkingPos][2], 200, true, true)
                                }

                                while(this.toggle && (Player.getX() != this.ParkBirch[this.walkingPos][0] || (Player.getY() - 1) != this.ParkBirch[this.walkingPos][1] || Player.getZ() != this.ParkBirch[this.walkingPos][2])) {Thread.sleep(100)}

                                if(this.toggle) {
                                    this.walkingPos += 1
                                }

                                this.aotvClick = false
                                //ChatLib.chat("closest")
                                //ChatLib.chat(this.walkingPos)
                            }).start()
                        }
                    }
                    else if(this.walkingAlgoRithem(this.ParkBirch[this.walkingPos])) {
                        this.walkingPos += 1
                        this.aotvClick = false
                    }
                } else {
                    this.goingToSpot = false
                    //this.toggleFishing = true
                    this.cancelMovement()
                    ChatLib.chat(polarPrefix + " Done With Task")

                    this.toggleFishingFunc()
                }
            }

            if(this.toggleFishing) {

                //Detect Entity
                this.mob = this.fishingMob()
                if(this.mob != undefined) {
                    this.click = !this.click
                    this.attacking = true
                    this.throw = false
                    this.startY = undefined
                    this.particleNear = false
                    //lookAt(mob.getX(), mob.getY() + 1.6, mob.getZ(), 50, false, false)
                    if(!this.hyperionMode) {
                        if(this.click) {LClick.invoke(mc)}
                    } else {
                        setPitch(89)
                        //lookAt(this.plyX + 0.5,this.plyY,this.plyZ + 0.5,50,false,false)
                        //ChatLib.chat(Date.now() - this.lastHyperion)
                        if(Date.now() - this.lastHyperion > 1000 && Player.getHeldItemIndex() === (global.exports.settingGet.getSetting(this.configName,"Weapon Slot") - 1)) {
                            //ChatLib.chat("Clicked")
                            this.lastHyperion = Date.now()
                            RClickItem()
                        }
                    }
                } else {
                    this.lastHyperion = (Date.now() - 700)
                    this.attacking = false
                }

                //Item Switching
                if(this.attacking) {
                    Player.setHeldItemIndex(global.exports.settingGet.getSetting(this.configName,"Weapon Slot") - 1)
                    this.pulled = Date.now()
                } else {
                    Player.setHeldItemIndex(finder.slotRod)
                }

                if(this.walkBackToBox(this.ParkBirch[10][0], this.ParkBirch[10][2])) return

                //Fishing
                let mot = Player.getMotionY().toFixed(1)
                //ChatLib.chat(mot)
                if(!this.throw && !this.attacking && (mot === '-0.1' || mot === '0.1') && Player.getMotionX() === 0.0 && Player.getMotionZ() === 0.0 && Player.getHeldItemIndex() === finder.slotRod && Date.now() - this.pulled > 1000) {
                    //ChatLib.chat("thrown")
                    this.throw = true
                    this.startY = undefined
                    this.soundNear = false
                    this.particleNear = false
                    this.lastTime = (Date.now() - 300)
                    this.pulled = (Date.now() - 300)
                    lookAt2(-283.5, 80.2, -34.5, 300, true, false)
                }

                if(this.throw) {
                    let fishingHook = World.getAllEntitiesOfType(net.minecraft.entity.projectile.EntityFishHook)
                    this.closest = undefined
                    for(let i = 0; i < fishingHook.length; i++) {
                        if(fishingHook[i].entity.field_146042_b.toString().includes(Player.getName()) && fishingHook[i].isInWater()) {
                            this.closest = fishingHook[i]
                        }
                    }
                    if(this.closest === undefined && Date.now() - this.lastTime > 3000) {
                        this.lastTime = Date.now()
                        this.startY = undefined
                        this.closest = undefined
                        this.throw = false
                        this.particleNear = false
                        this.soundNear = false
                    }
                }
            }
        })

        register("renderWorld", () => {
            if(this.closest != undefined && this.toggleFishing && this.toggle) {
                RenderLib.drawInnerEspBox(this.closest.getX(), this.closest.getY(), this.closest.getZ(), 0.2, 0.2, 0, 0, 1, 0.3, true)
            }
        })

        register("step", () => {
            if(this.closest != undefined && this.toggleFishing && this.toggle) {

                if(this.startY === undefined && this.closest.getMotionY() < 0.005 && this.closest.getMotionY() > -0.005 && (this.closest.isInLava() || this.closest.isInWater()) && this.throw) {
                    this.startY = this.closest.getY()
                    //ChatLib.chat(this.startY)
                }

                if(this.startY === undefined) return

                //ChatLib.chat(this.startY - this.closest.getY())
                //ChatLib.chat("Moion: " + this.closest.getMotionY())
                if(((this.startY - this.closest.getY()) > 0.17 || (this.startY - this.closest.getY()) < -0.17) && (this.particleNear || !this.particleDetection) && (Date.now() - this.lastTime > 1000) && (this.soundNear || !this.soundeDetection)) {
                    RClickItem()
                    this.startY = undefined
                    this.closest = undefined
                    this.throw = false
                    this.particleNear = false
                    this.soundNear = false
                    this.pulled = Date.now()
                }
            }
        }).setFps(100)

        register("soundPlay", (pos,name,volume,pitch,catacory,event) => {
            //if(!this.toggle) return
            if(!this.toggleFishing) return
            if(!this.particleNear) return
            if(this.closest === undefined) return
            let nam = name.toString()
            if(nam == "game.neutral.swim.splash" || nam == "game.player.swim.splash") {
                if(disFrToFr(this.closest.getX(), this.closest.getY(), this.closest.getZ(), pos.getX(), pos.getY(), pos.getZ()) < 2) {
                    this.soundNear = true
                    //ChatLib.chat("near")
                }
            }
        })

        register("spawnParticle", (particle, Type, event) => {
            if(!this.toggle || !this.toggleFishing || this.closest === undefined) return
                if(Type.toString() === "WATER_WAKE" && this.closest.isInWater() && disFrToFr(particle.getX(), particle.getY(), particle.getZ(), this.closest.getX(), this.closest.getY(), this.closest.getZ()) < 2) {
                    this.particleNear = true
                }
        })
    }

    toggleMacro() {
        this.toggle = !this.toggle
        if(this.toggle) {
            if(finder.rod() && finder.etherwarp()) {
                ChatLib.chat(polarPrefix + " Fishing Macro: " + this.toggle)
                ChatLib.say("/warp hub")

                this.walkingPos = 0
                this.goingToSpot = false
                this.walkAfk = false
                this.hyperionMode = global.exports.settingGet.getSetting(this.configName,"Hyperion Mode")
                this.particleDetection = global.exports.settingGet.getSetting(this.configName,"Use particle detection")
                this.soundeDetection = global.exports.settingGet.getSetting(this.configName,"Use sounds detection")
                new Thread(() => {
                    while((Player.getX() != -2.5 || Player.getY() != 70.0 || Player.getZ() != -69.5) && this.toggle) {Thread.sleep(500)}
                    if(this.toggle) {this.goingToSpot = true}
                }).start()
            } else {
                ChatLib.chat(polarPrefix + " Fishing Macro: Requirements")
                ChatLib.chat("- Rod")
                ChatLib.chat("- Etherwarp")
                this.toggle = false
            }
        } else {

            this.cancelMovement()

            if(this.toggleFishing) {
                this.toggleFishingFunc()
            }

            ChatLib.chat(polarPrefix + " Fishing Macro: " + this.toggle)
        }
    }

    toggleFishingFunc() {
        this.toggleFishing = !this.toggleFishing
        if(this.toggleFishing) {
            ChatLib.chat(polarPrefix + " Started Fishing")
            this.attacking = false
            this.throw = false
            this.startY = undefined
            this.soundNear = false
            this.particleNear = false
            this.lastWalk = Date.now()
            this.lastHyperion = Date.now()
            this.pulled = Date.now()
        } else {
            ChatLib.chat(polarPrefix + " Stopped Fishing")
            this.mob = undefined
        }
    }

    walkBackToBox(x,z) {
        let found = false
        let plyYaw = Player.getYaw()
        if(plyYaw > 135 || plyYaw < -135) {
            playerDirection = "North"
        } else if(plyYaw > -135 && plyYaw < -45) {
            playerDirection = "East"
        } else if(plyYaw > -45 && plyYaw < 35) {
            playerDirection = "South"
        } else if(plyYaw > 35 && plyYaw < 135) {
            playerDirection = "West"
        }
        let xBorders = [x + 0.3, x - 0.3]
        let zBorders = [z + 0.3, z - 0.3]
        if(Player.getX() > xBorders[0]) {
            found = true
            Shift.setState(true)
            if(playerDirection === "West") {
                cancelWalk('forward')
                //WalkForward.setState(true)
            }
            if(playerDirection === "East") {
                cancelWalk('backward')
                //WalkBackward.setState(true)
            }
            if(playerDirection === "South") {
                cancelWalk('right')
                //WalkRight.setState(true)
            }
            if(playerDirection === "North") {
                cancelWalk('left')
                //WalkLeft.setState(true)          
            }

            this.lastShift = Date.now()
        }
    
        if(Player.getX() < xBorders[1]) {
            found = true
            Shift.setState(true)
            if(playerDirection === "West") {
                cancelWalk('backward')
                //WalkBackward.setState(true)
            }
            if(playerDirection === "East") {
                cancelWalk('forward')
                //WalkForward.setState(true)
            }
            if(playerDirection === "South") {
                cancelWalk('left')
                //WalkLeft.setState(true)
            }
            if(playerDirection === "North") {    
                cancelWalk('right') 
                //WalkRight.setState(true)       
            } 

            this.lastShift = Date.now()
        }
    
        if(Player.getZ() > zBorders[0]) {
            found = true
            Shift.setState(true)
            if(playerDirection === "West") {
                cancelWalk('right')
                //WalkRight.setState(true)
            }
            if(playerDirection === "East") {
                cancelWalk('left')
                //WalkLeft.setState(true)
            }
            if(playerDirection === "South") {
                cancelWalk('backward')
                //WalkBackward.setState(true)
            }
            if(playerDirection === "North") {   
                cancelWalk('forward')
                //WalkForward.setState(true)         
            }

            this.lastShift = Date.now()
        }
    
        if(Player.getZ() < zBorders[1]) {
            found = true
            Shift.setState(true)
            if(playerDirection === "West") {
                cancelWalk('left')
                //WalkLeft.setState(true)
            }
            if(playerDirection === "East") {
                cancelWalk('right')
                //WalkRight.setState(true)
            }
            if(playerDirection === "South") {
                cancelWalk('forward')
                //WalkForward.setState(true)
            }
            if(playerDirection === "North") {  
                cancelWalk('backward')
                //WalkBackward.setState(true)         
            }

            this.lastShift = Date.now()
        }

        if(!found) {
            WalkBackward.setState(false)
            WalkForward.setState(false)
            WalkLeft.setState(false)
            WalkRight.setState(false)
            if(Date.now() - this.lastShift > 1000) {
                Shift.setState(false)
            }
        }

        if(found && !this.attacking && !this.throw) {
            if(this.blockNear()) {
               WalkJump.setState(true)
            } else {
               WalkJump.setState(false)
            }
        } else {
            WalkJump.setState(false)
        }

        if(found && !this.attacking && !this.throw) {
            lookAtHori(x,Player.getY(),z,50)
        }

        if(this.toggleFishing && this.closest != undefined && !found) {
            if(Math.random() > 0.99 || Date.now() - this.lastWalk > 20000) {
                this.lastWalk = Date.now()
                this.lastShift = Date.now()
                //ChatLib.chat("WALK")
                if(Math.random() > 0.5) {
                        Shift.setState(true)
                        WalkRight.setState(true)
                } else {
                        Shift.setState(true)
                        WalkLeft.setState(true)
                }
            } else if(Math.random() > 0.996) {
                new Thread(() => {
                    Attack.setState(true)
                    Thread.sleep(1000)
                    Attack.setState(false)
                }).start()
            }
        }

        return found
    }

    blockNear() {
        this.callCords()
        for(let x = -2; x < 1; x++) {
            for(let z = -1; z < 2; z++) {
                for(let y = 0; y < 1; y++) {
                    let block = World.getBlockAt(this.plyX + x, this.plyY + y, this.plyZ + z )
                    if(degreeRannge(this.plyX + x + 0.5, this.plyY + y + 0.5, this.plyZ + z + 0.5) < 60 && block.type.getID() != 0.0 && block.type.getID() != 31.0 && disToPlyFlat(this.plyX + x + 0.5, this.plyZ + z + 0.5) < 1) return true
                }
            }
        }
    }

    fishingMob() {
        let mobs = World.getAllEntities()
        for(let i = 0; i < mobs.length; i++) {
            if(this.instanceOfClass(fishingMobs, mobs[i].entity) && disToPly(mobs[i].getX(), mobs[i].getY(), mobs[i].getZ()) < 4.5 /*&& mobs[i].entity.func_110143_aJ() > 1.1*/) {
                return mobs[i]
            }
        }
        return undefined
    }


    instanceOfClass(array, entity) {
        for(let i = 0; i < array.length; i++) {
            if(entity instanceof array[i]) {
                return true
            }
        }
        return false
    }

    cancelMovement() {
        WalkBackward.setState(false)
        WalkForward.setState(false)
        WalkLeft.setState(false)
        WalkRight.setState(false)
    }

    walkingAlgoRithem(instructions) {
        let direction = instructions[0]
        let x = instructions[1]
        let z = instructions[2]
        let biggerThen = instructions[3]
        let array = instructions[4]
        //walkDirection.direction

        cancelWalk(direction)

        if(array != undefined) {
            if(array[2] != undefined) {
                lookAt(array[0],array[1],array[2], 50, false, false)
            } else {
                setYaw(array[0])
                setPitch(array[1])
            }
        }

        if(x != undefined) {
            if(biggerThen) {
                if(Player.getX() > x) {
                    return true
                } else {
                    return false
                }
            } else {
                if(Player.getX() < x) {
                    return true
                } else {
                    return false
                }
            }
        } else if(z != undefined) {
            if(biggerThen) {
                if(Player.getZ() > z) {
                    return true
                } else {
                    return false
                }
            } else {
                if(Player.getZ() < z) {
                    return true
                } else {
                    return false
                }
            }
        }
    }

    callCords() {
        this.plyX = Math.floor(Player.getX())
        this.plyY = Math.floor(Player.getY())
        this.plyZ = Math.floor(Player.getZ())
    }
}

global.exports.fishingMacro = new fishing()