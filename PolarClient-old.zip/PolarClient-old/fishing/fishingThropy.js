import request from "requestV2"
let { polarPrefix } = global.exports

class thropyFisher {
    constructor() {
        this.trophy

        this.toggle = false

        register("command", () => {
            this.onFishApi()
        }).setName("trophy")
    }

    toggleMacro() {
        this.toggle = !this.toggle
        if(this.toggle) {
            ChatLib.chat(polarPrefix + " Trophy Fisher: " + this.toggle)
        } else {
            ChatLib.chat(polarPrefix + " Trophy Fisher: " + this.toggle)
        }
    }

    onFishApi() {
        let url = "https://sh.noms.tech/v1/profiles/" + this.trimUUID(Player.getUUID())
        request({
            url: url,
            method: "GET",
            headers: {
                'Content-type': 'application/json',
                "User-Agent":"Mozilla/5.0",
                'Authorization': "alwin_kuipers"
            }
        })
            .then(function(response) {
                let object = JSON.parse(response)
                ChatLib.chat(object.data[0].trophy_fish.fish.BLOBFISH)
            })
            .catch(function(error) {
                ChatLib.chat(error)
            });
    }

    trimUUID(uuid) {
        return uuid.replace(/-/g,'');
    }
}

global.exports.thropyFisher = new thropyFisher()