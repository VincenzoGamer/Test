import RenderLib from "RenderLib";
let { keyBind } = global.exports
let { polarPrefix, ArrayLists, mc, EnumFacing, BP, disToPly} = global.exports

class fairySoul {
    constructor() {

        this.toggle = false

        this.whitelist = new ArrayLists

        keyBind.keyBindFairySoulAura.registerKeyPress(() => {this.toggleMacro()})

        register("tick", () => {
            if(this.toggle) {
                let Entities = World.getAllEntitiesOfType(net.minecraft.entity.item.EntityArmorStand)
                for(let i = 0; i < Entities.length; i++) {
                    let pos = new BP(Math.floor(Entities[i].getX()),Math.floor(Entities[i].getY()),Math.floor(Entities[i].getZ()))
                    if(!this.whitelist.contains(pos) && mc.field_71439_g.func_70011_f(pos.func_177958_n() + 0.5, pos.func_177956_o() - mc.field_71439_g.func_70047_e(), pos.func_177952_p() + 0.5) < 4) {
                        let daEntity = Entities[i].getEntity()
                        let idkReally = daEntity.func_82169_q(3)
                        try {
                            if(!idkReally.func_82833_r().equals("Head")) {
                                continue
                            }
                        } catch(e) {continue}
                        let owner = idkReally.func_179543_a("SkullOwner", false)
                        if(!owner.func_74779_i("Id").equals("57a4c8dc-9b8e-3d41-80da-a608901a6147")) {
                            continue
                        }
                        
                        //click method
                        this.interactWithEntity(daEntity)
                        this.whitelist.add(pos)
                        ChatLib.chat(polarPrefix + " Clicked Fairy Soul")
                        this.current = Entities[i]
                        new Thread(() => {Thread.sleep(200); this.current = undefined}).start()
                    }
                }
            }
        })

        register("renderWorld", () => {
            if(this.current === undefined) return
            RenderLib.drawInnerEspBox(this.current.getX(), this.current.getY() + 1.5, this.current.getZ(), 1, 1, 0, 1, 0, 0.2, true)
        })
    }
 
    toggleMacro() {
        this.toggle = !this.toggle
        if(this.toggle) {
            ChatLib.chat(polarPrefix + " Fairy Soul Aura: " + this.toggle)
            this.whitelist = new ArrayLists
        } else {
            ChatLib.chat(polarPrefix + " Fairy Soul Aura: " + this.toggle)
            this.whitelist = new ArrayLists
        }
    }

    interactWithEntity(entity) {
        let objectMouseOver = Client.getMinecraft().field_71476_x.field_72307_f;
        let dx = objectMouseOver.xCoord - entity.field_70165_t;
        let dy = objectMouseOver.yCoord - entity.field_70163_u;
        let dz = objectMouseOver.zCoord - entity.field_70161_v;
        let vec = new net.minecraft.util.Vec3(dx, dy, dz);
        Client.sendPacket(new net.minecraft.network.play.client.C02PacketUseEntity(entity, vec));
    }
}

global.exports.fairySoulAura = new fairySoul()