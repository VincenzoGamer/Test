import request from "requestV2"
import Font from "FontLib"

const GUI = () => {

    let FolderName = "PolarConfig" // POLAR PLEASE CHANGE THIS RATHER THAN REPLACING EVERY 'FolderName' WITH 'PolarConfig'


    let titlefont = new Font("PolarClient/Assets/Bold.ttf", 50)

    let font = new Font("PolarClient/Assets/SF-Pro-Display-Medium.ttf", 17)

    let version = "1.1.0"

    let config = JSON.parse(FileLib.read(FolderName, "polarconfig.json"))


    let logo
    try {
        logo = Image.fromUrl("https://polar.forkdev.xyz/cfbe89822994ff3519dce33a329e086fc6826d27a43f1372f34b3e5c2b82beb1")
    } catch(e) {
        ChatLib.chat("&cUnable to load logo")
    }

   
    const DrawRoundedRect = (colour, x, y, width, height, radius) => {
        //TOP LEFT
        Renderer.drawCircle(colour, x + radius, y + radius, radius, 25)

        //TOP RIGHT
        Renderer.drawCircle(colour, x - radius + width, y + radius, radius, 25)

        //BOTTOM LEFT
        Renderer.drawCircle(colour, x + radius, y - radius + height, radius, 25)

        //BOTTOM RIGHT
        Renderer.drawCircle(colour, x - radius + width, y - radius + height, radius, 25)


        Renderer.drawRect(colour, x, y + radius, width, height - (radius*2))

        Renderer.drawRect(colour, x + radius, y, width - (radius * 2), height)
    }

    class ToggleButton{
        constructor(name, defaultValue, parent){
            this.name = name
            this.value = defaultValue

            this.parent = parent

            this.hovered = false

            this.x = 0
            this.y = 0
            this.width = 14
            this.height = 12
        }

        Draw(mx, my){
            this.hovered = false
            if (mx > this.x && mx < this.x + this.width){
                if (my > this.y && my < this.y + this.height){
                    this.hovered = true
                }
            }

            font.drawString(`${this.name.removeFormatting()}`, this.x + this.width + 5, this.y, new java.awt.Color(0.7, 0.7, 0.7, 1))
            Renderer.drawRect(this.hovered? guiSettings.colours.border : guiSettings.colours.accent, this.x - 0.5, this.y - 0.5, this.width + 1, 9)
            Renderer.drawRect(guiSettings.colours.background, this.x, this.y, this.width, 8)

            if (this.value){
                Renderer.drawRect(Renderer.color(15, 200, 15), this.x + 6.5, this.y + 1, 6, 6)
            } else {
                Renderer.drawRect(Renderer.color(200, 15, 15), this.x + 2, this.y + 1, 6, 6)
            }
        }

        Click(){
            if (this.hovered){
                this.value = !this.value

                Save(this.parent.name, this.name, this.value)
            }
        }
    }

    class ValueSlider{
        constructor(name, min, max, defaultValue, parent){
            this.name = name
            this.min = min
            this.max = max
            this.default = defaultValue

            this.value = this.default

            this.parent = parent

            this.x = 0
            this.y = 0

            this.width = 200
            this.height = 21

            this.hovered = false
            this.dragging = false

            this.typed = [""]
        }

        GetPercent(){
            return (this.value - this.min) / (this.max - this.min) 
        }

        GetMouseValue(mx){
            if (!this.dragging) return

            let normalised = mx - this.x

            let percent = normalised / (this.width)
            
            let range = this.max - this.min
            
            let v = (range * percent) + (this.min)

            if (range > 10){
                v = Math.round(v / 5) * 5
            }
            if (v > this.max) v = this.max 
            if (v < this.min) v = this.min
            this.value = Math.round(v)

            //ChatLib.chat(`Normalised: ${normalised} - Percent: ${percent} - Range: ${range} - Value: ${v}`)
        }
        
        Draw(mx, my){
            this.hovered = false
            if (mx > this.x && mx < this.x + this.width){
                if (my > this.y + 9 && my < this.y + 15){
                    this.hovered = true
                }
            }

            if (!md){
                if (this.dragging){
                    Save(this.parent.name, this.name, this.value)
                }
                this.dragging = false
            }

          
            this.GetMouseValue(mx)
            

            font.drawString(`${this.name.removeFormatting().replace("'", "")}`, this.x, this.y, new java.awt.Color(0.7, 0.7, 0.7, 1))

            font.drawString(`${this.value}`, this.x + this.width + 2, this.y + 8, new java.awt.Color(0.5, 0.5, 0.5, 1))

            Renderer.drawRect(this.hovered? guiSettings.colours.border : guiSettings.colours.accent, this.x, this.y + 9, this.width, 5)
            Renderer.drawRect(guiSettings.colours.accent, this.x + 0.5, this.y + 9.5, this.width - 1, 4)
            Renderer.drawRect(guiSettings.colours.border, this.x + 0.5, this.y + 9.5, (this.width - 1) * (this.GetPercent()), 4)
        }

        Click(){
            if (this.hovered){
                this.dragging = true
            }
        }
    }

    class SelectionDropdown{
        constructor(name, value, options, collapsed, parent){
            this.name = name
            this.value = value
            this.options = options
            this.collapsed = true

            this.parent = parent

            this.x = 0
            this.y = 0

            this.height = 19

            this.width = this.GetWidth()
            this.hoverindex = 0

            this.hovered = false
        }

        Draw(mx, my){
            font.drawString(this.name, this.x, this.y, new java.awt.Color(0.7, 0.7, 0.7, 1))

            if (this.collapsed){   
                this.hovered = false
                if (mx > this.x && mx < this.x + this.width){
                    if (my > this.y + 10 && my < this.y + 19){
                        this.hovered = true
                    }
                }

                this.hoverindex = -1
                Renderer.drawRect(this.hovered? guiSettings.colours.border : guiSettings.colours.accent, this.x, this.y + 9, this.width, 10)
                Renderer.drawRect(guiSettings.colours.background, this.x + 0.5, this.y + 9.5, this.width - 1, 9)
                font.drawString(this.options[this.value].removeFormatting().replace("'", ""), this.x, this.y + 10, new java.awt.Color(1, 1, 1, 1))
                this.height = 23

            } else {
                this.height = 14 + (this.options.length * 9)

                Renderer.drawRect(guiSettings.colours.border, this.x, this.y + 9, this.width, this.height - 13)
                Renderer.drawRect(guiSettings.colours.background, this.x + 0.5, this.y + 9.5, this.width-1, this.height - 14)

                let c = -1
                this.options.forEach((opt, i) => {
             
                    if (mx > this.x && mx < this.x + this.width){
                        if (my > this.y + 10 + (i * 8) && my < this.y + 18 + (i * 8)){
                            this.hoverindex = i
                            c = this.hoverindex
                        }
                    }

                    font.drawString(opt.removeFormatting(), this.x + 1.5, this.y + 10 + (i * 9), this.hoverindex == i? new java.awt.Color(1, 1, 1, 1) : new java.awt.Color(0.7, 0.7, 0.7, 1))
                })
                this.hoverindex = c
            }
           
        }

        GetWidth(){
            let t = 0
                this.options.forEach(o => {
                    if (font.getWidth(o) > t){
                        t = font.getWidth(o)
                    } 
                });
                return t + 4
        }

        Click(mx, my){
            if (this.hovered){
                this.hovered = false
                return this.collapsed = false
            }

            if (this.hoverindex != -1){
                this.value = this.hoverindex
                Save(this.parent.name, this.name, this.value)
                this.collapsed = true
            } else { this.collapsed = true }
        }
    }

    class Feature{
        constructor(name, keys, description){
            this.name = name
            this.keys = keys

            this.description = description

            this.x = 0;
            this.y = 0;

            this.width = guiSettings.width - 200
            this.height = 6 + (this.keys.length * 20)

            this.hovered = false

            this.banning = false

            this.shouldDraw = true

            this.open = false
            this.hoverStart = 0

        }

        SetX(x){
            this.x = x
        }
        SetY(y){
            this.y = y
        }
        UpdateHeight(){
            let height = 4

            this.keys.forEach(key => height += key.height)

            this.height = height

            if ((this.y + this.height) > guiSettings.y + 24 + guiSettings.height - 34){
                //this.open = false
            }

            this.shouldDraw = true //!(this.y + 10 > guiSettings.y + 24 + guiSettings.height - 34)
        }
        GetHeight(){
            let h = 10

            if (this.open){
                h+= this.height
            }

            return h + 4
        }
        OpenHeight(){
            let h = 14

            
            h += this.height
            

            return h
        }

        Draw(mx, my){
            this.UpdateHeight()
    
            if (!this.shouldDraw) return
            this.width = guiSettings.width - 200
            
            // Check if module name hovered
            if ((mx > this.x - 2 && mx < this.x + 2 + (font.getWidth(this.name))) && (my > this.y - 1 && my < this.y + 10)){
                if (!this.hovered){
                    this.hoverStart = Date.now()
                } 
                else {
                    
                }
                this.hovered = true
            } else {this.hovered = false; this.hoverStart = Date.now()}
                

            font.drawString(`${this.name.removeFormatting().replace("'", "")}`, this.x, this.y, this.hovered? new java.awt.Color(1, 1, 1, 1) : new java.awt.Color(0.7, 0.7, 0.7, 1))

            if (this.banning) font.drawString("! BANNING !", this.x + this.width - (font.getWidth("! BANNING !")), this.y, new java.awt.Color(1, 0.3, 0.3, 1))

            if (!this.open) return Renderer.drawRect(Renderer.color(66, 100, 160, 150), this.x, this.y + 8.5, font.getWidth(this.name.removeFormatting()), 0.5)

            
            DrawRoundedRect(this.banning? Renderer.color(255, 15, 15) : guiSettings.colours.accent, this.x - 0.5, this.y + 9.5, this.width + 1, this.height + 1, 3)
            
            DrawRoundedRect(guiSettings.colours.background, this.x, this.y + 10, this.width, this.height, 3)

            let o = 0
            this.keys.forEach((key) => {
                key.x = this.x + 5
                key.y = this.y + 12 + o

                key.Draw(mx, my)
                
                o += key.height
            })

            
           
        }

        Click(){
            if (this.open){
                this.keys.forEach(key => {
                key.parent = this
                key.Click()
                });
            }
            if (this.hovered){
                this.open = !this.open
            }
        
        }
    }

    class Category{
        constructor(name){
            this.name = name

            this.selected = false

            this.features = []

            this.hovered = false

            this.y = 0

            this.scrollDown = false
            this.scrollHovered = false
            this.scrollValue = 25

            this.scrollHeight = 4

            this.maxScroll = -(guiSettings.height - 34)
        }

        Draw(mx, my){

            this.hovered = false
            if (mx > guiSettings.x && mx < guiSettings.x + 150){
                if (my > guiSettings.y + this.y && my < guiSettings.y + this.y + 20){
                    this.hovered = true
                }
            }

            this.scrollHovered = false
            if (mx > guiSettings.x + guiSettings.width - 20 && mx <  guiSettings.x + guiSettings.width - 14){
                if (my > guiSettings.y + 29 && my < guiSettings.y + 29 + guiSettings.height - 44){
                    this.scrollHovered = true
                }
            }

            this.CalcScroll(mx, my)

            DrawRoundedRect(guiSettings.colours.accent, guiSettings.x + 4.5, guiSettings.y + this.y - 0.5, 141, 21, 4)
            DrawRoundedRect(guiSettings.colours.categoryBackground, guiSettings.x + 5, guiSettings.y + this.y, 140, 20, 4) //' new java.awt.Color(1, 1, 1, 1)
            
            font.drawString(`${this.name.toUpperCase()}`, guiSettings.x + 75 - (font.getWidth(this.name.toUpperCase()) / 2), guiSettings.y + this.y + 6, this.selected? new java.awt.Color(0.5, 0.6, 1, 1) : this.hovered? new java.awt.Color(1, 1, 1, 1) : new java.awt.Color(0.7, 0.7, 0.7, 1))

            if (!this.selected) return 
            DrawRoundedRect(guiSettings.colours.categoryBackground, guiSettings.x + 150, guiSettings.y + 24, guiSettings.width - 180, guiSettings.height - 34, 3)
           
            // scroll bar
            if (this.maxScroll > 0){
                this.scrollHovered? Renderer.drawRect(guiSettings.colours.categoryBackground, guiSettings.x + guiSettings.width - 18.5, guiSettings.y + 28.5, 3, guiSettings.height - 43) : null
                Renderer.drawRect(guiSettings.colours.accent, guiSettings.x + guiSettings.width - 18, guiSettings.y + 29, 2, guiSettings.height - 44)

                Renderer.drawRect(guiSettings.colours.border, guiSettings.x + guiSettings.width - 18, guiSettings.y + 29 + ((guiSettings.height - (44 + this.scrollHeight)) * (this.scrollValue / this.maxScroll)), 2, this.scrollHeight)
            } else {this.scrollValue = 0}
        

            let sr = new net.minecraft.client.gui.ScaledResolution(
                Client.getMinecraft()
              );

            let sh = sr.func_78325_e()
            let sw = sr.func_78325_e()
        
            GL11.glEnable(GL11.GL_SCISSOR_TEST)
                
            try {
                GL11.glScissor((guiSettings.x + 150) * sw, Renderer.screen.getHeight() - ((guiSettings.y + 24) * sh), (guiSettings.width - 180) * sw, (guiSettings.height - 34) * sh);
                //Renderer.drawRect(Renderer.DARK_AQUA, 0, 0, 1000, 1000)
                let o = -this.scrollValue

                this.maxScroll = - (guiSettings.height - 34)

                this.features.forEach(feature => {
                    this.maxScroll += feature.GetHeight()
                    feature.SetX(guiSettings.x + 160)
                    feature.SetY(guiSettings.y + 29 + o)

                    o += feature.GetHeight()

                    feature.Draw(mx, my)

                });

                this.features.forEach(feat => {
                    if (feat.hovered){
                        let w = (feat.width - 4)
                        if (Date.now() - feat.hoverStart > 600){
                            Renderer.drawRect(guiSettings.colours.border, feat.x + 2, feat.y + 5, w, 3 + (9 * feat.description.length))
                            Renderer.drawRect(guiSettings.colours.background, feat.x + 2.5, feat.y + 5.5, w-1, 2 + (9 * feat.description.length))

                            feat.description.forEach((line, i)=> {
                                font.drawString(line.removeFormatting(), feat.x + 4, feat.y + 6 + (i * 9), new java.awt.Color(0.7, 0.7, 0.7, 1))
                            })
                        }
                    }
                })
                this.maxScroll += 5
            } catch (e) {

            }
            GL11.glDisable(GL11.GL_SCISSOR_TEST)
        }

        CalcScroll(mx, my){
            let scrollbary = guiSettings.y + 29

            let scrollbarheight = guiSettings.height - 44

            this.scrollHeight = scrollbarheight - this.maxScroll
            if (this.scrollHeight < 15) {this.scrollHeight = 15}
            if (this.scrollDown){
                if (!md){
                    this.scrollDown = false
                }

                let o =  my - scrollbary

                let y = o / (guiSettings.height - 44)

                let x = this.maxScroll * y


                if (x > this.maxScroll) x = this.maxScroll
                if (x < 0) x = 0
               this.scrollValue = Math.floor(x)

            }
            if (this.maxScroll < this.scrollValue) this.scrollValue = this.maxScroll
        }

        AddFeature(feature){ 
            this.features.push(feature)
        }

        ScrollWheel(dir){
            if (this.maxScroll < 0) return
            this.scrollValue += (dir * 8)
            if (this.maxScroll < this.scrollValue) this.scrollValue = this.maxScroll
            if (this.scrollValue < 0) this.scrollValue = 0
        }

        Init(){

        }

        Click(){
            if (this.selected){
                this.features.forEach(feature => {
                    feature.Click()
                })
            }
            if (this.hovered){
                let s = this.selected
                categories.forEach(cat => {
                    cat.selected = false
                })
               
                if (!s) this.selected = true
                
            }

            if (this.scrollHovered){
                this.scrollDown = true
            }
        }
    }

   

    let guiSettings = {
        colours: {
            border: Renderer.color(66, 160, 255),
            background: Renderer.color(15, 15, 29),
            categoryBackground: Renderer.color(20, 20, 34),
            accent: Renderer.color(0, 0, 0)
        },
        
        width: Renderer.screen.getWidth() * 0.5,
        height: Renderer.screen.getHeight() * 0.65,
        x: 0,
        y: 0,
        loadPercent: 0
    }

    let categories = []

    let gui = new Gui()

    gui.registerScrolled((mx, my, scroll) => {
        categories.forEach(cat => {
            cat.ScrollWheel(-scroll)
        })
    })

    gui.registerDraw((mx, my) => {
        // ADAPT TO SCREEN
        guiSettings.width = 500,
        guiSettings.height =  304,

        // DRAW MAIN
        DrawRoundedRect(dragging? guiSettings.colours.accent : guiSettings.colours.border, guiSettings.x - 0.5, guiSettings.y - 0.5, guiSettings.width + 1, guiSettings.height + 1, 5)
        DrawRoundedRect(Renderer.color(15, 15, 29), guiSettings.x, guiSettings.y, guiSettings.width, guiSettings.height, 5)


        //backgroundImage?.draw(guiSettings.x, guiSettings.y, guiSettings.width, guiSettings.height)
        //Renderer.drawRect(Renderer.color(5, 5, 8, 150), guiSettings.x, guiSettings.y, guiSettings.width, guiSettings.height)

        //titlefont.drawString("Polar Client", guiSettings.x + 20, guiSettings.y + 15, new java.awt.Color(0.2, 0.6, 1, 1))

    
        logo?.draw(guiSettings.x + 5, guiSettings.y + 5, 50, 50)
        titlefont.drawString("Polar", guiSettings.x + 60, guiSettings.y + 30 - (titlefont.getHeight("Polar") / 2), new java.awt.Color(66 / 255, 160 / 255, 1, 1))
        categories.forEach((cat, i) => {
            cat.y = 65 + (i * 25)
            cat.Draw(mx, my)
        })

        
        font.drawString(`${version}`, guiSettings.x + 20, guiSettings.y + guiSettings.height - 11.5, new java.awt.Color(1, 1, 1, 1))
        Renderer.drawRect(Renderer.color(15, 15, 29, 200), guiSettings.x + 16, guiSettings.y + guiSettings.height - 13, 8 + Renderer.getStringWidth(version), 10)
     

        DrawRoundedRect(Renderer.color(15, 15, 29, 255 * guiSettings.loadPercent), guiSettings.x, guiSettings.y, guiSettings.width, guiSettings.height, 5)

        if (guiSettings.loadPercent > 1){
           
            font.drawString("Polar Client", guiSettings.x + (guiSettings.width / 2) - (font.getWidth("Polar Client") / 2), guiSettings.y + (guiSettings.height / 2) - 20, new java.awt.Color(1, 1, 1, 1))
            

            DrawRoundedRect(guiSettings.colours.accent, guiSettings.x + 50, guiSettings.y + (guiSettings.height / 2) - 4, guiSettings.width - 100, 6, 2)
            DrawRoundedRect(guiSettings.colours.border, guiSettings.x + 51, guiSettings.y + (guiSettings.height / 2)  - 3, (guiSettings.width - 100) * (2 - guiSettings.loadPercent), 4, 2)

            Renderer.drawRect(Renderer.color(15, 15, 29, 255 - (255 * (guiSettings.loadPercent - 0.8))), guiSettings.x, guiSettings.y + (guiSettings.height / 2) - 22, guiSettings.width, 50)
        }

        font.drawString(`x`, guiSettings.x + guiSettings.width - 18, guiSettings.y + 5, (mx > guiSettings.x + guiSettings.width - 21 && mx < guiSettings.x + guiSettings.width - 13)&&(my > guiSettings.y + 5 && my < guiSettings.y + 13)? new java.awt.Color(1, 0, 0, 1) : new java.awt.Color(1, 0.3, 0.3, 1)) 
        
        if (!banModules){
            font.drawString("WARNING: Unable to fetch list of detected modules (try /ct load)", guiSettings.x + (guiSettings.width / 2) - (font.getWidth("WARNING: Unable to fetch list of detected modules (try /ct load)") /2), guiScale.y - 10, new java.awt.Color(1, 0.3, 0.3, 1))
        }

        if (!dragging) return 

        guiSettings.x = mx + offsetx 

        if (guiSettings.x < 0) guiSettings.x = 0
        if (guiSettings.y < 0) guiSettings.y = 0

        if (guiSettings.x + guiSettings.width > Renderer.screen.getWidth()) {guiSettings.x = Renderer.screen.getWidth() - guiSettings.width}
        if (guiSettings.y + guiSettings.height > Renderer.screen.getHeight()) {guiSettings.y = Renderer.screen.getHeight() - guiSettings.height}

        guiSettings.y = my + offsety

        prevx = mx
        prevy = my

    })

    let dragging = false
    let prevx = 0
    let offsetx = 0

    let prevy = 0
    let offsety = 0


    gui.registerMouseReleased(() => {
        dragging = false
        md = false
    })
    gui.registerClosed(() => {
        dragging = false
        md = false
    })

 

    gui.registerClicked((mx, my) => {
        md = true

        categories.forEach((cat, i) => {
            cat.Click()
        })

        if (mx > guiSettings.x && mx < guiSettings.x + guiSettings.width){
            if (my > guiSettings.y && my < guiSettings.y + 24){
                dragging = true

                offsetx = guiSettings.x - mx
                offsety = guiSettings.y - my
            }
        }

        if (mx > guiSettings.x + guiSettings.width - 18 && mx < guiSettings.x + guiSettings.width - 13){
            if (my > guiSettings.y + 5 && my < guiSettings.y + 13){
               gui.close()
               dragging = false  

            }
        }
    })

    let guiScale = 0
    gui.registerOpened(() => {
        guiSettings.width = Renderer.screen.getWidth() * 0.5
        guiSettings.height = Renderer.screen.getHeight() * 0.65
        guiSettings.x = (Renderer.screen.getWidth() / 2) - (guiSettings.width / 2)
        guiSettings.y = (Renderer.screen.getHeight() / 2) - (guiSettings.height / 2)

        md = false
        guiScale = Client.getSettings().getSettings().field_74335_Z
        Client.getSettings().getSettings().field_74335_Z = 2
        guiSettings.loadPercent = 2
        new Thread(() => {
            Thread.sleep(50)
            while (guiSettings.loadPercent > 0){
                guiSettings.loadPercent -= 0.02
                Thread.sleep(4)
            }   
            guiSettings.loadPercent = 0
            
        }).start()
    })  

    gui.registerClosed(() => {
        md = false
        Client.getSettings().getSettings().field_74335_Z = guiScale
    })

    register("command", () => {
        gui.open()
    }).setName("polar", true)
    
    register("renderHotbar", (e) => {
        if (gui.isOpen()){
            cancel(e)
        }
    })
    register("renderHealth", (e) => {
        if (gui.isOpen()){
            cancel(e)
        }
    })
    register("renderFood", (e) => {
        if (gui.isOpen()){
            cancel(e)
        }
    })
    register("renderArmor", (e) => {
        if (gui.isOpen()){
            cancel(e)
        }
    })
    register("renderExperience", (e) => {
        if (gui.isOpen()){
            cancel(e)
        }
    })
    register("actionBar", (e) => {
        if (gui.isOpen()){
            cancel(e)
        }
    })

    function Save(moduleName, setting, value){

        let newConfig = config
        
        config.forEach(mod => {
            //ChatLib.chat(mod.Name)
            if (mod.Name == moduleName){
                mod.Settings.forEach(set => {
                    if (set.Name.toLowerCase() == setting.toLowerCase()){
                        
                        set.Value = value
                    }
                })
            }
        })

        global.modules.forEach(mod => {

            if (mod.Name == moduleName){
                
                mod.settings.forEach(set => {
                    if (set.Name == setting){
                       
                       set.Value = value
                        
                    }
                });
            }
            
        })
        config = newConfig

        FileLib.write(FolderName, "polarconfig.json", JSON.stringify(config, null, 2))

        try {
            global.exports.settingGet.saveSettings()
        } catch (error) {
            ChatLib.chat(error)
        }

    }

    let CategoryTypes = ["Dwarven Mines","Crystal Hollows","Mining","Dungeons","Farming","Fishing","Foraging","Combat","Misc"]

    let banModules
    try {
        banModules = JSON.parse(FileLib.getUrlContent("https://polar.forkdev.xyz/782c230c0495d63d65bfe0dc91ae901be5f6622a630c9cad4b009101006aa7e0"))
    } catch (e){
        ChatLib.chat("&cFailed to load detected modules. Proceed with caution")
    }
    
        register("step", () => {
            request('https://polar.forkdev.xyz/782c230c0495d63d65bfe0dc91ae901be5f6622a630c9cad4b009101006aa7e0')
            .then(function(response) {
                let oldBM = banModules
                banModules = JSON.parse(response)
    
                let catKeys = {}
                CategoryTypes.forEach((cat, i) => {
                    catKeys[cat] = i
                })
                
                CategoryTypes.forEach(cat => {
                    categories[catKeys[cat]].features.forEach(feat => {
                        if (!banModules.Modules[feat.name]){
                            feat.banning = true

                            if (oldBM.Modules[feat.name]){
                                ChatLib.chat(`&0[&cPolar Client&0]&r &cWARNING: ${feat.name} detected, disable to avoid ban.`)
                            }
                        }
                    })
                })
            })
            .catch(function(error) {
                
            });

        }).setDelay(10)
 
    

    function Init(){
        let catKeys = {}
        CategoryTypes.forEach((cat, i) => {
            categories.push(new Category(cat))
            catKeys[cat] = i
        })
        
        let modules = global.modules

        modules.forEach(mod => {
           
            let settingsObj = new Feature(
                mod.Name,
                [],
                mod.description
            )
            if (banModules){
                if (!banModules.Modules[mod.Name]){
                    settingsObj.banning = true
                }
            }

            for (set in mod.settings){
                
                if (mod.settings[set].Min != undefined){
                    settingsObj.keys.push(new ValueSlider(
                        mod.settings[set].Name,
                        mod.settings[set].Min,
                        mod.settings[set].Max,
                        mod.settings[set].Value,
                        this
                    ))
                }
                else if (mod.settings[set].Options != undefined){
                    settingsObj.keys.push(new SelectionDropdown(
                        mod.settings[set].Name,
                        mod.settings[set].Value,
                        mod.settings[set].Options,
                        mod.settings[set].IsCollapsed,
                        this
                    ))
                } else {
                    settingsObj.keys.push(new ToggleButton(
                        mod.settings[set].Name,
                        mod.settings[set].Value,
                        this
                    ))
                }
            }        
            
            settingsObj.keys.forEach(key => {
                config.forEach(setting => {
                    if (setting.Name == mod.Name){
                        setting.Settings.forEach(set => {
                            //ChatLib.chat(`${setting.Name}     ${key.name}`)
                            if (set.Name.toLowerCase() == key.name.toLowerCase()){
                                //ChatLib.chat(set.Name)
                                //ChatLib.chat(key.value)
                                key.value = set.Value
                            }
                        })
                    }
                })
            })

            categories[catKeys[mod.Catecory]].AddFeature(settingsObj)
        })
    }

    
    Init()
}

//UNCOMMENT THIS, THROWS ERROR ON MY MACHINE DUE TO 'global.exports' NOT BEING DEFINED
global.exports.gui = GUI