global.exports = {}
global.modules = []


import "PolarClient/settingsGetter.js"
import "PolarClient/gui.js"

/*
    ASM toggle Functions, need to be First!
*/


// fork <3
// farlow <3

/*
    utils
*/
import "PolarClient/utils/fileUtils.js"
import "PolarClient/utils/serverUtils.js"
import "PolarClient/utils/rotationUtils.js"
import "PolarClient/utils/itemUtils.js"
import "PolarClient/utils/mathUtils.js"
import "PolarClient/utils/ungrab.js"
import "PolarClient/utils/calcUtils.js"
import "PolarClient/utils/randomConsts.js"
import "PolarClient/keyBinds.js"
import "PolarClient/utils/javaArrayList.js"
import "PolarClient/mining/qolMining/XRay.js"
import "PolarClient/misc/renderToggle.js"
import "PolarClient/utils/failsafe.js"
import "PolarClient/utils/itemFinderUtils.js"
import "PolarClient/utils/lookAt.js"
import "PolarClient/utils/playerPos.js"
import "PolarClient/utils/rayTraceUtils.js"
import "PolarClient/utils/rotationCalc.js"
import "PolarClient/utils/speedCalc.js"
import "PolarClient/utils/toBlockPos.js"
import "PolarClient/utils/rayTrauceUtils.js"
import "PolarClient/utils/renderUtils.js"

/*
    Combat Macro's
*/
import "PolarClient/combat/flareMacro.js"
import "PolarClient/combat/autoKatana.js"
import "PolarClient/combat/autoMaddox.js"
import "PolarClient/combat/ghostMacro.js"
import "PolarClient/combat/helmetSwapper.js"
import "PolarClient/combat/qolSwap.js"
import "PolarClient/combat/killAura.js"

/*
    Dungeons Qol
*/
import "PolarClient/dungeons/autoRoutes.js"
import "PolarClient/dungeons/autoTerm.js"
import "PolarClient/dungeons/GhostBlocks.js"
import "PolarClient/dungeons/HBlock.js"
import "PolarClient/dungeons/secretAura.js"
import "PolarClient/dungeons/VBlock.js"

/*
    Fishing Macro's
*/
import "PolarClient/fishing/fishingMacro.js"
import "PolarClient/fishing/fishingThropy.js"
/*
    Fishing Qol
*/

import "PolarClient/foraging/foragingMacroHub.js"

import "PolarClient/general/fairySoulAura.js"

import "PolarClient/Farming/farmingMacro.js"

import "PolarClient/mining/routeNuker.js"

/*
    Mining Macro's
*/
import "PolarClient/mining/obsidianMacro.js"
import "PolarClient/mining/miningMacro.js"
import "PolarClient/mining/autoCompactGems.js"
import "PolarClient/mining/autoRouteSetup.js"
import "PolarClient/mining/commisionMacro.js"
import "PolarClient/mining/gemstoneMacro.js"
import "PolarClient/mining/hardStoneNuker.js"
import "PolarClient/mining/lobbySwap.js"
import "PolarClient/mining/mithrilMacro.js"
import "PolarClient/mining/powderMacro.js"
import "PolarClient/misc/sandMiner.js"
import "PolarClient/mining/routeChecker.js"
import "PolarClient/combat/flareMacro.js"

global.exports.settingGet.makeObject()
global.exports.gui()











































let { dungeonFloor, setting, polarPrefix } = global.exports

let { getCorrectPanes, exitTerm } = global.exports

ChatLib.chat("&bpolar on top")


let floor = undefined
register("step", () => {
    floor = dungeonFloor()
}).setFps(1)

register("tick", () => {
    if(global.exports.settingGet.getSetting("Auto Terminals","Enabled") && floor === 7) {
        if (!(Client.currentGui.get() instanceof net.minecraft.client.gui.inventory.GuiChest)) exitTerm() 
        else getCorrectPanes()
    }
})

register("Command", () => {
ChatLib.chat((Math.floor(Player.getX()) + 0.5) + " " + Math.floor(Player.getY() - 1 ) + " " + (Math.floor(Player.getZ()) + 0.5))
}).setName("meme")

register("Command", () => {
    let looking = Player.lookingAt()
    ChatLib.chat(Math.floor(looking.getX()) + " " + Math.floor(looking.getY()) + " " + Math.floor(looking.getZ()) + " " + looking.face)
}).setName("meme2")

register("Command", () => {
    ChatLib.chat("[" + Math.floor(Player.getX()) + "," + Math.floor(Player.getY() - 1) + "," + Math.floor(Player.getZ()) + "]")
    console.log("[" + Math.floor(Player.getX()) + "," + Math.floor(Player.getY() - 1) + "," + Math.floor(Player.getZ()) + "],")
}).setName("meme3")

register("command", () => {
    ChatLib.chat("if(Player.getX() < " + (Math.floor(Player.getX()) + 1) + " && " + "Player.getX() > " + (Math.floor(Player.getX()) - 1) + " && " + "Player.getZ() < " + (Math.floor(Player.getZ()) + 1) + " && " + "Player.getZ() > " + (Math.floor(Player.getZ()) - 1) + " && " + "Player.getY() < " +  (Math.floor(Player.getY()) + 1) + " && " + "Player.getY() > " + (Math.floor(Player.getY()) - 1) + ")")
    console.log("if(Player.getX() < " + (Math.floor(Player.getX()) + 1) + " && " + "Player.getX() > " + (Math.floor(Player.getX()) - 1) + " && " + "Player.getZ() < " + (Math.floor(Player.getZ()) + 1) + " && " + "Player.getZ() > " + (Math.floor(Player.getZ()) - 1) + " && " + "Player.getY() < " +  (Math.floor(Player.getY()) + 1) + " && " + "Player.getY() > " + (Math.floor(Player.getY()) - 1) + ")")
}).setName("meme4")


register("command", () => {
    ChatLib.chat(
    "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠛⠛⠛⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠙⠛⠛⠛⠿⠻⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n" +
    "⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⠀⠀⠀⠀⠀⡀⠠⠤⠒⢂⣉⣉⣉⣑⣒⣒⠒⠒⠒⠒⠒⠒⠒⠀⠀⠐⠒⠚⠻⠿⠿⣿⣿⣿⣿⣿⣿⣿⣿\n" +
    "⣿⣿⣿⣿⣿⣿⣿⣿⠏⠀⠀⠀⠀⡠⠔⠉⣀⠔⠒⠉⣀⣀⠀⠀⠀⣀⡀⠈⠉⠑⠒⠒⠒⠒⠒⠈⠉⠉⠉⠁⠂⠀⠈⠙⢿⣿⣿⣿⣿⣿\n" +
    "⣿⣿⣿⣿⣿⣿⣿⠇⠀⠀⠀⠔⠁⠠⠖⠡⠔⠊⠀⠀⠀⠀⠀⠀⠀⠐⡄⠀⠀⠀⠀⠀⠀⡄⠀⠀⠀⠀⠉⠲⢄⠀⠀⠀⠈⣿⣿⣿⣿⣿\n" +
    "⣿⣿⣿⣿⣿⣿⠋⠀⠀⠀⠀⠀⠀⠀⠊⠀⢀⣀⣤⣤⣤⣤⣀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠜⠀⠀⠀⠀⣀⡀⠀⠈⠃⠀⠀⠀⠸⣿⣿⣿⣿\n" +
    "⣿⣿⣿⣿⡿⠥⠐⠂⠀⠀⠀⠀⡄⠀⠰⢺⣿⣿⣿⣿⣿⣟⠀⠈⠐⢤⠀⠀⠀⠀⠀⠀⢀⣠⣶⣾⣯⠀⠀⠉⠂⠀⠠⠤⢄⣀⠙⢿⣿⣿\n" +
    "⣿⡿⠋⠡⠐⠈⣉⠭⠤⠤⢄⡀⠈⠀⠈⠁⠉⠁⡠⠀⠀⠀⠉⠐⠠⠔⠀⠀⠀⠀⠀⠲⣿⠿⠛⠛⠓⠒⠂⠀⠀⠀⠀⠀⠀⠠⡉⢢⠙⣿\n" +
    "⣿⠀⢀⠁⠀⠊⠀⠀⠀⠀⠀⠈⠁⠒⠂⠀⠒⠊⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⢀⣀⡠⠔⠒⠒⠂⠀⠈⠀⡇⣿\n" +
    "⣿⠀⢸⠀⠀⠀⢀⣀⡠⠋⠓⠤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠄⠀⠀⠀⠀⠀⠀⠈⠢⠤⡀⠀⠀⠀⠀⠀⠀⢠⠀⠀⠀⡠⠀⡇⣿\n" +
    "⣿⡀⠘⠀⠀⠀⠀⠀⠘⡄⠀⠀⠀⠈⠑⡦⢄⣀⠀⠀⠐⠒⠁⢸⠀⠀⠠⠒⠄⠀⠀⠀⠀⠀⢀⠇⠀⣀⡀⠀⠀⢀⢾⡆⠀⠈⡀⠎⣸⣿\n" +
    "⣿⣿⣄⡈⠢⠀⠀⠀⠀⠘⣶⣄⡀⠀⠀⡇⠀⠀⠈⠉⠒⠢⡤⣀⡀⠀⠀⠀⠀⠀⠐⠦⠤⠒⠁⠀⠀⠀⠀⣀⢴⠁⠀⢷⠀⠀⠀⢰⣿⣿\n" +
    "⣿⣿⣿⣿⣇⠂⠀⠀⠀⠀⠈⢂⠀⠈⠹⡧⣀⠀⠀⠀⠀⠀⡇⠀⠀⠉⠉⠉⢱⠒⠒⠒⠒⢖⠒⠒⠂⠙⠏⠀⠘⡀⠀⢸⠀⠀⠀⣿⣿⣿\n" +
    "⣿⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⠑⠄⠰⠀⠀⠁⠐⠲⣤⣴⣄⡀⠀⠀⠀⠀⢸⠀⠀⠀⠀⢸⠀⠀⠀⠀⢠⠀⣠⣷⣶⣿⠀⠀⢰⣿⣿⣿\n" +
    "⣿⣿⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⠀⠁⢀⠀⠀⠀⠀⠀⡙⠋⠙⠓⠲⢤⣤⣷⣤⣤⣤⣤⣾⣦⣤⣤⣶⣿⣿⣿⣿⡟⢹⠀⠀⢸⣿⣿⣿\n" +
    "⣿⣿⣿⣿⣿⣿⣿⣧⡀⠀⠀⠀⠀⠀⠀⠀⠑⠀⢄⠀⡰⠁⠀⠀⠀⠀⠀⠈⠉⠁⠈⠉⠻⠋⠉⠛⢛⠉⠉⢹⠁⢀⢇⠎⠀⠀⢸⣿⣿⣿\n" +
    "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣀⠈⠢⢄⡉⠂⠄⡀⠀⠈⠒⠢⠄⠀⢀⣀⣀⣰⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⢀⣎⠀⠼⠊⠀⠀⠀⠘⣿⣿⣿\n" +
    "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⡀⠉⠢⢄⡈⠑⠢⢄⡀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠁⠀⠀⢀⠀⠀⠀⠀⠀⢻⣿⣿\n" +
    "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⣀⡈⠑⠢⢄⡀⠈⠑⠒⠤⠄⣀⣀⠀⠉⠉⠉⠉⠀⠀⠀⣀⡀⠤⠂⠁⠀⢀⠆⠀⠀⢸⣿⣿\n" +
    "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⣄⡀⠁⠉⠒⠂⠤⠤⣀⣀⣉⡉⠉⠉⠉⠉⢀⣀⣀⡠⠤⠒⠈⠀⠀⠀⠀⣸⣿⣿\n" +
    "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣶⣤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⣿⣿⣿\n" +
    "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣶⣶⣶⣤⣤⣤⣤⣀⣀⣤⣤⣤⣶⣾⣿⣿⣿⣿⣿"
    )
}).setName("rat")

let fagots = ["floatingsand","aurorafenn","implodent","pie5","zgrillbz","creepstick","umtofly","itsfrag"]
register("command", () => {
    let players = World.getAllPlayers()
    for(let i = 0; i < players.length; i++) {
        for(let y = 0; y < fagots.length; y++) {
            if(players[i].toString().toLocaleLowerCase().includes(fagots[y])) {
                ChatLib.chat(players[i])            
            }
        }
    }
}).setName("findfag")

let array = []
register("command", () => {
    array.push([Math.floor(Player.getX()), Math.floor(Player.getY()), Math.floor(Player.getZ())])
    ChatLib.chat("added: " + array.length)
}).setName("addyes")

register("command", () => {
    let arrayyes = ""
    for(let i = 0; i < array.length; i++) {
        arrayyes += (", [" + array[i][0] + ", " + array[i][1] + ", " + array[i][2] + "]")
    }
    ChatLib.chat(arrayyes)
}).setName("arrayprint")


// register("packetSent", (packet, event) => {
//     ChatLib.chat(packet.fieldChanger())
// }).setPacketClasses([net.minecraft.network.play.client.C03PacketPlayer])

// register("clicked", (x,y,b,d) => {
//     if(b === 1.0 && d) {
//         array.push([Math.floor(Player.getX()), Math.floor(Player.getY()), Math.floor(Player.getZ())])
//         ChatLib.chat("added: " + array.length)
//     } 
// })