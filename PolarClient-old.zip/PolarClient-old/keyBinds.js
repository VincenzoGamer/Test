let { config, polarPrefix, configWebhook, writeWebhook } = global.exports

class keyBinds {
    constructor() {

        register("command", (x) => {
            if(x.toString().toLowerCase().includes("discord")) {
                ChatLib.chat(polarPrefix + " Webhook set to: " + x)

                configWebhook.webhookname = x
                writeWebhook()
            } else {
                ChatLib.chat(polarPrefix + " " + x + " is not valid!")
            }
        }).setName("setwebhook")

        try {
            this.loadKeys()
        } catch (e) {
            global.exports.MakeNewKeys()
            this.loadKeys()
        }
        this.updateTime = 0

        register("Tick", () => {
            if(this.updateTime < 20) {
                this.updateTime += 1
            } else {
                this.updateTime = 0
                this.loadConfig()
            }
        })
    }

    loadKeys() {
        //General
        this.keyBindFairySoulAura = new KeyBind("Fairy Soul Aura", config.keyFairySoulAura, "Polar Client - General")

        //Fishing
        this.keyBindFishingMacro = new KeyBind("Fishing Macro", config.keyFishingMacro, "Polar Client - Fishing")
    
        //Foraging
        this.keyBindHubForagingMacro = new KeyBind("Foraging Macro Hub", config.keyHubForagingMacro, "Polar Client - Foraging")
    
        //Combat
        this.keyBindKillAura = new KeyBind("Kill Aura", config.keyKillAura, "Polar Client - Combat")
        this.keyBindGhostMacro = new KeyBind("Ghost Macro", config.keyGhostMacro, "Polar Client - Combat")
        this.keyBindQolSwap = new KeyBind("Qol Swap", config.keyQolSwap, "Polar Client - Combat")
        this.keyBindHelmetSwapper = new KeyBind("Helmet Swapper", config.keyHelmetSwapper, "Polar Client - Combat")
        this.keyBindArmorSwapper = new KeyBind("Armor Swapper", config.keyArmorSwapper, "Polar Client - Combat")
    
        //Mining
        this.keyBindMiningMacro = new KeyBind("Mining Macro", config.keyMiningMacro, "Polar Client - Mining")
        this.keyBindCommMacro = new KeyBind("Commision Macro", config.keyCommMacro, "Polar Client - Mining")
        this.keyBindMithrilMacro = new KeyBind("Mithril Macro", config.keyBindMithrilMacro, "Polar Client - Mining")
        this.keyBindHardStoneNuker = new KeyBind("HardStone Nuker", config.keyHardStoneNuker, "Polar Client - Mining")
        this.keyBindGemstoneMacro = new KeyBind("Gemstone Macro", config.keyGemstoneMacro, "Polar Client - Mining")
        this.keyBindRouteNuker = new KeyBind("Route Nuker", config.keyRouteNuker, "Polar Client - Mining")
        this.keyBindLobbySwapper = new KeyBind("Lobby Swapper", config.keyLobbySwapper, "Polar Client - Mining")
        this.keyBindAutoCompactSacks = new KeyBind("Auto Compacter", config.keyAutoCompactSacks, "Polar Client - Mining")
        this.keyBindSandMiner = new KeyBind("Sand Miner", config.keySandMiner, "Polar Client - Mining")
        this.keyBindPowderMacro = new KeyBind("Powder Macro", config.keyPowderMacro, "Polar Client - Mining")
        this.keyBindArmadilloMacro = new KeyBind("Armadillo Macro", config.keyArmadilloMacro, "Polar Client - Mining")
        this.keyBindXRay = new KeyBind("X-Ray", config.keyXRay, "Polar Client - Mining")
        
        //Dungeons
        this.keyBindHBlock = new KeyBind("HBlock", config.keyHBlock, "Polar Client - Dungeons")
        this.keyBindVBlock = new KeyBind("VBlock", config.keyVBlock, "Polar Client - Dungeons")
        this.keyBindGhostBlock = new KeyBind("Ghost Blocks", config.keyGhostBlock, "Polar Client - Dungeons")
        this.keyBindSecretAura = new KeyBind("Secret Aura", config.keySecretAura, "Polar Client - Dungeons")
    
        //Farming
        this.keyBindFarmingMacro = new KeyBind("Farming Macro", config.keyFarmingMacro, "Polar Client - Farming")
    }

    loadConfig() {
        //General
        config.keyFairySoulAura = this.keyBindFairySoulAura.getKeyCode();

        //Fishing
        config.keyFishingMacro = this.keyBindFishingMacro.getKeyCode();
    
        //Foraging
        config.keyHubForagingMacro = this.keyBindHubForagingMacro.getKeyCode();
    
        //Combat
        config.keyKillAura = this.keyBindKillAura.getKeyCode();
        config.keyGhostMacro = this.keyBindGhostMacro.getKeyCode();
        config.keyQolSwap = this.keyBindQolSwap.getKeyCode();
        config.keyHelmetSwapper = this.keyBindHelmetSwapper.getKeyCode();
        config.keyArmorSwapper = this.keyBindArmorSwapper.getKeyCode();
    
        //Mining
        config.keyMiningMacro = this.keyBindMiningMacro.getKeyCode();
        config.keyCommMacro = this.keyBindCommMacro.getKeyCode();
        config.keyBindMithrilMacro = this.keyBindMithrilMacro.getKeyCode();
        config.keyHardStoneNuker = this.keyBindHardStoneNuker.getKeyCode();
        config.keyGemstoneMacro = this.keyBindGemstoneMacro.getKeyCode();
        config.keyRouteNuker = this.keyBindRouteNuker.getKeyCode();
        config.keyLobbySwapper = this.keyBindLobbySwapper.getKeyCode();
        config.keyAutoCompactSacks = this.keyBindAutoCompactSacks.getKeyCode();
        config.keySandMiner = this.keyBindSandMiner.getKeyCode();
        config.keyPowderMacro = this.keyBindPowderMacro.getKeyCode();
        config.keyArmadilloMacro = this.keyBindArmadilloMacro.getKeyCode();
        config.keyXRay = this.keyBindXRay.getKeyCode();
    
        //Dungeons
        config.keyHBlock = this.keyBindHBlock.getKeyCode();
        config.keyVBlock = this.keyBindVBlock.getKeyCode();
        config.keyGhostBlock = this.keyBindGhostBlock.getKeyCode();
        config.keySecretAura = this.keyBindSecretAura.getKeyCode();

        //Farming
        config.keyFarmingMacro = this.keyBindFarmingMacro.getKeyCode();

        var json = JSON.stringify(config,null,2);
        FileLib.write("PolarConfig", "config.json", json);
    }
}

global.exports.keyBind = new keyBinds()