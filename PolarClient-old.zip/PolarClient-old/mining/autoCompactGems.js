let { keyBind } = global.exports
let { polarPrefix, setting } = global.exports

const configAutoCompact = new global.configModuleClass(
    "Auto Compacter",
    "Crystal Hollows",
    false,
    [
        new global.settingSelector("Gemstone Type", 0, ["&cRuby", "&eTopaz", "&bSapphire", "&5Amethyst", "&6Amber", "&aJade"], false)
    ],
    [
        "&bAuto Compacter",
        "Auto mattically Compacts in Gemstone sacks"
    ]
)

global.modules.push(configAutoCompact)

class autoCompactGems {
    constructor() {

        this.configName = "Auto Compacter"

        this.toggle = false
        this.cooldown = 0
        this.spammCoolDown = 0

        
        keyBind.keyBindAutoCompactSacks.registerKeyPress(() => {this.toggleMacro()})

        register("Tick", () => {
            this.cooldown += 1
            if(this.cooldown === 10) {
                this.gemType = global.exports.settingGet.getSetting(this.configName,"Gemstone Type")
                this.cooldown = 0
            }

            if(this.toggle) {
                let plyCont = Player.getContainer()
                if(plyCont != undefined) {
                    if(plyCont.getName() === "Gemstones Sack") {
                        this.spammCoolDown += 1
                        if(this.spammCoolDown === 2) {
                            if(this.gemType === "&aJade") {
                                plyCont.click(10,false,"LEFT")
                            }
                            if(this.gemType === "&6Amber") {
                                plyCont.click(11,false,"LEFT")
                            }
                            if(this.gemType === "&eTopaz") {
                                plyCont.click(12,false,"LEFT")
                            }
                            if(this.gemType === "&bSapphire") {
                                plyCont.click(13,false,"LEFT")
                            }
                            if(this.gemType === "&5Amethyst") {
                                plyCont.click(14,false,"LEFT")
                            }
                            if(this.gemType === "&cRuby") {
                                plyCont.click(16,false,"LEFT")
                            }
                            this.spammCoolDown = 0
                        }
                    }
                }
            }
        })
    }

    toggleMacro() {
        this.toggle = !this.toggle
        if(this.toggle) {
            ChatLib.chat(polarPrefix + " Auto Compact: " + this.toggle)
        } else {
            ChatLib.chat(polarPrefix + " Auto Compact: " + this.toggle)
        }
    }
}

global.exports.autoCompact = new autoCompactGems()