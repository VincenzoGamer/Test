let { polarPrefix, WalkBackward, WalkForward, WalkLeft, WalkRight } = global.exports

let movements = [WalkBackward, WalkForward, WalkLeft, WalkRight]
class autoRouteSetupClass {
    constructor() {
        this.toggle = false

        register("command", () => {
            this.toggleMacro()
        }).setName("autoRouteSetupTest")

        register("tick", () => {
            this.callCords()
            if(this.toggle) {
                this.scanblock()
            }
        })

        register("step", () => {
            if(this.toggle) {
                this.walkDirection("forward")
            }
        }).setFps(100)
    }

    toggleMacro() {
        this.toggle = !this.toggle
        if(this.toggle) {
            ChatLib.chat(polarPrefix + " Started Auto Route Setup")
        } else {
            ChatLib.chat(polarPrefix + " Stopped Auto Route Setup")
            this.cancelWalk()
        }
    }

    scanblock() {
        for(let x = -1; x < 2; x++) {
            for(let z = -1; z < 1; z++) {
                ChatLib.chat(World.getBlockAt(this.plyX + x, this.plyY, this.plyZ + z).type.getID())
            }
        }
    }

    walkDirection(walkType) {
        this.cancelWalk()
        switch(walkType) {
            case "left":
                movements[2].setState(true)
                break;
            case "right":
                movements[3].setState(true)
                break;
            case "forward":
                movements[1].setState(true)
                break;
            case "backward":
                movements[0].setState(true)
                break;
        }
    }

    cancelWalk() {
        for(let i = 0; i < movements.length; i++) {
            movements[i].setState(false)
        }
    }

    callCords() {
        this.plyX = Math.floor(Player.getX())
        this.plyY = Math.floor(Player.getY())
        this.plyZ = Math.floor(Player.getZ())
    }
}

global.exports.autoRouteSetup = new autoRouteSetupClass()