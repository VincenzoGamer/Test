import Skyblock from "BloomCore/Skyblock";
let { autoMine } = global.exports
let { finder } = global.exports
let { keyBind } = global.exports
let { C09PacketHeldItemChange, cancelWalk, commissions, polarPrefix, sendPacket, setPitch, setYaw, Shift, writeSave, BP, WalkLeft, WalkRight, WalkBackward, WalkForward } = global.exports
let { lookAt, rotationUtils, itemUtils } = global.exports
let { setting } = global.exports
let { toggle } = global.exports
let { setSpeeds } = global.exports
let { getVisibleValidPoint } = global.exports
let { lookAtRayCast, disToPly, degreeRannge, degreeRanngeRaw, disToPlyFlat, lookAt2, LClickItem, fillJavaArray, mathUtils } = global.exports

const configCommisionMacro = new global.configModuleClass(
    "Commision Macro",
    "Dwarven Mines",
    false,
    [
        new global.settingToggle("Pidgeonless Mode", false),
        new global.settingToggle("Use nuker", false),
        new global.settingSlider("Mining look speed", 150, 1, 1000),
        new global.settingSlider("Etherwarp look speed", 500, 1, 1000),
        new global.settingSlider("Additional mining ticks", 2, 0, 10),
        new global.settingSlider("Max rotation", 120, 0, 180)
    ],
    [
        "&bCommision Macro",
        "Auto Mattically does Dwarven Mines commissions for you",
        "Requires: Pickaxe, Drill/Gauntlet, Frozen Scythe, Pidgeon(Optional)"
    ]
)

global.modules.push(configCommisionMacro)

let mc = Client.getMinecraft()
let LClick = mc.getClass().getDeclaredMethod("func_147116_af")
LClick.setAccessible(true)

class commisionMacro {
    constructor() {
        this.configName = "Commision Macro"
        this.pidgeonless = false
        this.posIndex = 0
        this.toggleIceWalker = false
        this.toggleGoblin = false
        this.currentArea = "Forge"
        this.toggle = false
        toggle.commisionMacro = this.toggle
        toggle.titanium = false
        writeSave()
        this.refuelPlace = 0
        this.fuelItems = ["Volta","Oil"]
        this.inMenu = false
        this.pidgeonWalk = [
            ["left",9.5,undefined,true,[0.0,0.0]],
            ["forward",undefined,-64,true,[0.0,0.0]],
            ["left",10,undefined,true,[0.0,0.0]],
            ["forward",undefined,-42,true,[0.0,0.0]],
            ["right",9,undefined,false,[0.0,0.0]],
            ["forward",undefined,-21,true,[0.0,0.0]],
            ["forward",40,undefined,true, [-43.2,7.5]],
            ["forward",42,undefined,true,[42.5,135.4,22.5]]
        ]
        this.drillWalk = [
            ["right",-8,undefined,false,[0.0,0.0]],
            ["forward",undefined,-66,true,[0.0,0.0]],
            ["right",-9.3,undefined,false,[0.0,0.0]],
            ["forward",undefined,-42,true,[0.0,0.0]],
            ["left",-8,undefined,true,[0.0,0.0]],
            ["forward",-66,undefined,true,[0.0,0.0]],
            ["forward",undefined,-21,true,[0.0,0.0]]
        ]
        this.currentPlace = "NONE"
        this.startItems = {
            drill: undefined,
            etherwarp: undefined,
            pidgeon: undefined,
            pickaxe: undefined,
            weapon: undefined
        }
        
        keyBind.keyBindCommMacro.registerKeyPress(() => {this.toggleComm()})

        register("packetReceived", (packet,event) => {
            let x = packet.func_148932_c() //getX()
            let y = packet.func_148928_d() //getY()
            let z = packet.func_148933_e() //getZ()

            if((this.pidgeonless || !this.atForge) && this.toggle) {
                if(x === 0.5 && y === 149 && z === -68.5) {
                    new Thread(() => {
                        ChatLib.chat(polarPrefix + " Detected the User at the Forge")
                        let onSpawnTime = new Date().getTime()
                        while(this.toggle) {
                            Thread.sleep(100)
                            if(new Date().getTime() - onSpawnTime > 1000) {
                                this.atForge = true
                                break
                            }
                            if(this.isAtForge()) {
                                continue
                            }
                            onSpawnTime = new Date().getTime()
                        }
                    }).start()
                }
            }

            if(this.toggle && autoMine.toggle) {
                if(Math.floor(x) === Math.floor(Player.getX()) && Math.floor(y) === Math.floor(Player.getY()) && Math.floor(z) === Math.floor(Player.getZ())) {
                    ChatLib.chat(polarPrefix + " Getting rotation checked!")
                    this.warnPlayer()
                }
            }
        }).setFilteredClasses([net.minecraft.network.play.server.S08PacketPlayerPosLook])

        register("worldLoad", () => {
            if(this.toggle) {
                if(!this.traversing) {       
                    ChatLib.chat(polarPrefix + " Detected World Change")

                    if(autoMine.toggle) {
                        autoMine.toggleMacro()
                    }
                    if(this.toggleGoblin) {
                        this.toggleGoblinF()
                    }
                    if(this.toggleIceWalker) {
                        this.toggleIceWalkerF()
                    }
        
                    this.traversing = true
        
                    cancelWalk("none")
                    Shift.setState(false)
                }
            }
        })

        register("Chat", (theMsg) => {
            let gtheMsg = ChatLib.getChatMessage(theMsg, false)
            if(gtheMsg.toString().includes("Commission Complete!") && (this.toggle && this.gotSpeed)) {
        
                    if(autoMine.toggle) autoMine.toggleMacro()

                    
                    if(this.toggleGoblin || this.toggleIceWalker) {
                        if(this.toggleGoblin) this.toggleGoblinF()

                        if(this.toggleIceWalker) this.toggleIceWalkerF()

                        this.traversing = true
                        ChatLib.say("/l")
                        return
                    }

                    if(!this.settingPidgeon) {
                        this.usePidgeon()
                    } else {
                        this.pidgeonless = true
                        this.posIndex = 0
                        ChatLib.say("/warp forge")
                    }
            }

            if(gtheMsg.toString().includes("Refuel it by talking to a Drill Mechanic!") && (this.toggle && this.gotSpeed)) {
                this.toggleComm()
            }

            if((gtheMsg.toString().includes("You can't fast travel while in combat!") || gtheMsg.toString().includes("You can't use this while in combat!")) && (this.toggle && this.gotSpeed)) {
                this.traversing = true
            }
        })

        register("command", () => {
            this.toggleGoblinF()
        }).setName("icewalker")

        register("step", () => {
            if(this.toggleIceWalker) {
                if(this.target != undefined) {
                    let mob = this.target.mob
                    let angles = rotationUtils.calculateAngles({x: mob.getX(), y: mob.getY() + 1.5, z: mob.getZ()}, false)
                    if(disToPlyFlat(mob.getX(), mob.getZ()) >= 3.0) {
                        if(angles.yaw < -20) { 
                            WalkRight.setState(false)
                            WalkLeft.setState(true)
                            WalkForward.setState(true)
                            WalkBackward.setState(false)
                        } else if(angles.yaw > 20) {
                            WalkLeft.setState(false)
                            WalkRight.setState(true)
                            WalkForward.setState(true)
                            WalkBackward.setState(false)
                        } else {
                            WalkLeft.setState(false)
                            WalkRight.setState(false)
                            WalkForward.setState(true)
                            WalkBackward.setState(false)
                        }
                    } else {
                        itemUtils.leftClick(0)
                        WalkLeft.setState(false)
                        WalkRight.setState(false)
                        WalkForward.setState(false)
                        WalkBackward.setState(false)
                    }

                    if(rotationUtils.getRotationLength({x: mob.getX(), y: mob.getY() + 1.5, z: mob.getZ()}, false) > 30) {
                        rotationUtils.onStopRotation()
                        rotationUtils.polarRotateTo({x: mob.getX(), y: mob.getY() + 1.5, z: mob.getZ()}, 300)
                    } else {
                        rotationUtils.onStopRotation()
                        rotationUtils.polarRotateTo({x: mob.getX(), y: mob.getY() + 1.5, z: mob.getZ()}, 70)
                    }
                } else {
                    WalkLeft.setState(false)
                    WalkRight.setState(false)
                    WalkForward.setState(false)
                    WalkBackward.setState(false)
                }
            }
        }).setFps(8)

        this.clicked = false
        this.currentCord = null

        this.canShootGoblin = 0
        this.goblinWhiteList = fillJavaArray([])
        this.foundGoblin = false
        this.left = true

        register("tick", () => {
            if(this.toggle && this.gotSpeed) {
                if(this.startAotving) {
                    if(!this.atForge) return
                    this.callCords()
                    if(!this.clicked) {
                        Player.setHeldItemIndex(finder.slotWarp)
                        for(let i = 0; i < this.cords.length; i++) {
                            if(this.cords[i][0] == this.plyX && this.cords[i][1] == (this.plyY - 1) && this.cords[i][2] == this.plyZ) {
                                if(i == (this.cords.length - 1)) {
                                    this.startAotving = false
                                    this.atForge = false

                                    if(this.currentComm === "Goblin Slayer") {
                                        this.toggleGoblinF()
                                    } else if(this.currentComm === "Ice Walker Slayer") {
                                        this.toggleIceWalkerF()
                                    } else {
                                        autoMine.toggleMacro()
                                    }
                                    break
                                }
                                this.clicked = true
                                this.currentCord = this.cords[i + 1]
                                let num1 = this.cords[i + 1][0]
                                let num2 = this.cords[i + 1][1]
                                let num3 = this.cords[i + 1][2]
                                new Thread(() => {
                                    lookAtRayCast(num1, num2, num3, Math.floor(global.exports.settingGet.getSetting(this.configName,"Etherwarp look speed")), true, true)
                                }).start()
                            }
                        }
                    }
                    if(this.clicked) {
                        if(this.currentCord[0] == this.plyX && this.currentCord[1] == (this.plyY - 1) && this.currentCord[2] == this.plyZ) {
                            this.clicked = false
                        }
                    }
                }

                //running when pidgeonless is enabled
                if(this.pidgeonless) {
                    if(!this.atForge) return
                    if(this.posIndex >= this.pidgeonWalk.length) {
                        this.pidgeonless = false
                        cancelWalk("none")
                        this.interactWithNpc()
                        this.getNewComm()
                        return
                    }
                    if(this.walkingAlgoRithem(this.pidgeonWalk[this.posIndex])) {
                        this.posIndex += 1
                    }
                }

                //Runs when the toLobby is started
                if(this.traversing) {
                    let place = this.getCurrentLocation()

                    if(this.currentPlace != place) {
                        this.locationWait = new Date().getTime()
                    }
                    this.currentPlace = place

                    let timeDiff = new Date().getTime() - this.locationWait
                    if(timeDiff > 3000) {
                        if(place === "Forge") {
                            ChatLib.chat(polarPrefix + "Done Warping")

                            if(!this.settingPidgeon) {
                                this.usePidgeon()
                            } else {
                                this.pidgeonless = true
                                this.posIndex = 0
                            }

                            this.atForge = true
                            this.traversing = false
                        }

                        if(place === "Hub") {
                            ChatLib.chat(polarPrefix + "Going to the Forge")
                            ChatLib.say("/warp forge")
                            this.currentPlace = "Forge"
                        }

                        if(place === "Lobby") {
                            ChatLib.chat(polarPrefix + "Going to the Skyblock Mines")
                            ChatLib.say("/skyblock")
                            this.currentPlace = "Mines"
                        }

                        if(place === "Mines") { 
                            ChatLib.chat(polarPrefix + "Going to the Skyblock Hub")
                            ChatLib.say("/warp hub")
                            this.currentPlace = "Hub"
                        }
                    }
                }

                //Runs when the toggleIceWalkerF is started
                if(this.toggleIceWalker) {
                    Player.setHeldItemIndex(finder.slotPickaxe)
                    let players = World.getAllPlayers()
                    let icewalkers = []
                    for(let i = 0; i < players.length; i++) {
                        let player = players[i]
                        if(player.getName() === "Ice Walker" && player.getX() > -34.0 && player.getX() < 34.0 && player.getZ() < 178.0 && player.getZ() > 140.0 && player.entity.func_110143_aJ() > 1.1 && player.getY() > 127.0 && player.getY() < 129.0) icewalkers.push(player) 
                    }
            
                    this.target = undefined
                    for(let i = 0; i < icewalkers.length; i++) {
                        let icewalker = {
                            mob: icewalkers[i],
                            dis: disToPly(icewalkers[i].getX(), icewalkers[i].getY(), icewalkers[i].getZ()) * 2.0,
                            range: degreeRannge(icewalkers[i].getX(), icewalkers[i].getY(), icewalkers[i].getZ() * 0.2)
                        }

                        if(this.target === undefined) this.target = icewalker
                        else if((icewalker.dis + icewalker.range) < (this.target.dis + this.target.range)) this.target = icewalker
                    }
                }

                //Runs when the toggleGoblinF is started
                let time = 500
                if(this.toggleGoblin) {
                    if(Player.getInventory()?.getStackInSlot(finder.slotRange)?.getName().includes("Aurora Staff")) {
                        time = 1100
                    }
                }
                if(this.toggleGoblin && new Date().getTime() - this.canShootGoblin > time) {
                    Shift.setState(true)
                    let players = World.getAllPlayers()
                    let goblins = []
                    for(let i = 0; i < players.length; i++) {
                        let player = players[i]
                        if(player.getName() === "Goblin " && player.entity.func_110143_aJ() > 1.1 && Player.asPlayerMP().canSeeEntity(player) && !this.goblinWhiteList.contains(player.entity.func_145782_y())) goblins.push(player)
                    }
            
                    this.goblin = undefined
                    for(let i = 0; i < goblins.length; i++) {
                        let goblin = {
                            mob: goblins[i],
                            dis: mathUtils.disToPlayerCT(goblins[i]),
                            id: goblins[i].entity.func_145782_y()
                        }
                        if(Player.getInventory()?.getStackInSlot(finder.slotRange)?.getName().includes("Aurora Staff") && goblin.dis > 25) {
                            continue
                        }
                        if(this.goblin === undefined) this.goblin = goblin
                        else if(goblin.dis < this.goblin.dis) this.goblin = goblin
                    }
            
                    if(this.goblin != undefined) {
                        this.foundGoblin = true
                        let mob = this.goblin.mob
                        this.goblinWhiteList.add(this.goblin.id)
                        while(this.goblinWhiteList.size() > 2) this.goblinWhiteList.remove(0)
                        Player.setHeldItemIndex(finder.slotRange)
                        rotationUtils.onStopRotation()
                        rotationUtils.polarRotateTo({x: mob.getX(), y: mob.getY() + 1.2, z: mob.getZ()}, 100, true)
                        itemUtils.rightClick(4)
                    } else {
                        rotationUtils.onStopRotation()
                        if(Player.getY() < 150.0 && Player.getY() > 140.0) {
                            rotationUtils.polarRotateTo({x: -82.5, y: 139.5, z: 155.5}, 300)
                        } else {
                            rotationUtils.polarRotateTo({x: -73.5, y: 154.5,z: 159.5}, 300)
                        }
                    }
            
                    new Thread(() => {
                        this.left = !this.left
                        if(this.left) {
                            WalkLeft.setState(true)
                            Thread.sleep(50)
                            WalkLeft.setState(false)
                        } else {
                            WalkRight.setState(true)
                            Thread.sleep(50)
                            WalkRight.setState(false)
                        }
                    }).start()
            
                    if(this.goblin === undefined && this.foundGoblin) {
                        this.foundGoblin = false
                        new Thread(() => {
                            let plyY = Player.getY()
                            Player.setHeldItemIndex(finder.slotWarp)
                            if(plyY >= 150.0 && plyY < 157.0) {
                                lookAtRayCast(-77,142,144,200,true,true)
                            }
                            else if(plyY < 150.0 && plyY > 140.0) {
                                lookAtRayCast(-68,154,149,200,true,true)
                            }
                        }).start()
                    }
            
                    this.canShootGoblin = new Date().getTime()
                }
            }
        })


        register("packetReceived", (packet, event) => {

            if(autoMine.toggle && this.toggle) {

                if(packet instanceof net.minecraft.network.play.server.S0CPacketSpawnPlayer) {
                    try {
                        let packetid = packet.func_148943_d()
                        Client.scheduleTask(0, () => {
                            let entity = World.getWorld().func_73045_a(packetid)
                            if(entity != null) {
                                if(mathUtils.disToPlayerMC(entity) < 6.0 && !entity.toString().includes("Goblin ")) {
                                    ChatLib.chat(polarPrefix + "Detected Floating player around you")
                                    this.warnPlayer()
                                }
                            }
                        })
                    } catch (error) {
                        ChatLib.chat(error)
                    }
                }

                if(packet instanceof net.minecraft.network.play.server.S12PacketEntityVelocity) {
                    try {
                        if(this.playerNear()) {
                            let entity = World.getWorld().func_73045_a(packet.func_149412_c())
                            if(entity.toString().includes(Player.getName())) {
                                ChatLib.chat(polarPrefix + " Detected Velocity check")
                                this.warnPlayer()
                            }
                        }
                    } catch (error) {}
                }
            }

            this.lastPacket = new Date().getTime()
        })

        /*
        register("tick", () => {
            if(autoMine.toggle && this.toggle) {
                if (
                (Player?.getInventory()?.getStackInSlot(finder.slotDrill)?.getName() != this.startItems?.drill ||
                Player?.getInventory()?.getStackInSlot(finder.slotRange)?.getName() != this.startItems?.weapon ||
                Player?.getInventory()?.getStackInSlot(finder.slotWarp)?.getName() != this.startItems?.etherwarp ||
                (Player?.getInventory()?.getStackInSlot(finder.slotPidgeon)?.getName() != this.startItems?.pidgeon && !this.settingPidgeon) ||
                Player?.getInventory()?.getStackInSlot(finder.slotPickaxe)?.getName() != this.startItems?.pickaxe)
                && this.startItems?.drill != undefined
                ) {
                    ChatLib.chat(polarPrefix + " Item's got replaced")
                    this.warnPlayer()
                }
            }
        })
        */
    }

    toggleComm() {
        finder.bluecheese()
        this.toggle = !this.toggle
        if(this.toggle) {
            this.gotSpeed = false
            this.settingPidgeon = global.exports.settingGet.getSetting(this.configName,"Pidgeonless Mode")
            this.currentArea = "Forge"
            if(finder.drill() && finder.pickaxe() && finder.etherwarp() && finder.range() && (this.settingPidgeon || finder.pidgeon()) && Skyblock.area == "Dwarven Mines") {
                ChatLib.chat(polarPrefix + " Comm Macro: " + this.toggle)
                new Thread(() => {

                    if(autoMine.miningSpeedBoost) {
                        this.toggle = false
                        ChatLib.chat(polarPrefix + " Make sure your mining speed boost is not active");
                        ChatLib.chat(polarPrefix + " Comm Macro: false"); 
                        return "nigga"
                    }

                    Player.setHeldItemIndex(finder.slotDrill)
                    Thread.sleep(500)
                    if(!this.toggle) return

                    sendPacket(new C09PacketHeldItemChange(8))
                    sendPacket(new net.minecraft.network.play.client.C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(8).getItemStack(), 0, 0, 0))
                    sendPacket(new C09PacketHeldItemChange(finder.slotDrill))

                    while(Player.getContainer()?.getName() != "SkyBlock Menu" && this.toggle) {Thread.sleep(10)}
                    if(!this.toggle) return "nigga"

                    while(Player.getContainer().getStackInSlot(13) === null && this.toggle ) {Thread.sleep(10)}
                    if(!this.toggle) return "nigga"

                    let statLore = Player.getContainer().getStackInSlot(13).getLore()
                    let speed = null
                    for(let i = 0; i < statLore.length; i++) {
                        if(statLore[i].removeFormatting().includes("Mining Speed")) {
                            //ChatLib.chat(statLore[i])
                            if(statLore[i].charAt(27) == "") {
                                speed = parseInt(statLore[i].charAt(24) + statLore[i].charAt(25) + statLore[i].charAt(26))
                            } else {
                                speed = parseInt(statLore[i].charAt(24) + statLore[i].charAt(26) + statLore[i].charAt(27) + statLore[i].charAt(28))
                            }
                            break
                        }
                    }
                    if(speed === NaN) {
                        this.toggle = false; 
                        ChatLib.chat(polarPrefix + " Something went wrong try again"); 
                        ChatLib.chat(polarPrefix + " Comm Macro: " + this.toggle);
                        return "nigga"
                    }
                    //ChatLib.chat(speed)
                    ChatLib.say("/hotm")
                    //Player.getContainer()?.click(10,false,"MIDDLE")

                    while(Player.getContainer()?.getName() != "Heart of the Mountain" && this.toggle) {Thread.sleep(10)}

                    if(!this.toggle) return "nigga"
                    Thread.sleep(100)
                    Player.getContainer()?.click(8,false,"RIGHT")
        
                    while(Player.getContainer()?.getStackInSlot(12) === null && this.toggle) {Thread.sleep(10)}
                    if(!this.toggle) return "nigga"
        
                    while(!Player.getContainer()?.getStackInSlot(12)?.getName()?.removeFormatting()?.includes("Professional") && this.toggle) {Thread.sleep(10)}
                    Thread.sleep(100)
                    if(!this.toggle) return "nigga"

                    let profSpeed = null
                    let loreProf = Player.getContainer()?.getStackInSlot(12).getLore()
                    for(let i = 0; i < loreProf.length; i++) {
                        if(loreProf[i].removeFormatting().includes("Gain")) {
                            profSpeed = parseInt(loreProf[i].charAt(16) + loreProf[i].charAt(17) + loreProf[i].charAt(18))
                            break
                        }
                    }

                    //ChatLib.chat(profSpeed)
                    if(profSpeed === NaN) {
                        this.toggle = false; 
                        ChatLib.chat(polarPrefix + " Something went wrong try again");
                        ChatLib.chat(polarPrefix + " Comm Macro: " + this.toggle); 
                        return "nigga";
                    }

                    if(!this.toggle) return "nigga"

                    setSpeeds(speed, Math.floor(speed + profSpeed))

                    Client.scheduleTask(0, () => {Client.currentGui.close()})
                    Thread.sleep(100)
                    this.gotSpeed = true

                    autoMine.ms = global.exports.settingGet.getSetting(this.configName,"Mining look speed")
                    autoMine.maxRotation = global.exports.settingGet.getSetting(this.configName, "Max rotation")
                    autoMine.useNuker = global.exports.settingGet.getSetting(this.configName, "Use nuker")
                    autoMine.sneak = false
                    autoMine.precisionMiner = false
                    autoMine.bigblock = false

                    if(this.toggle) {
                            autoMine.onlyMine(false,false,true)
                            this.pidgeonless = this.settingPidgeon
                            this.startAotving = false

                            /*
                            try {
                                if(finder.slotDrill != undefined) this.startItems.drill = Player.getInventory()?.getStackInSlot(finder.slotDrill)?.getName()
                                if(finder.slotWarp != undefined) this.startItems.etherwarp = Player.getInventory()?.getStackInSlot(finder.slotWarp)?.getName()
                                if(finder.slotPidgeon != undefined) this.startItems.pidgeon = Player.getInventory()?.getStackInSlot(finder.slotPidgeon)?.getName()
                                if(finder.slotPickaxe != undefined) this.startItems.pickaxe = Player.getInventory()?.getStackInSlot(finder.slotPickaxe)?.getName()
                                if(finder.slotRange != undefined) this.startItems.weapon = Player.getInventory()?.getStackInSlot(finder.slotRange)?.getName()
                            } catch (error) {
                                ChatLib.chat(error)
                            }
                            */

                            //ChatLib.say("/warp forge")
                            if(!this.settingPidgeon) {
                                this.usePidgeon()
                            } else {
                                this.posIndex = 0
                                this.pidgeonless = true
                                ChatLib.say("/warp forge")
                            }
                    }
                }).start()
            } else {
                ChatLib.chat(polarPrefix + "Comm Macro: You are missing:")
                if(Skyblock.area != "Dwarven Mines") ChatLib.chat("- Being in the Dwarven Mines")
                if(!finder.drill()) ChatLib.chat("- Drill")
                if(!finder.pickaxe()) ChatLib.chat("- Pickaxe (For Ice Walker Slayer)")
                if(!finder.etherwarp()) ChatLib.chat("- Etherwarp")
                if(!finder.range())  ChatLib.chat("- Frozen Scythe")
                if(!finder.pidgeon() && !global.exports.settingGet.getSetting(this.configName,"Pidgeonless Mode")) ChatLib.chat("- Royal Pigeon")
                this.toggle = false
            }
        } else {
            ChatLib.chat(polarPrefix + " Comm Macro: " + this.toggle)
            autoMine.onlyMine(false,false,false)

            if(autoMine.toggle) {
                autoMine.toggleMacro()
            }
            if(this.toggleGoblin) {
                this.toggleGoblinF()
            }
            if(this.toggleIceWalker) {
                this.toggleIceWalkerF()
            }

            this.traversing = false
            this.pidgeonless = false
            this.atForge = false

            cancelWalk("none")
            Shift.setState(false)
        }

        toggle.commisionMacro = this.toggle
        writeSave()
    }

    isAtForge() {
        if(Player.getX() > -1.0 && Player.getX() < 1.0 && Player.getY() > 148.0 && Player.getY() < 150.0 && Player.getZ() > -70.0 && Player.getZ() < -68.0) {
            return true
        }
        return false
    }

    toggleGoblinF() {
        this.toggleGoblin = !this.toggleGoblin
        if(this.toggleGoblin) {
            ChatLib.chat(polarPrefix + "Started Goblin Slayer")
        } else {
            ChatLib.chat(polarPrefix + "Stopped Goblin Slayer")
            Shift.setState(false)
        }
    }

    toggleIceWalkerF() {
        this.toggleIceWalker = !this.toggleIceWalker
        if(this.toggleIceWalker) {
            ChatLib.chat(polarPrefix + "Started Ice Walker Slayer")
        } else {
            ChatLib.chat(polarPrefix + "Stopped Ice Walker Slayer")
        }
    }

    warnPlayer() {
        new Thread(() => {
            for(let i = 0; i < 100; i++) {
                Thread.sleep(50)
                World.playSound('mob.ghast.scream', 1000, 100)
            }
        }).start()
        if(this.toggle) {
            this.toggleComm()
        }
    }

    

    //returns the current locations
    getCurrentLocation() {
        let plyX = Player.getX()
        let plyY = Player.getY()
        let plyZ = Player.getZ()
        if(plyY > 148.0 && plyY < 150.0 && plyX < 1.5  && plyX > -1.5 && plyZ < -67.5 && plyZ > -69.0) return "Forge"
        else if(plyY > 69.0 && plyY < 71.0 && plyX < -1.5 && plyX > -3.5 && plyZ > -70.5 && plyZ < -68.5) return "Hub"
        else if(plyY > 68.0 && plyY < 70.0 && plyX < -139.0 && plyX > -159.0 && plyZ < 158.0 && plyZ > 138.0) return "Lobby"
        else if(plyY > 199.0 && plyY < 201.0 && plyX < -46.0 && plyX > -50.0 && plyZ < -119.0 && plyZ > -123.0) return "Mines"
    }

    interactWithNpc() {
        let players = World.getAllPlayers()
        for(let i = 0; i < players.length; i++) {
            let player = players[i]
            if(player.getX() === 42.5 && player.getY() === 134.5 && player.getZ() === 22.5) {
                mc.field_71442_b.func_78768_b(Player.getPlayer(), player.entity)
                break
            }
        }
    }

    usePidgeon() {
        new Thread(() => {
            Player.setHeldItemIndex(finder.slotPidgeon)
            itemUtils.rightClick(10)
            this.getNewComm()
        }).start()
    }

    playerNear() {
        let Players = World.getAllPlayers()
        for(let i = 0; i < Players.length; i++) {
            let player = Players[i]
            if(mathUtils.disToPlayerCT(player) < 10 && Player.getName() != player.getName()) {
                return true
            }
        }
        return false
    }

    getNewComm() {
        new Thread(() => {
            while(this.toggle && Player?.getContainer()?.getName() != "Commissions") {
                Thread.sleep(50)
            }
            if(this.toggle) {
                this.currentComm = undefined
                let plyCont = Player.getContainer()
                for(let i = 9; i < 17; i++) {
                    let stack = plyCont.getStackInSlot(i)
                    if(stack != null) {
                        let lore = stack.getLore()
                        for(let t = 0; t < lore.length; t++) {
                            if(lore[t].includes("COMPLETED")) {
                                plyCont.click(i,false,"LEFT")
                            }
                        }
                    }
                }
            }
            Thread.sleep(500)
            if(this.toggle) {
                let plyCont = Player.getContainer()
                for(let i = 9; i < 17; i++) {
                    let stack = plyCont.getStackInSlot(i)
                    if(stack != null) {
                        for(let t = 0; t < commissions.length; t++) {
                            let lore = stack.getLore()
                            for(let r = 0; r < lore.length; r++) {
                                if(lore[r].removeFormatting().includes(commissions[t]) && !lore[r].removeFormatting().includes("Golden Goblin")) {
                                    this.currentComm = commissions[t]
                                }
                            }
                        } 
                    }
                }

                Client.scheduleTask(0, () => {Client.currentGui.close()})

                if(this.currentComm?.includes("Titanium")) {
                    toggle.titanium = true
                } else {
                    toggle.titanium = false
                }
                writeSave()

                this.commCords(this.currentComm)
                let last = (this.cords.length - 1)
                this.callCords()
                if(this.cords[last][0] == this.plyX && this.cords[last][1] == (this.plyY - 1) && this.cords[last][2] == this.plyZ) {
                    if(this.currentComm === "Goblin Slayer") {
                        this.toggleGoblinF()
                    } else if(this.currentComm === "Ice Walker Slayer") {
                        this.toggleIceWalkerF()
                    } else {
                        autoMine.toggleMacro()
                    }
                    return
                }

                /*if(!this.atForge)*/ ChatLib.say("/warp forge")
                this.atForge = false
                this.pidgeonless = false
                this.startAotving = true
                this.currentCord = [0,148,-69]
            }
        }).start()
    }

    walkingAlgoRithem(instructions) {
        let direction = instructions[0]
        let x = instructions[1]
        let z = instructions[2]
        let biggerThen = instructions[3]
        let array = instructions[4]
        //walkDirection.direction
        this.callCords()

        cancelWalk(direction)

        if(array != undefined) {
            if(array[2] != undefined) {
                lookAt(array[0],array[1],array[2], 50, false, false)
            } else {
                setYaw(array[0])
                setPitch(array[1])
            }
        }

        if(x != undefined) {
            if(biggerThen) {
                if(Player.getX() > x) {
                    return true
                } else {
                    return false
                }
            } else {
                if(Player.getX() < x) {
                    return true
                } else {
                    return false
                }
            }
        } else if(z != undefined) {
            if(biggerThen) {
                if(Player.getZ() > z) {
                    return true
                } else {
                    return false
                }
            } else {
                if(Player.getZ() < z) {
                    return true
                } else {
                    return false
                }
            }
        }
    }

    commCords(theCommName) {
        if(theCommName === "Rampart's Quarry Titanium" || theCommName === "Rampart's Quarry Mithril") {this.cords = [[0,148,-69],[0,165,-12],[-16,179,-27],[-64,210,-24],[-88,200,-34],[-67,168,-59],[-70,169,-59]]} else
        if(theCommName === "Upper Mines Titanium" || theCommName === "Upper Mines Mithril") {this.cords = [[0,148,-69],[0,165,-12],[-16,179,-27],[-64,210,-24],[-94,220,-40],[-113,227,-47],[-129,216,-47]]} else
        if(theCommName === "Royal Mines Titanium" || theCommName === "Royal Mines Mithril") {this.cords = [[0,148,-69],[0,165,-12],[25,176,7],[51,161,59],[106,156,37],[109,160,33],[116,159,21],[114,158,23]]} else
        if(theCommName === "Titanium Miner" || theCommName === "Mithril Miner") {this.cords = [[0,148,-69],[0,165,-12],[-16,179,-27],[-64,210,-24],[-88,200,-34],[-67,168,-59],[-70,169,-59]]} else
        if(theCommName === "Cliffside Veins Mithril" || theCommName === "Cliffside Veins Titanium") {this.cords = [[0,148,-69],[0,165,-12],[25,176,7],[28,175,65],[27,138,22]]} else
        if(theCommName === "Goblin Slayer") {this.cords = [[0,148,-69],[0,165,-12],[25,176,7],[27,179,67],[-8,161,106],[9,130,129],[-26,131,170],[-48,137,147],[-68,154,149]]} else
        if(theCommName === "Lava Springs Mithril" || theCommName === "Lava Springs Titanium") {this.cords = [[0,148,-69],[0,165,-12],[33,201,-12],[43,206,-6],[51,215,-30]]} else
        if(theCommName === "Ice Walker Slayer") {this.cords = [[0,148,-69],[0,165,-12],[25,176,7],[27,179,67],[-8,161,106],[9,130,129],[-18,131,174]]}
    }

    callCords() {
        this.plyX = Math.floor(Player.getX())
        this.plyY = Player.getY()
        this.plyZ = Math.floor(Player.getZ())
    }
}

global.exports.commisionMacro = new commisionMacro()