let { SettingSelector, SettingSlider, SettingToggle, ConfigModuleClass, ModuleToggle, getKeyBind, ModuleManager } = global.settingSelection
let { MiningBot, ChatUtils, TimeHelper, MovementHelper, Rotations, PolarPathFinder, MouseUtils, Vector, Utils, MathUtils, MiningUtils, ItemUtils, RaytraceUtils, SkyblockUtils } = global.export;
global.modules.push(
    new ConfigModuleClass(
        "Commission Macro",
        "Mining",
        [
            new SettingSlider("Weapon slot", 1, 1, 9),
            new SettingToggle("Use a ranged weapon for slayer commissions", false),
            new SettingToggle("Use a drill for ice walker slayer", true),
            new SettingToggle("Pigeon", false),
            new SettingSelector("Travel method", 0, ["Walking","Aspect of the end","Etherwarp"]),
            new SettingSlider("Etherwarp cooldown", 0, 0, 10000)
        ],
        [
            "Does Dwarven Mines commissions without an etherwarp item"
        ]
    )
)

class PolarCommissionMacro {
    constructor() {
        this.ModuleName = "Commission Macro"
        getKeyBind("Commission Macro","Polar Client - Mining", this);
        this.Enabled = false
        this.state;
        this.STATES = {
            MOVE: 0,
            CLAIMCOMMISSION: 1,
            MINE: 2,
            TRAVELTOLOCATION: 3,
            GOBLIN: 4,
            ICEWALKER: 5,
            REPLACE: 6,
            SELL: 7,
            WARPFORGE: 8,
            WAITING: 9
        }
        this.METHOD = {
            WALKING: 0,
            AOTE: 1,
            ETHERWARP: 2
        }
        this.tickCounter = 0
        this.timer = new TimeHelper();

        this.npc_routes = {
            "Walking": [[new CommissionMarker(4,146,-35,this.METHOD.WALKING), new CommissionMarker(41,135,18,this.METHOD.WALKING)],[new CommissionMarker(14,144,-11,this.METHOD.WALKING),new CommissionMarker(37,135,15,this.METHOD.WALKING)]],
            "Aspect of the end": [[new CommissionMarker(6,146,-33,this.METHOD.WALKING),new CommissionMarker(41,135,18,this.METHOD.WALKING)], [new CommissionMarker(10,150,-16,this.METHOD.AOTE),new CommissionMarker(41,135,18,this.METHOD.WALKING)]],
            "Etherwarp": [[new CommissionMarker(3,146,-56,this.METHOD.WALKING), new CommissionMarker(9,152,-10,this.METHOD.ETHERWARP), new CommissionMarker(36,141,11,this.METHOD.AOTE), new CommissionMarker(40,135,17,this.METHOD.WALKING)],[new CommissionMarker(0,160,-14,this.METHOD.ETHERWARP), new CommissionMarker(36,138,8,this.METHOD.ETHERWARP)]]
        }

        this.routes = [
            {
                commission_names: ["Titanium Miner","Mithril Miner"]
            },
            {
                commission_names: ["Royal Mines Titanium","Royal Mines Mithril"],
                "Walking": {
                    location_path: [[new CommissionMarker(68,134,34,this.METHOD.WALKING), new CommissionMarker(111,153,41,this.METHOD.WALKING)]],
                    mine_path: [[new CommissionMarker(141,152,26,this.METHOD.WALKING)], [new CommissionMarker(114,158,23,this.METHOD.WALKING)], [new CommissionMarker(161,150,91,this.METHOD.WALKING)]]
                },
                "Aspect of the end": {
                    location_path: [[new CommissionMarker(85,143,39,this.METHOD.AOTE), new CommissionMarker(112,156,41,this.METHOD.AOTE)],[new CommissionMarker(56,135,27,this.METHOD.WALKING), new CommissionMarker(96,155,40,this.METHOD.AOTE), new CommissionMarker(112,153,41,this.METHOD.WALKING)]],
                    mine_path: [[new CommissionMarker(141,152,26,this.METHOD.WALKING)], [new CommissionMarker(153,150,34,this.METHOD.WALKING), new CommissionMarker(165,168,22,this.METHOD.AOTE), new CommissionMarker(168,160,18,this.METHOD.WALKING)],[new CommissionMarker(116,158,27,this.METHOD.AOTE), new CommissionMarker(114,163,20,this.METHOD.AOTE), new CommissionMarker(115,158,22,this.METHOD.WALKING)]]
                },
                "Etherwarp": {
                    location_path: [[new CommissionMarker(97,151,41,this.METHOD.AOTE), new CommissionMarker(111,158,41,this.METHOD.AOTE), new CommissionMarker(119,154,35,this.METHOD.WALKING)]],
                    mine_path: [[new CommissionMarker(139,153,28,this.METHOD.ETHERWARP), new CommissionMarker(141,152,26,this.METHOD.WALKING)], [new CommissionMarker(115,159,25,this.METHOD.ETHERWARP), new CommissionMarker(115,157,23,this.METHOD.ETHERWARP)], [new CommissionMarker(168,156,28,this.METHOD.ETHERWARP), new CommissionMarker(167,160,23,this.METHOD.ETHERWARP), new CommissionMarker(169,160,18,this.METHOD.WALKING)]]
                },
                from_forge: false,
                etherwarp_forge: false
            },
            {
                commission_names: ["Cliffside Veins Mithril","Cliffside Veins Titanium"],
                "Walking": {
                    location_path: [],
                    mine_path: []
                },
                "Aspect of the end": {
                    location_path: [],
                    mine_path: []
                },
                "Etherwarp": {
                    location_path: [],
                    mine_path: []
                },
                from_forge: false,
                etherwarp_forge: false
            },
            {
                commission_names: ["Upper Mines Titanium","Upper Mines Mithril"],
                "Walking": {
                    location_path: [],
                    mine_path: []
                },
                "Aspect of the end": {
                    location_path: [],
                    mine_path: []
                },
                "Etherwarp": {
                    location_path: [],
                    mine_path: []
                },
                from_forge: true,
                etherwarp_forge: true
            },
            {
                commission_names: ["Rampart's Quarry Titanium","Rampart's Quarry Mithril"],
                "Walking": {
                    location_path: [],
                    mine_path: []
                },
                "Aspect of the end": {
                    location_path: [],
                    mine_path: []
                },
                "Etherwarp": {
                    location_path: [],
                    mine_path: []
                },
                from_forge: true,
                etherwarp_forge: true
            },
            {
                commission_names: ["Lava Springs Mithril","Lava Springs Titanium"],
                "Walking": {
                    location_path: [],
                    mine_path: []
                },
                "Aspect of the end": {
                    location_path: [],
                    mine_path: []
                },
                "Etherwarp": {
                    location_path: [],
                    mine_path: []
                },
                from_forge: true,
                etherwarp_forge: true
            },
            {
                commission_names: ["Goblin Slayer"],
                "Walking": {
                    location_path: [],
                    mine_path: []
                },
                "Aspect of the end": {
                    location_path: [],
                    mine_path: []
                },
                "Etherwarp": {
                    location_path: [],
                    mine_path: []
                },
                from_forge: false,
                etherwarp_forge: true
            },
            {
                commission_names: ["Glacite Walker Slayer"],
                "Walking": {
                    location_path: [[new CommissionMarker(24,127,45,this.METHOD.WALKING), new CommissionMarker(0,127,98,this.METHOD.WALKING)]],
                    mine_path: [[new CommissionMarker(0,127,150,this.METHOD.WALKING)]]
                },
                "Aspect of the end": {
                    location_path: [[new CommissionMarker(2,132,64,this.METHOD.AOTE)]],
                    mine_path: [[new CommissionMarker(0,127,150,this.METHOD.WALKING)]]
                },
                "Etherwarp": {
                    location_path: [[new CommissionMarker(3,146,-56,this.METHOD.WALKING), new CommissionMarker(1,170,-4,this.METHOD.ETHERWARP), new CommissionMarker(-2,183,24,this.METHOD.ETHERWARP), new CommissionMarker(-2,181,34,this.METHOD.WALKING), new CommissionMarker(-8,161,66,this.METHOD.ETHERWARP), new CommissionMarker(0,127,112,this.METHOD.ETHERWARP)]],
                    mine_path: [[new CommissionMarker(0,127,154,this.METHOD.AOTE)]]
                },
                from_forge: false,
                etherwarp_forge: true
            }
        ]

        register("tick", () => {
            if( !this.Enabled) return
            this.tickCounter++
            switch (this.state) {
                case this.STATES.WARPFORGE:
                    if (MathUtils.getDistanceToPlayer(Utils.convertToVector([0,149,-68])).distance < 2.0 && this.timer.hasReached(2000)) return this.setState(this.STATES.MOVE);
                    break;
                case this.STATES.MOVE:
                    if ((!this.commission || this.pigeon || this.travel_method === "Etherwarp") && this.current_point?.num === 0 && MathUtils.getDistanceToPlayer(Utils.convertToVector([0,149,-68])).distance < 1.0 && this.received_s08 && this.warped_to_forge) {
                        if (this.timer.hasReached(2000)) this.warped_to_forge = false;
                        return;
                    } else if(this.warped_to_forge) return this.timer.reset(); //wait till it is at forge
                    if (
                        this.first_point || 
                        (this.current_point.method === this.METHOD.WALKING && !PolarPathFinder.currentNode) ||
                        (this.current_point.method === this.METHOD.AOTE && MathUtils.getDistanceToPlayerEyes(this.current_point.center).distance < 6.0) ||
                        (this.current_point.method === this.METHOD.ETHERWARP && this.received_s08 && MathUtils.getDistanceToPlayer(this.current_point.center).distance < 2.0)
                    ) {
                        if (!this.first_point) this.current_point = this.current_point.next(this.current_route); // bad code I know 
                        if (!this.current_point) {
                            if (!this.commission) return this.setState(this.STATES.CLAIMCOMMISSION);
                            else if (!this.is_mine_path) {
                                this.current_route = this.commission.route_data[this.travel_method].mine_path[Math.floor(Math.random() * this.commission.route_data[this.travel_method].mine_path.length)];
                                this.current_point = this.current_route[0];
                                this.current_point.num = 0;
                                this.first_point = true;
                                this.is_mine_path = true;
                            } else {
                                if (this.commission.name === "Goblin Slayer") this.setState(this.STATES.GOBLIN);
                                else if (this.commission.name === "Glacite Walker Slayer") this.setState(this.STATES.ICEWALKER);
                                else {
                                    MovementHelper.stopMovement();
                                    Rotations.stopRotate();
                                    this.setState(this.STATES.MINE);
                                }
                                return;
                            }
                        }
                        if (this.current_point.method === this.METHOD.WALKING) {
                            MovementHelper.setKey("shift", false);
                            PolarPathFinder.findPath(Utils.getPlayerNode().getBlockPos(), this.current_point.vec.getBlockPos());
                        } else if (this.current_point.method === this.METHOD.AOTE) {
                            MovementHelper.setKey("shift", false);
                            this.tickCounter = 5;
                            this.random_aote = 10;
                            Player.setHeldItemIndex(this.warp_item.slot);
                        } else if (this.current_point.method === this.METHOD.ETHERWARP) {
                            Rotations.stopRotate();
                            MovementHelper.stopMovement();
                            MovementHelper.setKey("shift", true);
                            this.tickCounter = -Math.floor(ModuleManager.getSetting(this.ModuleName, "Etherwarp cooldown")/50);
                            this.received_s08 = false;
                        }
                        this.first_point = false;
                    }

                    switch (this.current_point.method) {
                        case this.METHOD.WALKING:
                            if (!PolarPathFinder.currentNode) return ChatLib.chat("GONE WRONG!");
                            Rotations.rotateTo(Utils.convertToVector(PolarPathFinder.currentNode.lookPoint));
                            MovementHelper.setPathFindKeys(MathUtils.calculateAngles(Utils.convertToVector(PolarPathFinder.currentNode.point)).yaw);
                            if (Player.getMotionY() < -0.1) {
                                MovementHelper.setKey("w", false);
                                MovementHelper.setKey("s", true);
                            }
                            MovementHelper.setKey("shift", this.is_mine_path && MathUtils.getDistanceToPlayer(this.current_point.center).distance < 2.5 && Math.round(Player.getY() - 1) === this.current_point.y);
                            break;
                        case this.METHOD.AOTE:
                            MovementHelper.stopMovement();
                            MovementHelper.setKey("w", true);
                            Rotations.rotateTo(this.current_point.center);
                            let angles = MathUtils.calculateAngles(this.current_point.center);
                            if (Math.abs(angles.yaw) + Math.abs(angles.pitch) < 20 && this.tickCounter >= this.random_aote) {
                                this.tickCounter = 0;
                                this.random_aote = Math.floor(10 - (Math.random() * 3));
                                ItemUtils.rightClickPacket();
                            }
                            break;
                        case this.METHOD.ETHERWARP:
                            if (this.tickCounter === 0 && !this.received_s08) {
                                let result = RaytraceUtils.getPointOnBlock(this.current_point.vec.getBlockPos());
                                if (result) {
                                    MovementHelper.stopMovement();
                                    Rotations.rotateTo(new Vector(result))
                                    Rotations.onEndRotation(() => {ItemUtils.rightClickPacket(3)});
                                } else {
                                    Rotations.rotateTo(this.current_point.center);
                                    MovementHelper.stopMovement();
                                    MovementHelper.setKey("w", true);
                                    this.tickCounter = -1;
                                }
                            }
                            if(this.received_s08) {
                                ChatLib.chat("STUCK!!")
                            }
                            break;
                    }
                    break;

                case this.STATES.CLAIMCOMMISSION:
                    let npc = Utils.convertToVector([42.5,135,22.5]);
                    let player_container = Player.getContainer()
                    if (player_container && player_container.getName() === "Commissions") {
                        Rotations.stopRotate();
                        MovementHelper.stopMovement();
                        if (!this.timer.hasReached(1000)) return;
                        let commissions = [];
                        let items = player_container.getItems();
                        for (let i = 9; i <= 16; i++) {
                            let commission_item = items[i];
                            if (!commission_item) return;
                            let commission_lore = commission_item.getLore();
                            for (let j = 0; j < commission_lore.length; j++) {
                                let commission_line = commission_lore[j].removeFormatting();
                                if (commission_line.includes("COMPLETED")) {
                                    this.timer.reset();
                                    return player_container.click(i, false, "LEFT");
                                }
                                this.routes.forEach(route_data => {
                                    if (route_data.commission_names.indexOf(commission_line) != -1) {
                                        commissions.push(new PolarCommission(commission_line, route_data));
                                    }
                                })
                            }
                        }
                        let filter_commissions = commissions.filter(commission => !commission.name.includes("Slayer"));
                        if (filter_commissions.length === 0.0) this.commission = commissions[0];
                        else this.commission = filter_commissions[0];
                        this.sendMacroMessage("Doing " + this.commission.name);
                        Client.currentGui.close();
                        if (this.pigeon && this.commission.route_data.commission_names.toString() === this.previous_commission?.route_data?.commission_names?.toString()) return this.setState(this.STATES.MINE);
                        if (this.commission.name === "Titanium Miner" || this.commission.name === "Mithril Miner") {
                            if (this.pigeon && !this.previous_commission?.name?.includes("Slayer")) return this.setState(this.STATES.MINE);
                            else {
                                let random_route = this.routes[Math.floor(Math.random() * this.routes.length)];
                                this.commission.route_data[this.travel_method] = random_route[this.travel_method];
                                this.commission.route_data.from_forge = random_route.from_forge;
                                this.commission.route_data.etherwarp_forge = random_route.etherwarp_forge;
                            }
                        }
                        this.setState(this.STATES.MOVE);
                    } else if (!this.pigeon) {
                        let angles = MathUtils.calculateAngles(npc);
                        let distance = MathUtils.getDistanceToPlayerEyes(npc).distance;
                        let angle_distance = Math.abs(angles.yaw) + Math.abs(angles.pitch);
                        if (angle_distance < 10 && distance > 3.0) MovementHelper.setPathFindKeys(angles.yaw);
                        else MovementHelper.stopMovement();
                        if (Player.getMotionY() < -0.1) {
                            MovementHelper.setKey("w", false);
                            MovementHelper.setKey("s", true);
                        }
                        Rotations.rotateTo(npc);
                        if (distance < 3.0 && angle_distance < 10 && Player.lookingAt() instanceof Entity && !this.interacted) {
                            ItemUtils.rightClick();
                            this.interacted = true;
                            this.timer.reset();
                        }
                    } else if (!this.interacted) {
                        this.interacted = true;
                        this.timer.reset();
                        Client.scheduleTask(3, () => {Player.setHeldItemIndex(this.pigeon_item.slot)})
                        Client.scheduleTask(3 + Math.round(Math.random() * 10), () => {ItemUtils.rightClickPacket()})
                    }
                    break;
                
                case this.STATES.REPLACE:
                    if (this.tickCounter === 20 || this.tickCounter === 80) {
                        let slot = this.getPickonimbusSlot();
                        if (slot === undefined) return this.stop("You don't have another pickonimbus to continue with");
                        if (slot >= 36) {
                            this.drill = Utils.getItem(slot - 36);
                            this.blue_cheese = this.drill;
                            return Client.currentGui.close();
                        }
                        if (this.tickCounter === 80) this.stop("Something has gone wrong dm @implodent");
                    }
                    if (this.tickCounter === 40) Client.getMinecraft().func_147108_a(new net.minecraft.client.gui.inventory.GuiInventory(Player.getPlayer()));
                    if (this.tickCounter === 60) Player.getContainer().click(this.getPickonimbusSlot(), true, "LEFT");
                    if (this.tickCounter === 90) this.setState(this.previous_state);
                    break;
                
                case this.STATES.MINE:
                    if(!MiningBot.Enabled) {
                        MiningBot.toggle(
                            MiningBot.MACROTYPES.COMMISSION,
                            this.commission.titanium,
                            this.miningSpeed,
                            this.drill,
                            this.blue_cheese,
                            false,
                            false,
                            false,
                            false
                        )
                    }
                    break;

                case this.STATES.GOBLIN:
                case this.STATES.ICEWALKER:
                    if (!this.current_mob_id || this.rescan_timer.hasReached(1000)) {
                        let mob_names = this.state === this.STATES.GOBLIN ? ["Goblin ","Weakling "] : ["Ice Walker","Glacite Walker"]
                        let closest_mob = null;
                        let lowest_cost;
                        World.getAllPlayers().filter(player => mob_names.indexOf(player.getName()) != -1 && this.killed_mobs.indexOf(player.getEntity().func_145782_y()) == -1 && player.canBeCollidedWith() && player.entity.func_110143_aJ() > 1.1 && !player.isInvisible() && this.isInSlayerLocation(this.state, player)).forEach(slayer_mob => {
                            let cost = this.getMobCost(this.state, slayer_mob);
                            if (!closest_mob || cost < lowest_cost) {
                                closest_mob = slayer_mob;
                                lowest_cost = cost;
                            }
                        })
                        if (!closest_mob) return Rotations.rotateTo(Utils.convertToVector([35,130,158]));
                        this.current_mob_id = closest_mob.getEntity().func_145782_y();
                        this.last_mob_location = Utils.convertToVector(closest_mob);
                        this.rescan_timer = new TimeHelper();
                        PolarPathFinder.clearPath();
                    }
                    ItemUtils.setItemSlot(this.use_drill && this.state === this.STATES.ICEWALKER ? this.drill.slot : this.weapon_item.slot);

                    while (this.killed_mobs.length >= 6) this.killed_mobs.shift();

                    let current_mob = World.getWorld().func_73045_a(this.current_mob_id);
                    if (!current_mob || current_mob.func_110143_aJ() < 1.1) {
                        PolarPathFinder.clearPath();
                        this.current_mob_id = undefined;
                        return this.killed_mobs.push(this.current_mob_id);
                    }
                    current_mob = new Entity(current_mob);

                    let canSeeMob = Player.asPlayerMP().canSeeEntity(current_mob);
                    let flag_ranged = (this.ranged_weapons && this.state === this.STATES.GOBLIN) || (this.ranged_weapons && !this.use_drill && this.state === this.STATES.ICEWALKER);
                    if (canSeeMob && (MathUtils.getDistanceToPlayerEyes(current_mob).distance < 3.5 || flag_ranged)) {
                        if (this.timer.reachedRandom()) {
                            flag_ranged ? ItemUtils.rightClickPacket() : ItemUtils.leftClick();
                            this.timer.reset();
                            this.timer.setRandomReached(flag_ranged ? 700 : 100, flag_ranged ? 1000 : 200);
                        }
                        if (MathUtils.getDistanceToPlayerEyes(current_mob).distance < 3.5) {
                            MovementHelper.stopMovement();
                            return Rotations.rotateTo(Utils.convertToVector(current_mob).add(0.1, 1.25, 0.1));
                        }
                    }

                    if (!canSeeMob && (!PolarPathFinder.currentNode || MathUtils.getDistance(this.last_mob_location, current_mob).distance > 8.0)) {
                        if (!PolarPathFinder.findPath(Utils.getPlayerNode().getBlockPos(), Utils.getEntityPathfindLocation(current_mob.getEntity()).getBlockPos())) {
                            PolarPathFinder.clearPath();
                            this.current_mob_id = undefined;
                            return this.killed_mobs.push(this.current_mob_id);
                        }
                    }

                    Rotations.rotateTo(canSeeMob ? Utils.convertToVector(current_mob).add(0.1, 1.25, 0.1) : Utils.convertToVector(PolarPathFinder.currentNode.lookPoint));
                    MovementHelper.setPathFindKeys(MathUtils.calculateAngles(canSeeMob ? Utils.convertToVector(current_mob) : Utils.convertToVector(PolarPathFinder.currentNode.point)).yaw);
                    break;

                case this.STATES.SELL:
                    if (MathUtils.getDistanceToPlayer(Utils.convertToVector([-3,69,-70])).distance < 2.0 && this.warped_to_forge) this.warped_to_forge = false;
                    else if(this.warped_to_forge) return; //wait till it is in da hub
                    let npc_sell = Utils.convertToVector([15.5, 71.3, -71.8125]);
                    let ply_container = Player.getContainer()
                    if (ply_container && ply_container.getName() === "Farm Merchant") {
                        Rotations.stopRotate();
                        MovementHelper.stopMovement();
                        if (this.timer.reachedRandom()) {
                            this.timer.reset();
                            this.timer.setRandomReached(500, 800);
                            let items = ply_container.getItems();
                            let sell_items = ["Titanium","Mithril","Rune","Glacite","Goblin"];
                            for (let i = 54; i < items.length; i++) {
                                let item = items[i];
                                if (!item) continue;
                                let name = item.getName();
                                let item_id = item.getID();
                                if ([351,278,274,409,257].indexOf(item_id) != -1) continue;
                                for (let j = 0; j < sell_items.length; j++) {
                                    let sell = sell_items[j];
                                    if (name.includes(sell)) return ply_container.click(i, false, "LEFT");
                                }
                            }
                            Client.currentGui.close();
                            this.setState(this.STATES.WARPFORGE);
                        }
                    } else {
                        let near_npc = MathUtils.getDistanceToPlayerEyes(npc_sell).distance < 4.0;
                        near_npc ? MovementHelper.stopMovement() : MovementHelper.setPathFindKeys(MathUtils.calculateAngles(npc_sell).yaw, false);
                        Rotations.rotateTo(npc_sell);
                        let npc_angles = MathUtils.calculateAngles(npc_sell)
                        if (near_npc && Math.abs(npc_angles.yaw) + Math.abs(npc_angles.pitch) < 10 && Player.lookingAt() instanceof Entity && !this.interacted) {
                            ItemUtils.rightClick();
                            this.interacted = true;
                        }
                    }

                    //[14,69,-72]
                    break;
            }
        })

        register("packetReceived", () => {
            if (this.Enabled) this.received_s08 = true;
        }).setFilteredClass(net.minecraft.network.play.server.S08PacketPlayerPosLook)

        SkyblockUtils.register("commissionDone", () => {
            if (!this.Enabled) return;
            MiningBot.stopBot();
            this.previous_commission = this.commission;
            this.commission = null;
            this.setState(this.STATES.MOVE);
        })

        SkyblockUtils.register("pickonimbusbroke", () => {
            if (!this.Enabled) return;
            MiningBot.stopBot();
            this.setState(this.STATES.REPLACE);
        })

        SkyblockUtils.register("fullinventory", () => {
            if (!this.Enabled) return;
            MiningBot.stopBot();
            this.setState(this.STATES.SELL);
        })
    }

    toggle() {
        this.Enabled = !this.Enabled;
        this.sendMacroMessage(this.Enabled ? "&aEnabled": "&cDisabled");
        if (!this.Enabled) return this.stop();
        this.pigeon = ModuleManager.getSetting(this.ModuleName, "Pigeon");
        this.travel_method = ModuleManager.getSetting(this.ModuleName, "Travel method");
        this.ranged_weapons = ModuleManager.getSetting(this.ModuleName, "Use a ranged weapon for slayer commissions");
        this.use_drill = ModuleManager.getSetting(this.ModuleName, "Use a drill for ice walker slayer");
        this.previous_commission = null;
        this.commission = null;
        this.warp_item = Utils.getItemByNames(["Aspect of the Void","Aspect of the End"]);
        this.pigeon_item = Utils.getItemByName("Pigeon");
        this.weapon_item = Utils.getItem(ModuleManager.getSetting(this.ModuleName, "Weapon slot") - 1);
        let items = MiningUtils.getDrills();
        this.drill = items.drill;
        this.blue_cheese = items.blueCheese ?? items.drill;
        if (!this.drill) return this.stop("You are missing a mining item in your hotbar", true);
        if (!this.warp_item && this.travel_method != "Walking") return this.stop("You are missing a warping item in your hotbar", true);
        if (!this.pigeon_item && this.pigeon) return this.stop("You are missing a royal pigeon in your hotbar", true);
        if (this.weapon_item.name === undefined) return this.stop("You don't have a weapon in slot " + this.weapon_item.slot);
        if(!MiningUtils.hasSavedMiningSpeed()) return this.stop(null, true);
        this.miningSpeed = MiningUtils.getSavedMiningSpeed();
        this.setState(this.STATES.MOVE);
    }

    setState(new_state) {
        this.previous_state = this.state;
        this.state = new_state;
        switch (new_state) {
            case this.STATES.MOVE:
                if (!this.commission) {
                    if (this.pigeon) this.setState(this.STATES.CLAIMCOMMISSION);
                    else {
                        ChatLib.say("/warp forge");
                        this.current_route = this.npc_routes[this.travel_method][Math.floor(Math.random() * this.npc_routes[this.travel_method].length)];
                        this.current_point = this.current_route[0];
                        this.current_point.num = 0;
                        this.first_point = true;
                        this.warped_to_forge = true;
                        this.is_mine_path = false;
                    }
                } else {
                    if (this.commission.route_data.from_forge || this.pigeon || (this.commission.route_data.etherwarp_forge && this.travel_method === "Etherwarp")) {
                        ChatLib.say("/warp forge");
                        this.warped_to_forge = true;
                    }
                    this.current_route = [];
                    let random_npc_route = this.npc_routes[this.travel_method][Math.floor(Math.random() * this.npc_routes[this.travel_method].length)];
                    if (this.pigeon && (!this.commission.route_data.from_forge || (!this.commission.route_data.etherwarp_forge && this.travel_method === "Etherwarp"))) random_npc_route.forEach(point => this.current_route.push(point));
                    let random_location_route = this.commission.route_data[this.travel_method].location_path[Math.floor(Math.random() * this.commission.route_data[this.travel_method].location_path.length)]
                    random_location_route.forEach(point => this.current_route.push(point));
                    this.current_point = this.current_route[0];
                    this.current_point.num = 0;
                    this.first_point = true;
                    this.is_mine_path = false;
                }
                break;
            case this.STATES.CLAIMCOMMISSION:
                this.interacted = false;
                MovementHelper.setKey("shift", false)
                PolarPathFinder.clearPath();
                break;
            case this.STATES.REPLACE:
                this.tickCounter = 0;
                break;
            case this.STATES.GOBLIN:
            case this.STATES.ICEWALKER:
                PolarPathFinder.clearPath();
                MovementHelper.setKey("shift", false)
                this.timer.setRandomReached(0, 0);
                this.killed_mobs = [];
                this.rescan_timer = new TimeHelper();
                break;
            case this.STATES.SELL:
                //https://youtu.be/Sm3PWEOYmyk?si=UTltXqEuh-f_hPlF
                ChatLib.say("/warp hub");
                this.warped_to_forge = true;
                this.interacted = false;
                this.timer.reset();
                this.timer.setRandomReached(500, 800);
                break;
            case this.STATES.WARPFORGE:
                ChatLib.say("/warp forge");
                this.timer.reset();
                break;
            case this.STATES.MINE:
                PolarPathFinder.clearPath();
                break;
        }
    }

    /**
     * @param {Number} state 
     * @param {PlayerMP} mob 
     */
    isInSlayerLocation(state, mob) {
        if (state === this.STATES.GOBLIN) return mob.getY() > 127.0 && (mob.getZ() <= 153.0 || mob.getX() >= -157.0) && (mob.getZ() >= 148.0 || mob.getX() <= -77.0) && (mob.getX() < -100 && mob.getZ() > 117)
        else return Player.getX() > -31 && Player.getY() > 127;
    }

    getMobCost(state, mob) {
        if(this.killed_mobs.indexOf(mob.getEntity().func_145782_y()) != -1) return Infinity
        let angles = MathUtils.calculateAngles(Utils.convertToVector(mob));
        let distances = MathUtils.getDistanceToPlayer(mob);
        if (this.state === this.STATES.GOBLIN) return MathUtils.getDistance(mob, [-138,145,138]).distance + (distances.distance * 2) + (Math.abs(distances.differenceY) * 10) + Math.abs(angles.yaw) + Math.abs(angles.pitch) - (Player.asPlayerMP().canSeeEntity(mob) ? 50 : 0);
        else return (MathUtils.getDistance(mob, [21,127,160]).distance * 0.3) + (distances.distance * 2) + (Math.abs(distances.differenceY) * 10);
    }

    getPickonimbusSlot() {
        let player_items = Player.getContainer().getItems();
        for (let slot = 0; slot < player_items.length; slot++) {
            let item = player_items[slot];
            if (!item) continue;
            if (item.getName().includes("Pickonimbus")) return slot;
        }
        return undefined;
    }

    stop(msg=null, disable_message=false) {
        if (msg) this.sendMacroMessage(msg);
        if (disable_message) this.sendMacroMessage("&cDisabled");
        this.Enabled = false;
        MiningBot.stopBot();
        MovementHelper.stopMovement();
        MovementHelper.setKey("shift", false);
        Rotations.stopRotate();
        PolarPathFinder.clearPath();
        MouseUtils.reGrabMouse();
        global.export.FailsafeManager.unregister();
    }

    sendMacroMessage(msg) {
        ChatUtils.sendModMessage(this.ModuleName + ": " + msg);
    }
}

class CommissionMarker {
    constructor(x, y, z, method, num=0) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.vec = new Vector(x,y,z);
        this.center = this.vec.add(0.5, 0.5, 0.5);
        this.method = method;
        this.num = num
    }

    next(route) {
        let next_marker = route[this.num + 1];
        if (!next_marker) return null;
        next_marker.num = this.num + 1;
        return next_marker;
    }

    equals(marker) {
        return marker.x === this.x && marker.y === this.y && marker.z === this.z;
    }
}

class PolarCommission {
    /**
     * @param {String} name 
     * @param {{commission_names: Array<String>,"Walking": {location_path: Array<Array<CommissionMarker>>, mine_path: Array<Array<CommissionMarker>>}, "Aspect of the end": {location_path: Array<Array<CommissionMarker>>, mine_path: Array<Array<CommissionMarker>>}, "Etherwarp": {location_path: Array<Array<CommissionMarker>>, mine_path: Array<Array<CommissionMarker>>},from_forge: Boolean}} route_data 
     */
    constructor(name, route_data) {
        this.name = name;
        this.route_data = route_data;
        this.titanium = name.toLowerCase().includes("titanium");
    }
}

new PolarCommissionMacro();