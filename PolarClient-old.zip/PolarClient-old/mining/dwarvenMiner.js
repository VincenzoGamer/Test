let { SettingSelector, SettingSlider, SettingToggle, ConfigModuleClass, ModuleToggle, getKeyBind, ModuleManager } = global.settingSelection
let { ChatUtils, MiningUtils, TimeHelper, Routes, MathUtils, ItemUtils, Rotations, RaytraceUtils, Utils, MovementHelper, MiningBot, MouseUtils } = global.export

global.modules.push(
    new ConfigModuleClass(
        "Dwarven Miner",
        "Mining",
        [
            new SettingToggle("Move while mining", true),
            new SettingToggle("Shift while mining", true),
            new SettingToggle("Target better blocks", true),
            new SettingToggle("Use etherwarp routes", true),
            new SettingSelector("Etherwarp routes", 0, [
                "Blue 1",
                "Blue 2",
                "Blue 3",
                "Blue Green 1",
                "Gold 1"
            ]),
            new SettingSlider("Etherwarp cooldown", 0, 0, 10000)
        ]
    )
)

class DwarvenMiner {
    constructor() {
        this.ModuleName = "Dwarven Miner";
        this.Enabled = false;
        getKeyBind("Dwarven Miner", "Polar Client - Mining", this);

        this.MACROSTATES = {
            WAITING: 0,
            MINING: 1,
            WAITWARP: 2,
            WARPING: 3
        }
        this.state = this.MACROSTATES.WAITING;
        this.LOCATIONS = {
            FORGE: [0,148,-69],
            HUB: [-3,69,-70]
        }
        this.miningSpeed;
        this.tickCounter = 0;
        this.timer = new TimeHelper();
        this.etherwarpRoute;
        this.location;
        this.currentWarp;
        this.warped;

        register("tick", () => {
            if(!this.Enabled) return;
            switch(this.state) {
                case this.MACROSTATES.WARPING:
                    ItemUtils.setItemSlot(this.etherwarp.slot);
                    MovementHelper.setKey("shift", true);
                    if(Player.getHeldItemIndex() != this.etherwarp.slot || !MovementHelper.isKeyDown("shift")) break;
                    let delay = Math.floor(ModuleManager.getSetting(this.ModuleName, "Etherwarp cooldown")/50);
                    this.tickCounter++;
                    if(!this.warped && this.tickCounter === delay) {
                        this.warped = true;
                        this.tickCounter = 0;
                        let castResult = RaytraceUtils.getPointOnBlock(this.currentWarp.pos);
                        if(!castResult) return this.stopMacro("Somehow the next waypoint wasn't visable, report this!", true);
                        Rotations.rotateTo(Utils.convertToVector(castResult));
                        Rotations.onEndRotation(() => {
                            ItemUtils.rightClickPacket(5);
                        })
                    }
                    if(this.tickCounter === (delay + 100)) {
                        ChatUtils.sendModMessage("Your etherwarps failed, trying again!")
                        this.location = this.LOCATIONS.FORGE;
                        ChatLib.say("/warp forge");
                        this.setState(this.MACROSTATES.WAITWARP);
                    } else if(MathUtils.getDistanceToPlayer(this.currentWarp.pos).distance < 3.0) {
                        let nextIndex = this.currentWarp.index + 1;
                        this.tickCounter = 0;
                        if(nextIndex === this.etherwarpRoute.route.length) {
                            MovementHelper.setKeysForStraightLine(MathUtils.calculateAngles(Utils.convertToVector(this.etherwarpRoute.move)).yaw, false);
                            this.setState(this.MACROSTATES.WAITING);
                            Client.scheduleTask(2, () => {
                                MovementHelper.stopMovement();
                                this.setState(this.MACROSTATES.MINING);
                            })
                            break;
                        }
                        this.warped = false;
                        this.currentWarp = new MithrilMarker(this.etherwarpRoute.route[nextIndex], nextIndex);
                    }
                    let lastPoint = this.etherwarpRoute.route[this.etherwarpRoute.route.length-1];
                    World.getAllPlayers().forEach(otherPlayerMP => {
                        if(otherPlayerMP.getName() === Player.getName()) return;
                        if(MathUtils.getDistance(otherPlayerMP.getX(), otherPlayerMP.getY(), otherPlayerMP.getZ(), lastPoint[0], lastPoint[1], lastPoint[2]).distance < 5.0) {
                            this.sendMacroMessage("Detected player " + otherPlayerMP.getName() + " at the mining location")
                            ChatLib.say("/warp hub")
                            this.location = this.LOCATIONS.HUB
                            this.setState(this.MACROSTATES.WAITWARP);
                        }
                    })
                    break;
                case this.MACROSTATES.WAITWARP:
                    this.tickCounter += MathUtils.getDistanceToPlayer(this.location).distance < 10.0 ? 1 : -1;
                    if(this.tickCounter === 100) {
                        let array = this.location.toString();
                        if(array === this.LOCATIONS.FORGE.toString()) {
                            this.setState(this.MACROSTATES.WARPING);
                            break;
                        }
                        if(array === this.LOCATIONS.HUB.toString()) {
                            this.location = this.LOCATIONS.FORGE;
                            ChatLib.say("/warp forge");
                            this.setState(this.MACROSTATES.WAITWARP);
                        }
                    }
                    
                    break;
                case this.MACROSTATES.MINING:
                    if(!MiningBot.Enabled) {
                        MiningBot.toggle(
                            MiningBot.MACROTYPES.COMMISSION,
                            false,
                            this.miningSpeed,
                            this.drill,
                            this.bluecheese,
                            ModuleManager.getSetting(this.ModuleName,"Shift while mining"),
                            ModuleManager.getSetting(this.ModuleName,"Move while mining"),
                            true,
                            true
                        )
                    }
                    break;
            }
        })

        register("worldUnload", () => {
            if(!this.Enabled || this.state === this.MACROSTATES.WAITWARP) return;
            MiningBot.stopBot();
            this.setState(this.MACROSTATES.WAITING);
            Client.scheduleTask(100, () => {
                this.location = this.LOCATIONS.FORGE;
                ChatLib.say("/warp forge");
                this.setState(this.MACROSTATES.WAITWARP);
            })
        })
    }

    toggle() {
        this.Enabled = !this.Enabled;
        this.sendMacroMessage(this.Enabled ? "&aEnabled": "&cDisabled");
        if(this.Enabled) {
            let items = MiningUtils.getDrills();
            this.drill = items.drill;
            this.bluecheese = items.blueCheese ?? items.drill;
            if(!this.drill) return this.stopMacro("You are missing a mining item in your hotbar!", true);
            this.etherwarp = Utils.findItem(["Aspect of the End", "Aspect of the Void"]);
            if(!this.etherwarp) return this.stopMacro("You are missing an Aspect of the Void in your hotbar!", true);
            if(!MiningUtils.hasSavedMiningSpeed()) return this.stopMacro(null, true);
            this.miningSpeed = MiningUtils.getSavedMiningSpeed();
            this.etherwarpRoute = Routes.mithrilRoutes[ModuleManager.getSetting(this.ModuleName, "Etherwarp routes")]
            this.location = this.LOCATIONS.FORGE;
            ChatLib.say("/warp forge");
            this.setState(this.MACROSTATES.WAITWARP);

            // Failsafes
            global.export.FailsafeManager.register((cb) => {
                if (this.Enabled) this.toggle()
                cb()
            }, () => {
                if (!this.Enabled) this.toggle()
            }, ["Teleport", "Rotation", "Velocity", "Item", "Block", "Smart"])

            MouseUtils.unGrabMouse()
        }
        if(!this.Enabled) {
            this.stopMacro();
        }
    }

    setState(state) {
        this.state = state
        switch(state) {
            case this.MACROSTATES.WARPING:
                this.warped = false;
                this.currentWarp = new MithrilMarker(this.etherwarpRoute.route[0], 0);
                this.tickCounter = 0;
                break;
            case this.MACROSTATES.WAITWARP:
                this.tickCounter = 0;
                MovementHelper.stopMovement();
                MovementHelper.setKey("shift", false);
                Rotations.stopRotate();
                break;
            case this.MACROSTATES.MINING:
                break;
        }
    }

    stopMacro(msg=null, disableMessage=false) {
        if(msg) this.sendMacroMessage(msg);
        if(disableMessage) this.sendMacroMessage("&cDisabled");
        this.Enabled = false;
        MiningBot.stopBot();
        MovementHelper.stopMovement();
        MovementHelper.setKey("shift", false);
        Rotations.stopRotate();
        global.export.FailsafeManager.unregister();
        MouseUtils.reGrabMouse();
    }

    sendMacroMessage(msg) {
        ChatUtils.sendModMessage(this.ModuleName + ": " + msg);
    }
}

class MithrilMarker {
    constructor(point, index) {
        this.point = point;
        this.pos = new BlockPos(point[0], point[1], point[2]);
        this.index = index;
    }
}

new DwarvenMiner();