let { cancelLook, lookAt, lookAt2, startLook, lookAtRayCast } = global.exports
let { C09PacketHeldItemChange, checkMiningSpeed, cords, polarPrefix, sendPacket, setting, Shift, toggle, writeSave, BP, sendMessage, mc, diffNumber, location } = global.exports
let { autoMine, fileUtils, finder, inCrystal, keyBind, fillJavaArray, disFrToFr, disToPly, disToPlyFlat, route, degreeRannge, radians_to_degrees, rotaPitchRange, setSpeeds, itemUtils, rotationUtils } = global.exports
let { WalkForward, getClosest, renderUtils, mathUtils } = global.exports
import RenderLib from "RenderLib";

const configGemstoneMacro = new global.configModuleClass(
    "Gemstone Macro",
    "Crystal Hollows",
    false,
    [
        new global.settingSelector("Gemstone Macro Route", 0, [
            "&cRuby&f Default - 42 veins",
            "&cRuby&f Default - 68 veins",
            "Custom - 1",
            "Custom - 2",
            "Custom - 3",
            "Custom - 4",
            "Custom - 5"
        ], false),
        new global.settingSlider("Mining look speed", 150, 1, 1000),
        new global.settingSlider("Etherwarp look speed", 250, 1, 1000),
        new global.settingToggle("Mining Through Walls", false),
        new global.settingToggle("Sneak while Macroing", false),
        new global.settingToggle("Precision Miner auto aim", false),
        new global.settingToggle("Use nuker", false),
        new global.settingSlider("Additional mining ticks", 0, 0, 10),
        new global.settingSlider("Max rotation", 120, 0, 180),
    ],
    [
        "&bGemstone Macro&r, Requirments: Drill/Gauntlet, Ranged Weapon, Etherwarp"
    ]
)

global.modules.push(configGemstoneMacro)

let EntityMagmeCube = Java.type("net.minecraft.entity.monster.EntityMagmaCube")
let EntityIronGolem = Java.type("net.minecraft.entity.monster.EntityIronGolem")
let EntitySlime = Java.type("net.minecraft.entity.monster.EntitySlime")
let Entities = [EntityMagmeCube,EntityIronGolem,EntitySlime]

let rightClick = mc.getClass().getDeclaredMethod("func_147121_ag")
rightClick.setAccessible(true)

var jsonl = FileLib.read("PolarConfig", "webhook.json");
var configl = JSON.parse(jsonl);

class gemStoneMacro {
    constructor() {
        this.configName = "Gemstone Macro"
        this.nukerBlock = fillJavaArray([4,1,14,15,16,21,56,73,74,129])
        this.cords = []
        this.toggle = false
        this.toggleAotv = false
        this.toggleMining = false
        this.aotvPos = 0
        this.supposedCord = this.currentPos()
        this.cooldown = 0
        toggle.mineThroughWalls = false
        writeSave()
        this.reScan = false
        this.shouldRender = false
        this.inMenu = false
        this.fuelItems = ["Volta","Oil"]
        this.startTime = 0
        this.totalMoney = 0
        this.aotvCount = 0
        this.tries = 0
        this.whitelist = ["Weakling ","Kalhuiki Tribe","Team Treasurite"]
        this.inMenu = false
        this.serverChange = false
        this.serverChangeYaw = 0
        this.serverChangePitch = 0
        this.time = 0
        this.gotSpeed = false
        this.serverTp = false
        this.currentStructure = undefined
        this.startCordsStructure = [0,0,0]
        this.structureRoute = false
        this.lastReportedYaw = 0
        this.lastReportedPitch = 0
        this.lastPacket = new Date().getTime()
        this.check = false
        
        keyBind.keyBindGemstoneMacro.registerKeyPress(() => {this.toggleMacro()})

        this.speedBoostTimer = 0

        register("command", (x,y,z) => {
            fileUtils.updateGemstone()
            let firstInput = x?.toString()?.toLowerCase()
            let secondInput = y?.toString()?.toLowerCase()
            let thirdInput = z?.toString()

            if(firstInput === "set") {
                if(secondInput === undefined || thirdInput === undefined) {
                    ChatLib.chat(polarPrefix + "Usage -> /custom set <Custom1/etc> <file.txt/file.json in the PolarCustomCords folder in .minecraft\config\ChatTriggers\modules\PolarCustomCords"); 
                    ChatLib.chat(polarPrefix + "Example -> /custom set custom4 polarrevamp.txt")
                    return
                }

                try{
                    let json = FileLib.read("PolarCustomCords",thirdInput)
                    let value = JSON.parse(json)
                    if(json === null) {
                        ChatLib.chat(polarPrefix + " Couldn't read" + thirdInput)
                        return
                    }

                    let tempArray = []
                    if(value[0].x != undefined) {
                        for(let i = 0; i < value.length; i++) {
                            let array = [value[i].x, value[i].y, value[i].z]
                            tempArray.push(array)
                        }
                        value = tempArray
                    } else if(value[0][0] === undefined) {
                        return
                    }

                    switch(secondInput) {
                        case "custom1":
                            fileUtils.gemstonecords.custom1 = value
                            break;
                        case "custom2":
                            fileUtils.gemstonecords.custom2 = value
                            break;
                        case "custom3":
                            fileUtils.gemstonecords.custom3 = value
                            break;
                        case "custom4":
                            fileUtils.gemstonecords.custom4 = value
                            break;
                        case "custom5":
                            fileUtils.gemstonecords.custom5 = value
                            break;
                    }

                    fileUtils.writeGemstone(fileUtils.gemstonecords)
                    this.selectCords()
                    ChatLib.chat(polarPrefix + " Written the Route to " + secondInput)
                } catch (e) {
                    ChatLib.chat(polarPrefix + " Couldn't read File: " + thirdInput)
                }
            }

            if(firstInput === "insert") {
                if(secondInput === undefined || thirdInput === undefined) {
                    ChatLib.chat(polarPrefix + "Usage -> /custom insert <Custom1/etc> <route number>"); 
                    ChatLib.chat(polarPrefix + "Example -> /custom insert Custom4 23")
                    return
                }

                try {
                    let value = undefined
                    switch(secondInput) {
                        case "custom1":
                            fileUtils.gemstonecords.custom1 = value
                            break;
                        case "custom2":
                            fileUtils.gemstonecords.custom2 = value
                            break;
                        case "custom3":
                            fileUtils.gemstonecords.custom3 = value
                            break;
                        case "custom4":
                            fileUtils.gemstonecords.custom4 = value
                            break;
                        case "custom5":
                            fileUtils.gemstonecords.custom5 = value
                            break;
                    }

                    let num = (parseInt(thirdInput) - 1)
                    let tempArray = []
                    for(let i = 0; i < value.length; i++) {
                        if(i === num) {
                            let array1 = [Math.floor(Player.getX()), Math.floor(Player.getY()) - 1, Math.floor(Player.getZ())]
                            tempArray.push(array1)
                        }
                        let array = [value[i][0], value[i][1], value[i][2]]
                        tempArray.push(array)
                    }

                    switch(secondInput) {
                        case "custom1":
                            fileUtils.gemstonecords.custom1 = value
                            break;
                        case "custom2":
                            fileUtils.gemstonecords.custom2 = value
                            break;
                        case "custom3":
                            fileUtils.gemstonecords.custom3 = value
                            break;
                        case "custom4":
                            fileUtils.gemstonecords.custom4 = value
                            break;
                        case "custom5":
                            fileUtils.gemstonecords.custom5 = value
                            break;
                    }

                    fileUtils.writeGemstone(fileUtils.gemstonecords)
                    ChatLib.chat(polarPrefix + " Inserted cord " + value.length + " to " + secondInput)
                } catch (e) {
                }
            }

            if(firstInput === "add") {
                if(secondInput === undefined) {
                    ChatLib.chat(polarPrefix + "Usage -> /custom add <Custom1/etc>"); 
                    ChatLib.chat(polarPrefix + "Example -> /custom add Custom4")
                    return
                }

                try {
                    let value = undefined
                    switch(secondInput) {
                        case "custom1":
                            value = fileUtils.gemstonecords.custom1
                            break;
                        case "custom2":
                            value = fileUtils.gemstonecords.custom2
                            break;
                        case "custom3":
                            value = fileUtils.gemstonecords.custom3
                            break;
                        case "custom4":
                            value = fileUtils.gemstonecords.custom4
                            break;
                        case "custom5":
                            value = fileUtils.gemstonecords.custom5
                            break;
                    }
                    let tempArray = value
                    let array1 = [Math.floor(Player.getX()), Math.floor(Player.getY()) - 1, Math.floor(Player.getZ())]
                    tempArray.push(array1)

                    switch(secondInput) {
                        case "custom1":
                            fileUtils.gemstonecords.custom1 = value
                            break;
                        case "custom2":
                            fileUtils.gemstonecords.custom2 = value
                            break;
                        case "custom3":
                            fileUtils.gemstonecords.custom3 = value
                            break;
                        case "custom4":
                            fileUtils.gemstonecords.custom4 = value
                            break;
                        case "custom5":
                            fileUtils.gemstonecords.custom5 = value
                            break;
                    }
                    fileUtils.writeGemstone(fileUtils.gemstonecords)
                    ChatLib.chat(polarPrefix + " Added cord " + thirdInput + " to " + secondInput)
                } catch (e) {
                }
            }

            if(firstInput === "remove") {
                if(secondInput === undefined || thirdInput === undefined) {
                    ChatLib.chat(polarPrefix + "Usage -> /custom remove <Custom1/etc> <route number>"); 
                    ChatLib.chat(polarPrefix + "Example -> /custom remove Custom2 12")
                    return
                }

                try {
                    let value = undefined
                    switch(secondInput) {
                        case "custom1":
                            value = fileUtils.gemstonecords.custom1
                            break;
                        case "custom2":
                            value = fileUtils.gemstonecords.custom2
                            break;
                        case "custom3":
                            value = fileUtils.gemstonecords.custom3
                            break;
                        case "custom4":
                            value = fileUtils.gemstonecords.custom4
                            break;
                        case "custom5":
                            value = fileUtils.gemstonecords.custom5
                            break;
                    }

                    let num = (parseInt(thirdInput) - 1)
                    let tempArray = []
                    for(let i = 0; i < value.length; i++) {
                        if(i === num) continue
                        let array = [value[i][0], value[i][1], value[i][2]]
                        tempArray.push(array)
                    }

                    switch(secondInput) {
                        case "custom1":
                            fileUtils.gemstonecords.custom1 = value
                            break;
                        case "custom2":
                            fileUtils.gemstonecords.custom2 = value
                            break;
                        case "custom3":
                            fileUtils.gemstonecords.custom3 = value
                            break;
                        case "custom4":
                            fileUtils.gemstonecords.custom4 = value
                            break;
                        case "custom5":
                            fileUtils.gemstonecords.custom5 = value
                            break;
                    }
                    fileUtils.writeGemstone(fileUtils.gemstonecords)
                    ChatLib.chat(polarPrefix + " Removed cord " + thirdInput + " to " + secondInput)
                } catch (e) {              
                }
            }

            if(firstInput === "type") {
                if(secondInput === undefined || thirdInput === undefined) {
                    ChatLib.chat(polarPrefix + "Usage -> /custom type <gemstone type> <Custom1/etc>")
                    ChatLib.chat(polarPrefix + "Example -> /custom type amber custom3")
                    return
                }

                let gemTypes = ["ruby", "amber", "jade", "sapphire", "amethyst", "topaz", "jasper", "none"]
                if(!gemTypes.toString().includes(secondInput)) {
                    ChatLib.chat(polarPrefix + " That Gemstone Type doesn't exist")
                    ChatLib.chat(polarPrefix + " You can chose from: " + gemTypes.toString())
                }

                if(!thirdInput.includes("custom")) {
                    ChatLib.chat(polarPrefix + " Make sure you selected the right custom name")
                }

                switch(thirdInput) {
                    case "custom1":
                        fileUtils.gemstonecords.custom1type = secondInput
                        break;
                    case "custom2":
                        fileUtils.gemstonecords.custom2type = secondInput
                        break;
                    case "custom3":
                        fileUtils.gemstonecords.custom3type = secondInput
                        break;
                    case "custom4":
                        fileUtils.gemstonecords.custom4type = secondInput
                        break;
                    case "custom5":
                        fileUtils.gemstonecords.custom5type = secondInput
                        break;
                }

                fileUtils.writeGemstone(fileUtils.gemstonecords)
                ChatLib.chat(polarPrefix + " Selected " + secondInput + " on route " + thirdInput)
            }

            if(secondInput === undefined) {
                ChatLib.chat(polarPrefix + " Options: ")
                ChatLib.chat("- set")
                ChatLib.chat("- add")
                ChatLib.chat("- insert")
                ChatLib.chat("- remove")
                ChatLib.chat("- type")
            }
        }).setName("custom")

        register("step", () => {
            this.selectCords()
        }).setFps(1)

        register("Chat", (theMsg) => {
            let gtheMsg = ChatLib.getChatMessage(theMsg, false)
            if(gtheMsg.toString().includes("You used your Mining Speed Boost Pickaxe Ability!")) {
                this.speedBoostTimer = 0
            }
        })
        register("worldLoad", () => {
            if(this.toggle && this.gotSpeed) {
                sendMessage(configl.webhookname,"Detected world change, stopped Macro!")
                this.warnPlayer()
            }
            this.currentStructure = undefined
        })

        register("chat", (type, num, event) => {
            if(this.toggle && this.gotSpeed) {
                let Money = (240 * num)
                this.totalMoney += Money
                this.moneyAnHour = Math.floor(this.totalMoney/((Date.now() - this.startTime) / (1000 * 60 * 60)))
            }
        }).setCriteria("&r&d&lPRISTINE! &r&fYou found &r${*} &r&aFlawed ${type} Gemstone &r&8x${num}&r&f!&r").setContains()

        register("renderScoreboard", () => {
            if(this.toggle && this.moneyAnHour != undefined && this.gotSpeed) {
                let message
                try {
                    message = ("Money An Hour: $" + this.addNotation(this.moneyAnHour))
                } catch(e) {
                    message = this.moneyAnHour
                }
                let time = this.timeSince2(this.startTime)
                Scoreboard.setLine(2,"Session Time: " + time, true)
                Scoreboard.setLine(1,message,true)
            }
        })

        register("chat", () => {
            if(this.toggle && this.allowedToTricker && this.gotSpeed) {
                if(autoMine.toggle) {
                    autoMine.toggleMacro()
                }

                this.allowedToTricker = false
                this.inMenu = true
                let plyInv = Player.getInventory().getItems()
                for(let i = 0; i < plyInv.length; i++) {
                    if(plyInv[i] === null) continue
                    if(plyInv[i].getName().includes("Abiphone")) {
                        let current = Player.getHeldItemIndex()
                        sendPacket(new C09PacketHeldItemChange(i))
                        sendPacket(new net.minecraft.network.play.client.C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(i).getItemStack(), 0, 0, 0))
                        sendPacket(new C09PacketHeldItemChange(current))
                        new Thread(() => {
                            let clicked = false
                            while(!clicked) {
                                Thread.sleep(200)
                                if(Player.getContainer().getName().includes("Abiphone")) {
                                    let plyCont = Player.getContainer().getItems()
                                    for(let i = 0; i < plyCont.length; i++) {
                                        if(plyCont[i] === null) continue
                                        if(plyCont[i].getName().includes("Jotraelin")) {
                                            Player.getContainer().click(i,false,"LEFT")
                                            clicked = true
                                            this.allowedToTricker = true
                                        }
                                    }
                                }
                            }
                        }).start()
                        break
                    }
                }
            }
        }).setCriteria("&cis empty! Refuel it by talking to a Drill Mechanic!").setContains()

        register("chat", () => {
            ChatLib.say("/purchasecrystallhollowspass");
            ChatLib.chat(polarPrefix + ' Bought Pass');
        }).setCriteria("remaining on your pass.").setContains()

        register("step", () => {
            if(this.toggle && this.gotSpeed) {
                this.playerNear()
            }

            this.shouldRender = global.exports.settingGet.getSetting("Route Rendering", "Gemstone Macro Route")
            this.selectCords()
        }).setFps(1)

        register("Tick", () => {
            if(this.toggle && this.gotSpeed) {

                if(this.speedBoostTimer < 2440) {
                    this.speedBoostTimer += 1
                } else if(this.currentPos() === this.supposedCord) {
                    this.speedBoostTimer = 0
                    autoMine.useSpeedBoost()
                }

                this.yog = this.closestYog()
                if(this.yog === undefined && !this.inMenu) {
                    if(this.toggleAotv) {
                        this.aotvCount = 0
                        this.tries = 0
                        this.goToNext()
                        this.toggleAotvFunc()
                    } else if(this.currentPos() != this.supposedCord) {
                        Shift.setState(true)
                    }

                    if(this.currentPos() === this.supposedCord) {
                        if(!autoMine.toggle) {

                            toggle.supposedCords = this.supposedCord
                            writeSave()

                            autoMine.toggleMacro()
                            this.time = 0
                        }
                    } else {
                        if(autoMine.toggle) {
                            autoMine.toggleMacro()
                        }
                    }

                    if(autoMine.blockLength === 0.0) {
                        if(!this.reScan) {
                            this.reScan = true
                            autoMine.previousBlock = fillJavaArray([undefined,undefined])
                        } else {
                            this.toggleAotvFunc()
                        }
                    }

                } else if(!this.inMenu && this.yog != undefined) {
                    if(autoMine.toggle && !this.inMenu) {
                        autoMine.toggleMacro()
                    }

                    Player.setHeldItemIndex(finder.slotRange)
                    this.cooldown += 1
                    if(this.cooldown === 8) {
                        this.cooldown = 0
                        lookAt(this.yog.getX(), this.yog.getY() + 1, this.yog.getZ(), 50, true, false)
                    }
                }

                if(Player.getContainer().getName() === "Drill Anvil" && this.inMenu && !this.refueling) {
                    //ChatLib.chat("here")
                    //this.inMenu = true
                    let plyCont = Player.getContainer()
                    let plyItem = plyCont.getItems()
    
                    let slotDrill = undefined
                    let slotFuel = undefined
    
                    for(let i = 0; i < plyItem.length; i++) {
                        if(plyItem[i] != null) {
                            let found = false

                            let lore = plyItem[i].getLore()
                            for(let i = 0; i < lore.length; i++) {
                                //ChatLib.chat(lore[i])
                                if(lore[i].includes("Blue Cheese")) {
                                    found = true
                                }
                            }

                            if(plyItem[i].getName().toString().includes("Drill") && !found) {
                                slotDrill = i
                            }
                            for(let u = 0; u < this.fuelItems.length; u++) {
                                if(plyItem[i].getName().includes(this.fuelItems[u])) {
                                    slotFuel = i
                                }
                            }
                        }
                    }
                    if(slotFuel === undefined) return
                    this.refueling = true
    
                    new Thread(() => {
                        //if(slotFuel != undefined) {
                            Thread.sleep(500)
                            if(Player.getContainer().getName() === "Drill Anvil") {
                                plyCont.click(slotDrill, true, "LEFT")
                                Thread.sleep(500)
                            }
                            if(Player.getContainer().getName() === "Drill Anvil") {
                                plyCont.click(slotFuel, true, "LEFT")
                                Thread.sleep(500)
                            }
                            if(Player.getContainer().getName() === "Drill Anvil") {
                                plyCont.click(22,false,"LEFT")
                                Thread.sleep(500)
                            }
                            if(Player.getContainer().getName() === "Drill Anvil") {
                                plyCont.click(13,true,"LEFT")
                                Thread.sleep(500)
                                Client.scheduleTask(0, () => {Client.currentGui.close()})
                                Thread.sleep(500)
                                this.inMenu = false
                                this.refueling = false
                                autoMine.toggleMacro()
                                finder.drill()
                                finder.etherwarp()
                                finder.range()
                                this.startItems ={
                                    drill: Player.getInventory()?.getStackInSlot()?.getName(finder.slotDrill),
                                    etherwarp: Player.getInventory()?.getStackInSlot()?.getName(finder.slotWarp),
                                    weapon: Player.getInventory()?.getStackInSlot()?.getName(finder.slotRange)
                                }
                            }
                    }).start()
                }
            }
        })

        register("RenderWorld", () => {
            if(inCrystal() && this.shouldRender && this.cords != undefined) {
                if(this.toggle) return
                renderUtils.drawMultipleBlocksInWorld(this.cords, 0, 1, 0, 1, false, false, true, 2, 1)
                for(let i = 0; i < this.cords.length; i++) {
                    if((i > route.currentCord + 2 || i < route.currentCord - 2) && route.setting === this.setting) continue
                    Tessellator.drawString(i + 1,this.cords[i][0] + 0.5, this.cords[i][1] + 0.5, this.cords[i][2] + 0.5)
                }
            }
        })

        register("packetReceived", (packet, event) => {
            if(!this.toggle) return

            if(packet instanceof net.minecraft.network.play.server.S08PacketPlayerPosLook) {
                if(new Date().getTime() - this.lastPacket < 200 && this.check) {
                    let x = packet.func_148932_c() //getX()
                    let y = packet.func_148928_d() //getY()
                    let z = packet.func_148933_e() //getZ()
                    let points = [[0,0],[0,1],[1,0],[1,1]]
                    this.callCords()
                    for(let i = 0; i < this.cords.length; i++) {
                        for(let f = 0; f < points.length; f++) {
                            let point = points[f]
                            if(this.cords[i][0] + point[0] + 0.5 === x && this.cords[i][1] + 1.05 === y && this.cords[i][2] + point[1] + 0.5 === z) {
                                return 
                            }
                        }
                    }

                    this.check = false
                    ChatLib.chat(polarPrefix + "Detected Rotation check!")
                    this.warnPlayer()
                }
            }
            
            if(packet instanceof net.minecraft.network.play.server.S0CPacketSpawnPlayer) {
                try {
                    let packetid = packet.func_148943_d()
                    Client.scheduleTask(0, () => {
                        let entity = World.getWorld().func_73045_a(packetid)
                        if(entity != null) {
                            for(let i = 0; i < this.whitelist.length; i++) {
                                if(entity.toString().includes(this.whitelist[i])) {
                                   return 
                                }
                            }

                            if(mathUtils.disToPlayerMC(entity) < 6.0) {
                                ChatLib.chat(polarPrefix + "Detected Floating player around you")
                                this.warnPlayer()
                            }
                        }
                    })
                } catch (error) {
                    ChatLib.chat(error)
                }
            }

            if(packet instanceof net.minecraft.network.play.server.S12PacketEntityVelocity) {
                try {
                    if(this.playerNear()) {
                        let entity = World.getWorld().func_73045_a(packet.func_149412_c())
                        if(entity.toString().includes(Player.getName())) {
                            ChatLib.chat(polarPrefix + " Detected Velocity check")
                            this.warnPlayer()
                        }
                    }
                } catch (error) {}
            }

            this.lastPacket = new Date().getTime()
        })

        register("tick", () => {
            if(!this.toggle) return
            if (
               (Player?.getInventory()?.getStackInSlot(finder.slotDrill)?.getName() != this.startItems?.drill ||
               Player?.getInventory()?.getStackInSlot(finder.slotRange)?.getName() != this.startItems?.weapon ||
               Player?.getInventory()?.getStackInSlot(finder.slotWarp)?.getName() != this.startItems?.etherwarp)
               && this.startItems?.drill != undefined
            ) {
                ChatLib.chat(polarPrefix + " Item's got replaced")
                this.warnPlayer()
            }
        })
    }  

    selectCords() {
        let theSetting = global.exports.settingGet.getSetting(this.configName,"Gemstone Macro Route")
        let prevSetting = this.setting
        this.setting = theSetting
        if(theSetting === "&cRuby&f Default - 42 veins") this.cords = cords.RubyFourth
        else if(theSetting === "&cRuby&f Default - 68 veins") this.cords = cords.RubyThird
        else if(theSetting === "Custom - 1") this.cords = fileUtils.gemstonecords.custom1
        else if(theSetting === "Custom - 2") this.cords = fileUtils.gemstonecords.custom2
        else if(theSetting === "Custom - 3") this.cords = fileUtils.gemstonecords.custom3
        else if(theSetting === "Custom - 4") this.cords = fileUtils.gemstonecords.custom4
        else if(theSetting === "Custom - 5") this.cords = fileUtils.gemstonecords.custom5
        if(this.setting != prevSetting) {
            renderUtils.blockVBODataChanged = true
        }
    }

    getType() {
        let theSetting = global.exports.settingGet.getSetting(this.configName,"Gemstone Macro Route")
        this.setting = theSetting
        if(theSetting === "&cRuby&f Default - 68 veins") {this.cords = cords.RubyThird; autoMine.setFilter("ruby")} else
        if(theSetting === "&cRuby&f Default - 42 veins") {this.cords = cords.RubyFourth; autoMine.setFilter("ruby")}
        else if(theSetting === "Custom - 1") {this.cords = fileUtils.gemstonecords.custom1; autoMine.setFilter(fileUtils.gemstonecords.custom1type)}
        else if(theSetting === "Custom - 2") {this.cords = fileUtils.gemstonecords.custom2; autoMine.setFilter(fileUtils.gemstonecords.custom2type)}
        else if(theSetting === "Custom - 3") {this.cords = fileUtils.gemstonecords.custom3; autoMine.setFilter(fileUtils.gemstonecords.custom3type)}
        else if(theSetting === "Custom - 4") {this.cords = fileUtils.gemstonecords.custom4; autoMine.setFilter(fileUtils.gemstonecords.custom4type)}
        else if(theSetting === "Custom - 5") {this.cords = fileUtils.gemstonecords.custom5; autoMine.setFilter(fileUtils.gemstonecords.custom5type)}
    }

    goToNext() {
        let cords = []
        cords = this.cords
        let next = this.nextPos()
        if(!this.silentSwap) {
            Player.setHeldItemIndex(finder.slotWarp)
        }
        this.lookAtCord(cords[next][0], cords[next][1], cords[next][2], global.exports.settingGet.getSetting(this.configName,"Etherwarp look speed"), !autoMine.sneak, next)
        this.supposedCord = next
        this.reScan = false
    }

    lookingAtWrongBlock(blockid) {
        let ids = [95,160,1]
        for(let i = 0; i < ids.length; i++) {
            if(ids[i] === blockid) return false
        }
        return true
    } 

    nextPos() {
        let points = [[0,0],[0,1],[1,0],[1,1]]
        this.callCords()
        let cords = this.cords
        for(let i = 0; i < cords.length; i++) {
            for(let f = 0; f < points.length; f++) {
                let point = points[f]
                if(cords[i][0] + point[0] === this.plX && cords[i][1] === (this.plY - 1) && cords[i][2] + point[1] === this.plZ) {
                    if(i === (cords.length - 1)) {
                        return 0 
                    }
                    return (i + 1)
                }
            }
        }
        return undefined
    }

    currentPos() {
        let points = [[0,0],[0,1],[1,0],[1,1]]
        this.callCords()
        let cords = this.cords
        for(let i = 0; i < cords.length; i++) {
            for(let f = 0; f < points.length; f++) {
                let point = points[f]
                if(cords[i][0] + point[0] === this.plX && cords[i][1] === (this.plY - 1) && cords[i][2] + point[1] === this.plZ) {
                    return i
                }
            }
        }
        return undefined
    }

    onStructureRoute() {
        this.callCords()
        let cords = this.currentStructure
        try {
            for(let i = 0; i < cords.length; i++) {
                if(cords[i][0] === this.plX && cords[i][1] === (this.plY - 1) && cords[i][2] === this.plZ) {
                    return true
                }
            }
        } catch(e) {}
        return false
    }

    lookAtCord(x, y, z, ms, sneak, next) {
        cancelLook()

        let point = this.getSneakPoint({x: Player.getX(), y: Player.getY(), z: Player.getZ()}, {x: x, y: y, z: z})
        new Thread(() => {

            Shift.setState(true)
            WalkForward.setState(true)
            rotationUtils.onStopRotation()
            rotationUtils.polarRotateTo({x: Player.getX() + point[0] + (0.3 * Math.random()), y: Player.getY() + 1.6, z: Player.getZ() + point[1] + (0.3 * Math.random())}, 300, false, true)
            while(rotationUtils.end.isDone != true) {
                if(!this.toggle) return
                Thread.sleep(1)
            }
            WalkForward.setState(false)

            rotationUtils.onStopRotation()
            let castResult = this.onPlatForm(x,y,z,ms)
            while(rotationUtils.end.isDone != true && !castResult) {
                if(!this.toggle) return
                Thread.sleep(1)
            }
            Thread.sleep(100)

            if(!this.toggle) return
            if(this.lookingAtWrongBlock(Player.lookingAt()?.type?.getID()) && !castResult) {
                itemUtils.rightClick(0)
            } else if(this.time < 3) {
                this.time += 1
                ChatLib.chat(polarPrefix + " Block in the way")
                if(this.toggle) this.toggleMacro()

                /*
                    this.supposedCord = this.currentPos()

                    if(this.toggleAotv) {
                        this.toggleAotvFunc()
                    }

                    autoMine.previousBlock = fillJavaArray([undefined,undefined])

                    if(!autoMine.toggle) {
                        autoMine.toggleMacro()
                    }
                */
            } else if(this.toggle) {
                this.warnPlayer()
            }

            startLook()
        }).start()
    }

    onPlatForm(x,y,z,ms) {
        let points = [[0,0],[0,1],[1,0],[1,1]]
        let cast = undefined
        points.forEach(point => {
            if(World.getBlockAt(x + point[0],y+1,z + point[1]).type.getID() === 0.0 && World.getBlockAt(x + point[0],y+2,z + point[1]).type.getID() === 0.0) {
                cast = lookAtRayCast(x + point[0],y,z + point[1],ms, false, true)
            }
            if(!cast) {
                return 
            }
        })
    }

    getSneakPoint(location, next) {
        let points = [[-0.80,-0.80],[0.80,-0.80],[0.80,0.80],[-0.80,0.80]]
        let closest = undefined
        points.forEach((point) => {
            if(closest === undefined) {
                closest = point
            }
            if(disFrToFr(location.x + point[0], location.y, location.z + point[1], next.x, next.y, next.z) < disFrToFr(location.x + closest[0], location.y, location.z + closest[1], next.x, next.y, next.z)) {
                closest = point
            }
        })
        return closest
    }

    playerNear() {
        let Players = World.getAllPlayers()
        for(let i = 0; i < Players.length; i++) {
            let player = Players[i]
            if(mathUtils.disToPlayerCT(player) < 10 && Player.getName() != player.getName()) {
                return true
            }
        }
        return false
    }

    toggleMacro() {
        finder.bluecheese()
        this.toggle = !this.toggle
        if(this.toggle) {
            this.check = true
            this.gotSpeed = false
            this.structureRoute = this.onStructureRoute()
            this.supposedCord = this.currentPos()
            if(this.supposedCord != undefined && finder.drill() && finder.etherwarp() && finder.range()) {
                this.getType()
                if(this.structureRoute) {autoMine.setFilter("none")}
                ChatLib.chat(polarPrefix + " Gemstone Macro: " + this.toggle)
                new Thread(() => {

                    if(autoMine.miningSpeedBoost) {
                        this.toggle = false
                        ChatLib.chat(polarPrefix + " Make sure your mining speed boost is not active");
                        ChatLib.chat(polarPrefix + " Gemstone Macro: false"); 
                        return "nigga"
                    }

                    Player.setHeldItemIndex(finder.slotDrill)
                    Thread.sleep(500)
                    if(!this.toggle) return

                    sendPacket(new C09PacketHeldItemChange(8))
                    sendPacket(new net.minecraft.network.play.client.C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(8).getItemStack(), 0, 0, 0))
                    sendPacket(new C09PacketHeldItemChange(finder.slotDrill))

                    while(Player.getContainer()?.getName() != "SkyBlock Menu" && this.toggle) {Thread.sleep(10)}
                    if(!this.toggle) return "nigga"

                    while(Player.getContainer().getStackInSlot(13) === null && this.toggle ) {Thread.sleep(10)}
                    if(!this.toggle) return "nigga"

                    let statLore = Player.getContainer().getStackInSlot(13).getLore()
                    let speed = null
                    for(let i = 0; i < statLore.length; i++) {
                        if(statLore[i].removeFormatting().includes("Mining Speed")) {
                            speed = parseInt(statLore[i].charAt(24) + statLore[i].charAt(26) + statLore[i].charAt(27) + statLore[i].charAt(28))
                            break
                        }
                    }
                    if(speed === NaN) {
                        this.toggle = false; 
                        ChatLib.chat(polarPrefix + " Something went wrong try again"); 
                        ChatLib.chat(polarPrefix + " Gemstone Macro: " + this.toggle)
                        return "nigga"
                    }
                    ChatLib.say("/hotm")

                    while(Player.getContainer()?.getName() != "Heart of the Mountain" && this.toggle) {Thread.sleep(10)}

                    if(!this.toggle) return "nigga"
                    Thread.sleep(100)
                    Player.getContainer()?.click(8,false,"RIGHT")
        
                    while(!Player.getContainer()?.getStackInSlot(12)?.getName()?.removeFormatting()?.includes("Professional") && this.toggle) {Thread.sleep(10)}
                    Thread.sleep(100)
                    if(!this.toggle) return "nigga"

                    let profSpeed = null
                    let loreProf = Player.getContainer()?.getStackInSlot(12).getLore()
                    for(let i = 0; i < loreProf.length; i++) {
                        if(loreProf[i].removeFormatting().includes("Gain")) {
                            profSpeed = parseInt(loreProf[i].charAt(16) + loreProf[i].charAt(17) + loreProf[i].charAt(18))
                            break
                        }
                    }

                    if(profSpeed === NaN) {
                        this.toggle = false; 
                        ChatLib.chat(polarPrefix + " Something went wrong try again");
                        ChatLib.chat(polarPrefix + " Gemstone Macro: " + this.toggle); 
                        return "nigga";
                    }

                    if(!this.toggle) return "nigga"

                    setSpeeds(speed, Math.floor(speed + profSpeed))

                    Client.scheduleTask(0, () => {Client.currentGui.close()})
                    Thread.sleep(100)
                    this.gotSpeed = true

                    if(this.toggle) {
                        this.startTime = Date.now()
                        this.totalMoney = 0
                        this.moneyAnHour = 0
        
                        autoMine.ms = global.exports.settingGet.getSetting(this.configName,"Mining look speed")
                        autoMine.sneak = global.exports.settingGet.getSetting(this.configName,"Sneak while Macroing")
                        autoMine.precisionMiner = global.exports.settingGet.getSetting(this.configName,"Precision Miner auto aim")
                        autoMine.maxRotation = global.exports.settingGet.getSetting(this.configName, "Max rotation")
                        autoMine.useNuker = global.exports.settingGet.getSetting(this.configName, "Use nuker")
                        autoMine.bigblock = false
                        autoMine.useSpeedBoost()
        
                        this.whitelist.push(this.getWatchDogName())

                        this.tries = 0
        
                        this.time = 0
        
                        this.inMenu = false
                        this.refueling = false
                        this.allowedToTricker = true
        
                        this.speedBoostTimer = 0

                        this.silentSwap = false
        
                        toggle.supposedCords = this.supposedCord
                        writeSave()

                        this.startItems = {
                            drill: Player.getInventory()?.getStackInSlot(finder.slotDrill)?.getName(),
                            etherwarp: Player.getInventory()?.getStackInSlot(finder.slotWarp)?.getName(),
                            weapon: Player.getInventory()?.getStackInSlot(finder.slotRange)?.getName()
                        }
                    }
                }).start()

                toggle.gemStoneMacro = this.toggle
                writeSave()
            } else {
                ChatLib.chat(polarPrefix + "Gemstone Macro: You are missing: ")
                if(this.supposedCord === undefined) {
                    ChatLib.chat("- Being on the path")
                }
                if(!finder.drill()) {
                    ChatLib.chat("- Drill")
                }
                if(!finder.etherwarp()) {
                    ChatLib.chat("- Etherwarp")
                }
                if(!finder.range()) {
                    ChatLib.chat("- Frozen Scythe")
                }
                this.toggle = false
            }
        } else {

            ChatLib.chat(polarPrefix + " Gemstone Macro: " + this.toggle)

            this.reScan = false
            Scoreboard.setLine(1,"Polar On Top",true)
            Scoreboard.setLine(2,"",true)
            
            if(autoMine.toggle) {
                autoMine.setFilter("none")
                autoMine.toggleMacro()
            }

            Shift.setState(false)

            this.structureRoute = false

            toggle.mineThroughWalls = false
            writeSave()
        }

        toggle.gemStoneMacro = this.toggle
        writeSave()
    }

    playerNear() {
        let players = World.getAllPlayers()
        for(let i = 0; i < players.length; i++) {
            if(!this.whitelist.includes(players[i].getName()) && disToPly(players[i].getX(), players[i].getY(), players[i].getZ()) < 10 && Player.getName() != players[i].getName()) {
                this.whitelist.push(players[i].getName())
                ChatLib.chat(polarPrefix + "Player near!: " + players[i].getName())
                sendMessage(configl.webhookname, " @everyone Player near! " + players[i].getName())
                this.warnPlayer()
            }
        }
    }

    warnPlayer() {
        new Thread(() => {
            for(let i = 0; i < 100; i++) {
                Thread.sleep(50)
                World.playSound('mob.ghast.scream', 1000, 100)
            }
        }).start()
        if(this.toggle) {
            this.toggleMacro()
        }
    }

    getWatchDogName() {
        let players = World.getAllPlayers()
        for(let i = 0; i < players.length; i++) {
            let player = players[i]
            if(disToPlyFlat(player.getX(), player.getZ()) < 1 && player.getName() != Player.getName()) {
                return player.getName()
            }
        }
    }

    closestYog() {
        for(let i = 0; i < 3; i++) {
            let mobs = World.getAllEntitiesOfType(Entities[i])
            for(let i = 0; i < mobs.length; i++) {
                if(Player.asPlayerMP().canSeeEntity(mobs[i]) && mobs[i].entity.func_110143_aJ() > 1.1 && disToPly(mobs[i].getX(), mobs[i].getY(), mobs[i].getZ()) < 10) {
                    return mobs[i]
                }
            }
        }
        return undefined
    }

    toggleAotvFunc() {
        this.toggleAotv = !this.toggleAotv
    }

    callCords() {
        this.plX = Math.floor(Player.getX())
        this.plY = Math.floor(Player.getY())
        this.plZ = Math.floor(Player.getZ())
    }


    addNotation(x) {
        if (x === undefined) { return "" }
        var parts = x.toString().split(".");
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return parts.join(".");
    }

    timeSince2(date) {
        let time = Date.now() - date

        if (time > 30 * 60000) {
            return this.timeNumber2(time)
        }
        return this.timeNumber(time)
    }

    timeNumber2(time){
        let hours = Math.floor(time / 1000 / 60 / 60)
        let mins = Math.floor(time / 1000 / 60) % 60

        if (hours === 0) return mins + "m"
        return `${hours}h ${mins}m`
    }

    timeNumber(time, secondDecimals = 0){
        let mins = Math.floor(time / 1000 / 60)
        let secs = (time / 1000) % 60

        if (mins === 0) return `${secs.toFixed(secondDecimals)}s`
        return `${mins}m ${secs.toFixed(secondDecimals)}s`
    }
}

global.exports.gemstone = new gemStoneMacro()