/* @ Plus @ */
let { SettingSelector, SettingSlider, SettingToggle, ConfigModuleClass, ModuleToggle, getKeyBind, ModuleManager } = global.settingSelection
let { ChatUtils, MiningUtils, Utils } = global.export;

class GoldMacro {
    constructor() {
        this.ModuleName = "Gold Macro"
        getKeyBind("Gold Macro","Polar Client - Mining").registerKeyPress(() => this.toggle());
        this.Enabled = false;

        register("tick", () => {
            if(!this.Enabled) return;
        })
    }

    toggle() {
        this.Enabled = !this.Enabled;
        this.sendMacroMessage(this.Enabled ? "&aEnabled" : "&cDisabled");
        if(!this.Enabled) return this.stopMacro();
        let items = MiningUtils.getDrills();
        this.drill = items.drill;
        this.bluecheese = items.blueCheese ?? items.drill;
        this.abiphone = Utils.getItemByName("Abiphone");
        if(!this.drill) return this.stopMacro("You are missing a mining item in your hotbar!", true);
        if(!MiningUtils.hasSavedMiningSpeed()) return this.stopMacro(null, true);
    }

    stopMacro(msg=null, disableMessage=false) {
        if(msg) this.sendMacroMessage(msg);
        if(disableMessage) this.sendMacroMessage("&cDisabled");
        this.Enabled = false;
    }

    sendMacroMessage(msg) {
        ChatUtils.sendModMessage(this.ModuleName + ": " + msg);
    }
}

new GoldMacro();