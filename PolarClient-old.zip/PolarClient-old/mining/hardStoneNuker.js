let { ArrayLists, C07PacketPlayerDigging, C0APacketAnimation, EnumFacing, polarPrefix, sendPacket, mc } = global.exports
let { keyBind } = global.exports
let { fillJavaArray } = global.exports
let { toBlockPos, toPosBlock } = global.exports
let { disToPly } = global.exports
import RenderLib from "RenderLib";
import Skyblock from "BloomCore/Skyblock";

class hardStoneNuker {
    constructor() {
        this.toggle = false
        this.nukerBlock = fillJavaArray([4,14,15,16,17,21,56,73,74,129,162,49])
        this.latestBlocks = new ArrayLists
        this.previousBlock = undefined
        
        keyBind.keyBindHardStoneNuker.registerKeyPress(() => {this.toggleMacro()})

        register("Tick", () => {
            if(this.toggle) {

                if(this.latestBlocks.size() > 10) {
                    this.latestBlocks.remove(0)
                }

                if(this.previousBlock != undefined) {
                    //ChatLib.chat("stop")
                    //sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.previousBlock, EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
                    this.previousBlock = undefined
                }
                this.scan()
            }
        })

        register("renderWorld", () => {
            if(this.previousBlock != undefined) {
                let block = toPosBlock(this.previousBlock)
                RenderLib.drawInnerEspBox(block.getX() + 0.5, block.getY(), block.getZ() + 0.5, 1, 1, 0, 1, 0, 0.2, true)
            }
        })
    }

    toggleMacro() {
        this.toggle = !this.toggle
        if(this.toggle) {
            ChatLib.chat(polarPrefix + " Nuker: " + this.toggle)
            let area = Skyblock.area
            if(area === "The Park" || area === "Hub") {
                this.nukerBlock = fillJavaArray([17,162,59])
                this.foraging = true
            } else if(area === "The Farming Islands") {
                this.nukerBlock = fillJavaArray([59,141,142])
                this.foraging = true
            }
            else {
                this.nukerBlock = fillJavaArray([4,14,15,16,21,56,73,74,129,49])
                this.foraging = false
            }
        } else {
            ChatLib.chat(polarPrefix + " Nuker: " + this.toggle)
            if(this.previousBlock != undefined) {
                //ChatLib.chat("stop")
                //sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.previousBlock, EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
                this.previousBlock = undefined
            }
        }
    }

    scan() {
        this.callCords()
        this.blocks = []
        this.blockPos = []
        for (let x = -6; x <= 6; x++) {
            for (let y = 0; y < 6; y++) {
                for (let z = -6; z <= 6; z++) {
                    let block = World.getBlockAt(this.plX + x, this.plY + y, this.plZ + z)
                    let pos = toBlockPos(block)
                    if(this.includesBlock(block.type.getID(), block.getMetadata()) && this.latestBlocks.contains(pos) === false) {
                        this.blocks.push(block)
                        this.blockPos.push(pos)
                    }
                }
            }
        }

        let swinged = false
        for(let i = 0; i <= 1; i++) {
            let object = this.returnClosest()
            if(object.closest != undefined) {
                if(!swinged) { 
                    mc.field_71439_g.func_71038_i()
                    swinged = true
                }
                this.blocks.splice(object.index, 1)
                this.latestBlocks.add(object.closest)
                //ChatLib.chat("start")
                this.previousBlock = object.closest
                //mc.field_71439_g.func_71038_i()
                //sendPacket(new C0APacketAnimation())
                sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, object.closest, EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
            }
        }
    }

    returnClosest() {
        //ChatLib.chat(this.blocks.length)
        let closest = undefined
        let closestBlock = undefined
        let index = undefined
        for(let i = 0; i < this.blocks.length; i++) {
            if(disToPly(this.blocks[i].getX() + 0.5, this.blocks[i].getY() + 0.5, this.blocks[i].getZ() + 0.5) < 4.5) {
                //ChatLib.chat("here")
                if(closest === undefined) {
                    closest = this.blockPos[i]
                    closestBlock = this.blocks[i]
                    index = i
                } else if(disToPly(this.blocks[i].getX() + 0.5, this.blocks[i].getY() + 0.5, this.blocks[i].getZ() + 0.5) < disToPly(closestBlock.getX() + 0.5, closestBlock.getY() + 0.5, closestBlock.getZ() + 0.5)) {
                    closest = this.blockPos[i]
                    closestBlock = this.blocks[i]
                    index = i
                }
            }
        }
        //ChatLib.chat(closest)
        return {closest: closest, index: index}
    }

    includesBlock(id,meta) {
        //ChatLib.chat(id)
        //ChatLib.chat(meta)
        if(id === 1.0 && meta === 0.0 && !this.foraging) {
            return true
        } else if(this.nukerBlock.contains(id)) {
            return true
        } else {
            return false
        }
    }

    callCords() {
        this.plX = Math.floor(Player.getX())
        this.plY = Math.floor(Player.getY())
        this.plZ = Math.floor(Player.getZ())
    }
}

global.exports.nuker = new hardStoneNuker()