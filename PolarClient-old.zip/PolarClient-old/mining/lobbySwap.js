let { keyBind } = global.exports
let { polarPrefix, inCrystal, setting, fagotSpotted } = global.exports

const configLobbySwapper = new global.configModuleClass(
    "Lobby Swapper",
    "Crystal Hollows",
    false,
    [
        new global.settingSlider("Minimal Lobby Day", 3, 0, 15)
    ],
    [
        "&bLobby Swapper",
        "Auto Matically Swap between Crystal Hollows lobbies, until it finds a good one"
    ]
)

global.modules.push(configLobbySwapper)

class lobbySwaper {
    constructor() {

        this.toggle = false
        this.doCh = false

        this.cooldown = 0

        
        keyBind.keyBindLobbySwapper.registerKeyPress(() => {this.toggleMacro()})

        register("Tick", () => {
            if(this.toggle) {
                if(!inCrystal() && !this.doCh) {
                    this.cooldown += 1
                    if(!this.warpCh && this.cooldown === 60) {
                        this.warpChFunc()
                        this.doCh = true
                        this.cooldown = 0
                    }
                } else if(inCrystal() && this.doCh){
                    if(World != undefined) {

                        if(fagotSpotted()) {
                            ChatLib.chat(polarPrefix + " FloatingSand get HIMMMMMMMMMMM!!!!!!!!!!!!!!!!!!!")
                            this.toggleMacro()
                        }

                        else if(Math.floor(World.getTime()/28000) <= global.exports.settingGet.getSetting("Lobby Swapper","Minimal Lobby Day")) {
                            ChatLib.chat(polarPrefix + " Found Lobby!")
                            this.toggleMacro()
                        }
                    }
                    this.cooldown += 1
                    if(!this.warpHub && this.cooldown === 60) {
                        this.warpHubFunc()
                        this.doCh = false
                        this.cooldown = 0
                    }
                }
            }
        })
    }

    warpChFunc() {
        this.warpHub = false
        this.warpCh = true
        ChatLib.say("/warp ch")
    }

    warpHubFunc() {
        this.warpHub = true
        this.warpCh = false
        ChatLib.say("/warp hub")
    }

    toggleMacro() {
        this.toggle = !this.toggle
        if(this.toggle) {
            ChatLib.chat(polarPrefix + " Lobby Swapper: " + this.toggle)
            this.cooldown = 0

            if(inCrystal()) {
                this.doCh = true
                this.warpCh = true
                this.warpHub = false
            } else {
                this.doCh = false
                this.warpCh = false
                this.warpHub = true
            }
        } else {
            ChatLib.chat(polarPrefix + " Lobby Swapper: " + this.toggle)
        }
    }
}

global.exports.lobbySwap = new lobbySwaper()