let { toBlockPos } = global.exports
let { fillJavaArray } = global.exports
let { getPointsOnBlock } = global.exports
let { degreeRannge, rotaPitchRange } = global.exports
let { lookAt } = global.exports
let { setSpeeds, speedCalc } = global.exports
let { BP, C09PacketHeldItemChange, polarPrefix, sendPacket, setting, writeSave, Shift, inCrystal} = global.exports
let { finder } = global.exports
let { keyBind } = global.exports
let { toggle } = global.exports
import RenderLib from "RenderLib";
let { disFrToFr } = global.exports
let { route } = global.exports
let { rotationUtils } = global.exports

let ArrayLists = Java.type("java.util.ArrayList");
let mc = Client.getMinecraft()
let EnumFacing = Java.type("net.minecraft.util.EnumFacing");
let C07PacketPlayerDigging = Java.type("net.minecraft.network.play.client.C07PacketPlayerDigging");
let C0APacketAnimation = Java.type("net.minecraft.network.play.client.C0APacketAnimation");
let rightClick = mc.getClass().getDeclaredMethod("func_147121_ag")
rightClick.setAccessible(true)

const configMiningMacro = new global.configModuleClass(
    "Mining Extra's",
    "Misc",
    false,
    [
        new global.settingSlider("Extra amount of ticks while Mining (Without SpeedBoost)", 0, 0, 10),
        new global.settingSlider("Extra amount of ticks while Mining (With SpeedBoost)", 0, 0, 10),
        new global.settingToggle("I have Peak of The Mountain 5", true),
        new global.settingSlider("Base Mining look speed", 150, 1, 1000)
    ],
    [
        "These settings have effect on every Mining Macro"
    ]
)

global.modules.push(configMiningMacro)

class miningMacro {
        constructor() {
            this.configName = "Mining Extra's"
            this.toggle = false
            toggle.miningMacro = this.toggle
            writeSave()
            this.drillSlot = undefined
            this.mineableBlockID = fillJavaArray([95,160,35,159,168])
            this.mineableBlockMeta = fillJavaArray([1,14,7,3,9,5,4,10,2])
            this.mineableNamesMithril = fillJavaArray(["Wool", "Stained Clay", "Prismarine","Stone"])
            this.blocks = []
            this.blocksPoints = []
            this.mineBlock = undefined
            this.mining = false
            this.miningSpeedBoost = false
            this.previousBlock = fillJavaArray([undefined,undefined])
            this.whitelist = []
            this.blockLength = undefined
            this.colorWhiteList = undefined
            this.precisionMiner = false
            this.sneak = false
            this.requiredBlocks = new ArrayLists
            this.shouldUseSpeed = false
            this.gotSpeed = false
            this.ms = 100
            this.maxRotation = 180
            this.useNuker = true
            this.startedNuking = false

            keyBind.keyBindMiningMacro.registerKeyPress(() => {this.toggleMacro()})

            register("Tick", () => {
                if(this.toggle && this.gotSpeed) {

                    if(this.sneak) {
                        Shift.setState(true)
                    } else {
                        Shift.setState(false)
                    }

                    if(!this.mining) {
                        this.scan()
                    }
                    if(this.mining) {
                        if(!this.useNuker && !this.startedNuking && rotationUtils.end.isDone) {
                            this.startedNuking = true
                            sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, toBlockPos(this.mineBlock), EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
                            return
                        }
                        if(this.startedNuking) {
                            this.tickSpeedCount += 1
                        }
                        let currentBlock = World.getBlockAt(this.mineBlock.getX(), this.mineBlock.getY(), this.mineBlock.getZ()).type.getID()
                        mc.field_71439_g.func_71038_i()
                        if((this.tickSpeedCount === this.tickSpeed || currentBlock === 7.0 || currentBlock === 0.0) && this.startedNuking) {
                            sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, toBlockPos(this.mineBlock), EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
                            this.mining = false
                            this.scan()
                        }
                    }
                }
            })

            register("spawnParticle", (particle, particleType, event) => {
                if((particleType.toString() === "CRIT" || particleType.toString() === "VILLAGER_HAPPY") && this.precisionMiner && this.toggle && this.gotSpeed) {
                    if(this.mineBlock != undefined && !this.miningSpeedBoost) {
                        if(disFrToFr(particle.getX(), particle.getY(), particle.getZ(), this.mineBlock.getX() + 0.5, this.mineBlock.getY() + 0.5, this.mineBlock.getZ() + 0.5) < 1) {
                            lookAt(particle.getX(), particle.getY(), particle.getZ(), 1, false, toggle.sneak)
                            try {
                                this.tickSpeed = speedCalc(this.gemOrMithril(this.mineBlock.type), this.mineBlock.type.getName(), this.mineBlock.getMetadata(), this.miningSpeedBoost, false, true)
                            } catch(e) {
                            }
                        }
                    }
                }
            })

            register("packetReceived", (packet, event) => {
                if(!this.toggle || !this.gotSpeed) return;
                
                if (packet instanceof net.minecraft.network.play.server.S2FPacketSetSlot) {
            
                    if (!packet.func_149174_e()) { return }
                    if (!packet.func_149174_e().toString().toLowerCase().includes("shard") && !packet.func_149174_e().toString().toLowerCase().includes("pickaxe")) { return }
                    cancel(event)
                }
            
                if (packet instanceof net.minecraft.network.play.server.S30PacketWindowItems) {
            
                    if (packet.func_148911_c() != 0) { return }
                    cancel(event)
                }
            }).setPacketClasses([net.minecraft.network.play.server.S2FPacketSetSlot.class, net.minecraft.network.play.server.S30PacketWindowItems.class])
            
            register("WorldLoad", () => {
                worldLoad = Date.now()
            });

            register("RenderWorld",() => {
                if(this.mineBlock != undefined) {
                    let id = this.mineBlock.type.getID()
                    if(id == 95 || id == 160) {
                        RenderLib.drawInnerEspBox(this.mineBlock.getX() + 0.5, this.mineBlock.getY(), this.mineBlock.getZ() + 0.5, 1, 1, 0.7, 0, 0, 0.4, true)
                    } else {
                        RenderLib.drawInnerEspBox(this.mineBlock.getX() + 0.5, this.mineBlock.getY(), this.mineBlock.getZ() + 0.5, 1, 1, 0, 0, 1, 0.2, true)
                    }
                }
            })

            register("WorldLoad", () => {
                this.miningSpeedBoost = false
            })

            register("Chat", (theMsg) => {
                let gtheMsg = ChatLib.getChatMessage(theMsg, false)
                if(gtheMsg.toString().includes("Mining Speed Boost is now available!") && this.toggle && this.gotSpeed) {
                    this.useSpeedBoost()
                }
                if(gtheMsg.toString().includes("You used your Mining Speed Boost Pickaxe Ability!")) {
                    this.miningSpeedBoost = true
                }
                if(gtheMsg.toString().includes("Your Mining Speed Boost has expired!")) {
                    this.miningSpeedBoost = false
                }
            })
        }

        toggleMacro() {
            this.toggle = !this.toggle
            if(this.toggle) {
                this.gotSpeed = false
                finder.bluecheese()
                if(finder.drill()) {
                    toggle.mineThroughWalls = false
                    writeSave()

                    if(inCrystal()) {
                        route.selectCords()
                        route.makeArray(toggle.supposedCords)
                        this.requiredBlocks = route.requiredBlocks
                        this.mineableBlockID = fillJavaArray([95,160])
                    }

                    this.previousBlock = fillJavaArray([undefined,undefined])
                    
                    this.firstOfset = 3

                    if(!toggle.commisionMacro && !toggle.gemStoneMacro) {

                        if(this.miningSpeedBoost) {
                            this.toggle = false
                            ChatLib.chat(polarPrefix + " Make sure your mining speed boost is not active");
                            ChatLib.chat(polarPrefix + " Mining Macro: false"); 
                            return "nigga"
                        }
                        ChatLib.chat(polarPrefix + " Mining Macro: true")
                        this.ms = global.exports.settingGet.getSetting("Mining Extra's","Base Mining look speed")
                        new Thread(() => {
                            Player.setHeldItemIndex(finder.slotDrill)
                            Thread.sleep(500)
                            if(!this.toggle) return
        
                            sendPacket(new C09PacketHeldItemChange(8))
                            sendPacket(new net.minecraft.network.play.client.C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(8).getItemStack(), 0, 0, 0))
                            sendPacket(new C09PacketHeldItemChange(finder.slotDrill))
        
                            while(Player.getContainer()?.getName() != "SkyBlock Menu" && this.toggle) {Thread.sleep(10)}
                            if(!this.toggle) return "nigga"
        
                            while(Player.getContainer().getStackInSlot(13) === null && this.toggle ) {Thread.sleep(10)}
                            if(!this.toggle) return "nigga"
        
                            let statLore = Player.getContainer().getStackInSlot(13).getLore()
                            let speed = null
                            for(let i = 0; i < statLore.length; i++) {
                                if(statLore[i].removeFormatting().includes("Mining Speed")) {
                                    if(statLore[i].charAt(26) == ",") {
                                        speed = parseInt(statLore[i].charAt(24) + statLore[i].charAt(25) + statLore[i].charAt(27) + statLore[i].charAt(28) + statLore[i].charAt(29))
                                    } else {
                                        speed = parseInt(statLore[i].charAt(24) + statLore[i].charAt(26) + statLore[i].charAt(27) + statLore[i].charAt(28))
                                    }
                                    break
                                }
                            }
                            if(speed === NaN) {
                                this.toggle = false; 
                                ChatLib.chat(polarPrefix + " Something went wrong try again"); 
                                ChatLib.chat(polarPrefix + " Mining Macro: false");
                                return "nigga"
                            }
                            ChatLib.say("/hotm")
        
                            while(Player.getContainer()?.getName() != "Heart of the Mountain" && this.toggle) {Thread.sleep(10)}
        
                            if(!this.toggle) return "nigga"
                            Thread.sleep(100)
                            Player.getContainer()?.click(8,false,"RIGHT")
        
                            while(Player.getContainer()?.getStackInSlot(12) === null && this.toggle) {Thread.sleep(10)}
                            if(!this.toggle) return "nigga"
        
                            while(!Player.getContainer()?.getStackInSlot(12)?.getName()?.removeFormatting()?.includes("Professional") && this.toggle) {Thread.sleep(10)}
                            Thread.sleep(100)
                            if(!this.toggle) return "nigga"
        
                            let profSpeed = null
                            let loreProf = Player.getContainer()?.getStackInSlot(12).getLore()
                            for(let i = 0; i < loreProf.length; i++) {
                                if(loreProf[i].removeFormatting().includes("Gain")) {
                                    profSpeed = parseInt(loreProf[i].charAt(16) + loreProf[i].charAt(17) + loreProf[i].charAt(18))
                                    break
                                }
                            }
    
                            if(profSpeed === NaN) {
                                this.toggle = false; 
                                ChatLib.chat(polarPrefix + " Something went wrong try again");
                                ChatLib.chat(polarPrefix + " Mining Macro: false"); 
                                return "nigga";
                            }
        
                            if(!this.toggle) return "nigga"
        
                            setSpeeds(speed, Math.floor(speed + profSpeed))
        
                            Client.scheduleTask(0, () => {Client.currentGui.close()})
                            Thread.sleep(100)
                            this.gotSpeed = true        
        
                            if(this.toggle) {
                                this.useSpeedBoost()
                            }
                        }).start()
                    } else {

                        if(toggle.gemStoneMacro) {
                            toggle.mineThroughWalls = global.exports.settingGet.getSetting("Gemstone Macro","Mining Through Walls")
                        } else {
                            toggle.mineThroughWalls = false
                        }
                        writeSave()
                        this.gotSpeed = true
                        Player.setHeldItemIndex(finder.slotDrill)
                        sendPacket(new C09PacketHeldItemChange(finder.slotDrill))
                    }
                } else {
                    this.toggle = false
                    ChatLib.chat(polarPrefix + "Mining Macro: You are missing:")
                    if(!finder.drill()) {
                        ChatLib.chat("- Mining Item")
                    }
                }
            } else {

                if(!toggle.commisionMacro && !toggle.gemStoneMacro) {
                    ChatLib.chat(polarPrefix + " Mining Macro: false")
                }
                if(!toggle.gemStoneMacro && this.sneak) {
                    Shift.setState(false)
                }
                this.blockLength = undefined
                if(this.mineBlock != undefined) {
                    sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, toBlockPos(this.mineBlock), EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
                }
                this.stop()
            }

            toggle.sneak = this.sneak
            toggle.miningMacro = this.toggle
            writeSave()
        }

        scan() {
            this.blocks = []
            this.blocksPoints = []
            this.callCords()
            for (let x = -6; x < 6; x++) {
                for (let y = -3; y < 6; y++) {
                    for (let z = -6; z < 6; z++) {
                        if(x === 0 && z === 0) continue
                        let block = World.getBlockAt(this.plX + x, this.plY + y, this.plZ + z)
                        let pos = toBlockPos(block)
                        if((!this.previousBlock.contains(pos) && this.containsBlock(block.type.getID(),block.getMetadata()) && this.filter(block.getMetadata())) || (this.requiredBlocks.contains(pos) && block.type.getID() != 0)) {
                            if(this.rayTrace(pos) === true && rotationUtils.getRotationLength({x: this.plX + x + 0.5, y: this.plY + y + 0.5, z: this.plZ + z + 0.5}, this.sneak) < this.maxRotation) {
                                this.blocks.push(block)
                                this.blocksPoints.push(this.gPoint)
                            }
                        }

                    }
                }
            }

            this.blockLength = this.blocks.length

            this.mineBlock = undefined
            this.mineBlockPoint = undefined
            for(let i = 0; i < this.blocks.length; i++) {
                let block = this.blocks[i]
                let point = this.blocksPoints[i]
                if(this.checkBlocks(block, point)) {
                    let anglesBlock = rotationUtils.getRotationLength({x: point.field_72450_a, y: point.field_72448_b, z: point.field_72449_c}, this.sneak)
                    if(this.mineBlockPoint === undefined && anglesBlock < this.maxRotation) {
                        first = false
                        this.mineBlock = block
                        this.mineBlockPoint = point
                    }
                    if(this.mineBlockPoint === undefined) continue
                    let anglesClosest = rotationUtils.getRotationLength({x: this.mineBlockPoint.field_72450_a, y: this.mineBlockPoint.field_72448_b, z: this.mineBlockPoint.field_72449_c}, this.sneak)
                    if(anglesBlock < anglesClosest && anglesBlock < this.maxRotation) {
                        this.mineBlock = block
                        this.mineBlockPoint = point
                    }
                }
            }

            if(this.mineBlockPoint != undefined) {
                if(!this.precisionMiner || this.miningSpeedBoost) {
                    rotationUtils.onStopRotation()
                    rotationUtils.doPolarRotation({x: this.mineBlockPoint.field_72450_a, y: this.mineBlockPoint.field_72448_b, z: this.mineBlockPoint.field_72449_c}, this.ms, this.sneak)
                    //lookAt(this.mineBlockPoint.field_72450_a, this.mineBlockPoint.field_72448_b, this.mineBlockPoint.field_72449_c, this.ms, false, this.sneak)
                }
                this.startedNuking = false
                if(this.useNuker) {
                    this.startedNuking = true
                    sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, toBlockPos(this.mineBlock), EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
                }
                this.mining = true
                this.tickSpeed = speedCalc(this.gemOrMithril(this.mineBlock.type), this.mineBlock.type.getName(), this.mineBlock.getMetadata(), this.miningSpeedBoost, false, false, this.firstOfset)
                this.firstOfset = 0
                this.tickSpeedCount = 0
                this.previousBlock.add(toBlockPos(this.mineBlock))
                this.previousBlock.remove(0)
            }
        }

        filter(meta) {
            if(this.colorWhiteList === undefined) {
                return true
            } else {
                if(meta === this.colorWhiteList) {
                    return true
                } else {
                    return false
                }
            }
        }

        setFilter(meta) {
            if(meta === "ruby") {
                this.colorWhiteList = 14.0
            }
            else if(meta === "amber") {
                this.colorWhiteList = 1.0
            }
            else if(meta === "jade") {
                this.colorWhiteList = 5.0
            }
            else if(meta === "sapphire") {
                this.colorWhiteList = 3.0

            }
            else if(meta === "amethyst") {
                this.colorWhiteList = 10.0

            }
            else if(meta === "topaz") {
                this.colorWhiteList = 4.0

            }
            else if(meta === "jasper") {
                this.colorWhiteList = 2.0

            }
            else if(meta === "none") {
                this.colorWhiteList = undefined
            }
        }

        gemOrMithril(blockType) {
            if(this.mineableNamesMithril.contains(blockType.getName())) {
                //ChatLib.chat("mith")
                return "mithril"
            } else {
                //ChatLib.chat("gem")
                return "gem"
            }
        }

        callCords() {
            this.plX = Math.floor(Player.getX())
            this.plY = Math.floor(Player.getY())
            this.plZ = Math.floor(Player.getZ())
        }

        rayTrace(pos) {
            let found = false
            getPointsOnBlock(pos).forEach(point => {
                if(!found) {
                    let rayTraceResult = World.getWorld().func_72933_a(Player.getPlayer().func_174824_e(1), point)
                    if(rayTraceResult != null) {
                        if(rayTraceResult.func_178782_a().equals(pos) && point.func_72438_d(Player.getPlayer().func_174824_e(1)) < mc.field_71442_b.func_78757_d()) {
                            this.gPoint = point
                            found = true
                        }
                    }

                    let small = new net.minecraft.util.Vec3(pos).func_72441_c(0.5, 0.5, 0.5)
                    if(toggle.mineThroughWalls && small.func_72438_d(Player.getPlayer().func_174824_e(1)) < mc.field_71442_b.func_78757_d()) {
                        found = true
                        this.gPoint = small
                    }
                }
            })
            return found
        }

        containsBlock(blockID, metadata) {
            if(this.mineableBlockID.contains(blockID) && (blockID != 160 || !this.bigblock) && this.mineableBlockMeta.contains(metadata)) {
                return true
            } else if((blockID === 168 && metadata === 0) || (blockID === 1 && metadata === 4)) {
                return true
            }
            return false
        }


        useSpeedBoost() {
            if(finder.bluecheese()) {
                sendPacket(new C09PacketHeldItemChange(finder.slotBlueCheese))
                sendPacket(new net.minecraft.network.play.client.C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(finder.slotBlueCheese).getItemStack(), 0, 0, 0))
                sendPacket(new C09PacketHeldItemChange(finder.slotDrill))
            } else {
                rightClick.invoke(mc)
            }
        }

        onlyMine(cray, green, blue) {
            this.whitelist = []
            if(cray) {
                let array1 = [35,7]
                this.whitelist.push(array1)
                let array2 = [159,9]
                this.whitelist.push(array2)
            }

            if(green) {
                let array1 = [168,0]
                this.whitelist.push(array1)
                let array2 = [168,1]
                this.whitelist.push(array2)
                let array3 = [168,2]
                this.whitelist.push(array3)
            }

            if(blue) {
                let array1 = [35,3]
                this.whitelist.push(array1)
            }
        }

        checkBlocks(block, point) {
            let id = block.type.getID()
            let meta = block.getMetadata()

            if(toggle.titanium && toggle.commisionMacro) {
                if(id === 1.0 && meta === 4.0) {
                    this.mineBlock = block
                    this.mineBlockPoint = point
                    return true
                }
            }

            if(toggle.titanium && toggle.commisionMacro) {
                if(this.mineBlock != undefined) {
                    if(this.mineBlock.type.getID() === 1.0) {
                        return false
                    }
                }
            }

            if(this.whitelist.length != 0.0) {
                for(let i = 0; i < this.whitelist.length; i++) {
                    if(id === this.whitelist[i][0] && meta === this.whitelist[i][1]) {
                        return false
                    }
                }
                return true
            } else {
                return true
            }
        }

        stop() {
            this.mineableBlockID = fillJavaArray([95,160,35,159,168])
            this.mineableBlockMeta = fillJavaArray([1,14,7,3,9,5,4,10,2])
            this.mineableNamesMithril = fillJavaArray(["Wool", "Stained Clay", "Prismarine","Stone"])
            this.blocks = []
            this.blocksPoints = []
            this.mineBlock = undefined
            this.mining = false
            this.toggle = false
            this.previousBlock = fillJavaArray([undefined,undefined])
            this.mineBlockPoint = undefined
            this.shouldUseSpeed = false
        }
}

global.exports.autoMine = new miningMacro()