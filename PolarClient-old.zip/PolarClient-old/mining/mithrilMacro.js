let { checkMiningSpeed, polarPrefix, toggle, writeSave } = global.exports
let { keyBind } = global.exports
let { finder } = global.exports
let { setting } = global.exports
let { cancelLook, lookAt, startLook } = global.exports
let { autoMine } = global.exports
let { disFrToFr, disToPly } = global.exports
let { failSafe } = global.exports
let { setSpeeds } = global.exports

var json = FileLib.read("PolarConfig", "aotvCords.json");
var mithrilCords = JSON.parse(json);

const configMithrilMacro = new global.configModuleClass(
    "Mithril Macro",
    "Dwarven Mines",
    false,
    [
        new global.settingSelector("Mithril Macro Location", 0, [
            "Divan Gateway",
            "Secret Far Reserve"
        ], false),
        new global.settingSlider("Mining look speed", 150, 1, 1000),
        new global.settingSlider("Etherwarp look speed", 250, 1, 1000),
        new global.settingToggle("Mines Gray Mithril", true),
        new global.settingToggle("Mines Green Mithril", true),
        new global.settingToggle("Mines Blue Mithril", true)
    ],
    [
        "&bMithril Macro",
        "Mining Mithril in the Dwarven Mines, it goes there by Etherwarping from the forge",
        "Requirements: Drill/Gauntlet, Etherwarp"
    ]
)

global.modules.push(configMithrilMacro)

class mithrilMacro {
    constructor() {

        this.configName = "Mithril Macro"

        this.toggle = false
        toggle.mithrilMacro = this.toggle
        writeSave()

        this.forgeCoolDown = 0
        this.aotvPos = 0
        this.cords = undefined
        this.toggleAotv = false
        this.coolDown = 0
        this.first = false

        this.gotSpeed = false

        keyBind.keyBindMiningMacro.registerKeyPress(() => {this.toggleMacro()})

        register("WorldLoad", () => {
            this.first = false
        })

        register("Tick", () => {

            if(this.toggle && this.gotSpeed) {

                if(this.atForge()) {
                    if(!this.toggleAotv) {
                        this.toggleAotvFunc()
                    }
                }

                if(this.toggleHubFailSafe) {
                    this.callCords()
                    if(this.inTheHub()) {
                        this.coolDown += 1
                    } else {
                        this.coolDown = 0
                    }
    
                    if(this.coolDown === 150) {
                        this.coolDown = 0
                        this.toggleHubFailSafeFunc()
                        ChatLib.say("/warp forge")
                    }
                }

                if(this.toggleAotv) {
                    if(this.atAotvPos()) {
                        if(this.aotvPos < (this.cords.length - 1)) {
                            this.playerNearCords()
                            this.goToNextBlock()
                        } else {
                            this.toggleAotvFunc()
                            autoMine.toggleMacro()
                        }
                    }
                }

                if(autoMine.toggle) {
                    this.playerAtSpot()
                }
            }
        })
    }

    toggleAotvFunc() {
        this.toggleAotv = !this.toggleAotv
        if(this.toggleAotv) {
            this.aotvPos = 0
            ChatLib.chat(polarPrefix + " Started Aotv")
        } else {
            ChatLib.chat(polarPrefix + " Stopped Aotv")
            this.aotvPos = 0
        }
    }

    toggleMacro() {
        this.toggle = !this.toggle
        if(this.toggle) {
            this.gotSpeed = false
            if(finder.etherwarp() && finder.drill()) {
                this.selectCords()
                autoMine.onlyMine(!global.exports.settingGet.getSetting(this.configName,"Mines Gray Mithril"),!global.exports.settingGet.getSetting(this.configName,"Mines Green Mithril"),!global.exports.settingGet.getSetting(this.configName,"Mines Blue Mithril"))
                ChatLib.chat(polarPrefix + " Mithril Macro: " + this.toggle)
                this.gotSpeed = true
                ChatLib.say("/warp forge")
            } else {
                ChatLib.chat(polarPrefix + "Mithril Macro: You are missing:")
                    if(!finder.drill()) {
                        ChatLib.chat("- Drill")
                    }
                    if(!finder.etherwarp()) {
                        ChatLib.chat("- Etherwarp")
                    }
                    if(checkMiningSpeed(true,false) === false) {
                        ChatLib.chat("- Mining Speed for Mithril")
                    }
                this.toggle = false
            }
        } else {

            if(this.toggleAotv) {
                this.toggleAotvFunc()
            }

            if(autoMine.toggle) {
                autoMine.toggleMacro()
            }

            autoMine.onlyMine(false,false,false)
            ChatLib.chat(polarPrefix + " Mithril Macro: " + this.toggle)
        }
        toggle.mithrilMacro = this.toggle
        writeSave()
    }

    atForge() {
        this.callCords()
        if(this.plX === 0 && this.plY === 149 && this.plZ === -69) {
            if(this.forgeCoolDown < 40) {
                this.forgeCoolDown += 1
            } else {
                this.forgeCoolDown = 0
                return false
            }

            if(this.forgeCoolDown === 40) {
                this.forgeCoolDown = 0
                return true
            }
        } else {
            this.forgeCoolDown = 0
            return false
        }
    }

    toggleHubFailSafeFunc() {
        this.toggleHubFailSafe = !this.toggleHubFailSafe
        if(this.toggleHubFailSafe) {

            this.coolDown = 0
            if(this.toggleAotv) {
                this.toggleAotvFunc()
            }

            if(autoMine.toggle) {
                autoMine.toggleMacro()
            }

            ChatLib.say("/hub")
            ChatLib.chat(polarPrefix + " Going to the Hub")
            new Thread(() => {
                cancelLook()
                Thread.sleep(10)
                startLook()
            }).start()
        } else {
            this.coolDown = 0
            ChatLib.chat(polarPrefix + " Going to the Forge")
        }
    }

    playerNearCords() {
        let players = World.getAllPlayers()
            if(this.cords != undefined) {
                let c = this.cords.length - 1
                    for(let i = 0; i < players.length; i++) {
                            if(disFrToFr(players[i].getX(), players[i].getY(), players[i].getZ(), this.cords[c][0], this.cords[c][1], this.cords[c][2]) < 5) {
                                ChatLib.chat(polarPrefix + " Detected player: " + players[i].getName())
                                this.toggleHubFailSafeFunc()
                            }
                    }
            }
        }

    playerAtSpot() {
        let players = World.getAllPlayers()
                for(let i = 0; i < players.length; i++) {
                        if(disToPly(players[i].getX(), players[i].getY() + 1.6, players[i].getZ()) < 4 && players[i].getName() != Player.getName() && players[i].getName() != "Goblin ") {
                            //ChatLib.chat(polarPrefix + " Detected player: " + players[i].getName())
                            if(!this.first) {
                                this.first = true
                                autoMine.toggleMacro()
                                failSafe.toggleMacro()
                            } else {
                                if(this.coolDown < 150) {
                                    this.coolDown += 1
                                } else {
                                    this.coolDown = 0
                                    autoMine.toggleMacro()
                                    ChatLib.say("benc1ark stans")
                                    this.toggleHubFailSafeFunc()
                                }
                            }
                        }
                }
    }

    selectCords() {
        let theCords = global.exports.settingGet.getSetting(this.configName,"Mithril Macro Location")
        if(theCords === "Divan Gateway") {
            this.cords = mithrilCords.divanblue
        }
        if(theCords === "Secret Far Reserve") {
            this.cords = mithrilCords.FarReserve2
        }
    }

    atAotvPos() {
        this.callCords()
        if(this.plX === this.cords[this.aotvPos][0] && (this.plY - 1) === this.cords[this.aotvPos][1] && this.plZ === this.cords[this.aotvPos][2]) {
            return true
        } else {
            return false
        }
    }

    goToNextBlock() {
        Player.setHeldItemIndex(finder.slotWarp)
        let array = this.cords
        this.aotvPos += 1
        let x = 0
        let y = 0
        let z = 0
        if(array[this.aotvPos][3] === "Up") {
            y = 1
            x = 0.5
            z = 0.5
        } else if(array[this.aotvPos][3] === "Down") {
            y = 0
            x = 0.5
            z = 0.5
        } else if(array[this.aotvPos][3] === "North") {
            y = 0.5
            z = 0
            x = 0.5
        } else if(array[this.aotvPos][3] === "South") {
            y = 0.5
            z = 1
            x = 0.5
        } else if(array[this.aotvPos][3] === "East") {
            y = 0.5
            z = 0.5
            x = 0
        } else if(array[this.aotvPos][3] === "West") {
            y = 0.5
            z = 0.5
            x = 1
        } else if(array[this.aotvPos][3] === "none") {
            x = 0.5
            y = 0.5
            z = 0.5
        }
        lookAt(array[this.aotvPos][0] + x, array[this.aotvPos][1] + y, array[this.aotvPos][2] + z, global.exports.settingGet.getSetting(this.configName,"Etherwarp look speed"), true, true)
    }

    inTheHub() {
        let tab = Scoreboard.getLines()
        for(let i = 0; i < tab.length; i++) {
            if(tab[i].toString().includes("Village")) {
                return true
            }
        }
        return false
    }

    callCords() {
        this.plX = Math.floor(Player.getX())
        this.plY = Math.floor(Player.getY())
        this.plZ = Math.floor(Player.getZ())
    }
}

global.exports.mithrilMacro = new mithrilMacro()