import Skyblock from "BloomCore/Skyblock";
let { polarPrefix, rotationUtils, mathUtils, itemUtils, Shift, getClosest, WalkForward, finder, LeftClick, Sprint, renderUtils, WalkRight, WalkLeft } = global.exports

const configObsidianMacro = new global.configModuleClass(
    "Obsidian Macro",
    "Mining",
    false,
    [
        new global.settingToggle("Can in insta mine obsidian", true),
        new global.settingToggle("Nuker mode", false)
    ],
    [
        "&bObsidian Macro",
        "Mining obsidian in the End",
        "Make sure you can insta mine the Obsidian"
    ]
)

global.modules.push(configObsidianMacro)

class obsidianMacro {
    constructor() {
        this.configName = "Obsidian Macro"
        this.toggle = false
        this.macro = {
            state: "",
            Etherwarp: {
                Number: 0
            },
            Warp: {
                Location: 0,
                LastCheck: 0
            },
            Obsidian: {
                miningState: "NORMAL",
                speedBoost: false,
                ofset: 0
            },
            Walk: {
                Number: 0
            },
            Position: {
                current: 0,
                next: 0
            }
        }

        this.settingNuker = false
        this.settingInstaMine = false
        this.turnToSide = false

        this.warpPoints = [
            [-514,171,-257],
            [-548,198,-317],
            [-607,134,-294]
        ]

        this.walkPoints = [
            {
                Point: [-599,121,-293],
                Yaw: -44.0,
                Pitch: 25.0 
            },
            {
                Point: [-597,121,-298],
                Yaw: -68.0,
                Pitch: 36.6
            },
            {
                Point: [-600,121,-303],
                Yaw: -123.3,
                Pitch: 40.0
            },
            {
                Point: [-606,121,-299],
                Yaw: 143.0,
                Pitch: 17.9
            },
            {
                Point: [-607,121,-295],
                Yaw: 103.0,
                Pitch: 31.4
            },
            {
                Point: [-614,121,-288],
                Yaw: 130.0,
                Pitch: 40.0
            },
            {
                Point: [-610,121,-286],
                Yaw: 30.0,
                Pitch: 40.0 
            },
            {
                Point: [-604,121,-289],
                Yaw: -30.0,
                Pitch: 12.0 
            }
        ]

        register("renderWorld", () => {
            let inputArray = []
            for(let i = 0; i < this.walkPoints.length; i++) {
                inputArray.push(this.walkPoints[i].Point)
            }
            for(let i = 0; i < inputArray.length; i++) {
                Tessellator.drawString(i, inputArray[i][0] + 0.5, inputArray[i][1] + 0.5, inputArray[i][2] + 0.5)
            }
            renderUtils.drawMultipleBlocksInWorld(inputArray, 0, 1, 0, 1, false, false, true, 1, 1)
        })

        register("Chat", (event) => {
            let message = ChatLib.getChatMessage(event, false)
            if(message.toString().includes("Mining Speed Boost is now available!") && this.toggle && this.macro.state === "MINING") {
                this.onSpeedBoost()
            }
            if(message.toString().includes("You used your Mining Speed Boost Pickaxe Ability!")) {
                this.macro.Obsidian.speedBoost = true
                this.onFinishSpeedBoost()
            }
            if(message.toString().includes("Your Mining Speed Boost has expired!")) {
                this.macro.Obsidian.speedBoost = false
                this.onFinishSpeedBoost()
            }
        })

        register("worldLoad", () => {
            this.macro.Obsidian.speedBoost = false
        })

        register("tick", () => {
            if(!this.toggle) return

            if(this.macro.state === "WARPING") {
                if(new Date().getTime() - this.macro.Warp.LastCheck > 1000) {
                    ChatLib.chat(polarPrefix + " Detected Player in the End")
                    ChatLib.chat(polarPrefix + " Going to Location")
                    this.macro.Warp.Location = 0
                    this.macro.state = "ETHERWARPING"
                    this.onEtherwarpClick({x: Player.getX(), y: Player.getY(), z: Player.getZ()})
                }
                if(this.atEndSpawn() && Skyblock.area === "The End") {
                    return
                }
                this.macro.Warp.LastCheck = new Date().getTime()
            }

            if(this.macro.state === "ETHERWARPING") {
            }

            if(this.macro.state === "DROPPING") {
                if(this.atObsidianLocation()) {
                    this.onReachArea()
                }
            }

            if(this.macro.state === "MINING") {
                /*
                    Handles all the continious stuff
                */
                if(this.settingNuker) {
                    LeftClick.setState(false)
                    this.onNukeBlock()
                } else {
                    LeftClick.setState(true)
                }

                /*
                    Handles the current Location
                */
                if(this.atNextWalkPoint()) {
                    this.onNextWalkPoint()
                }

                /*
                    Handles the Keybind presses
                */
                if(!this.macro.Obsidian.speedBoost) {
                    Shift.setState(true)
                    WalkForward.setState(true)
                    WalkLeft.setState(false)
                }
                if(this.macro.Obsidian.speedBoost) {
                    Shift.setState(false)
                    if(this.turnToSide) {
                        WalkForward.setState(false)
                        WalkLeft.setState(true)
                    } else {
                        WalkForward.setState(true)
                        WalkLeft.setState(false)
                    }
                }

                /*
                    Handles the looking
                */
                                   
                rotationUtils.onStopRotation()
                if(!this.macro.Obsidian.speedBoost) {
                    let walkPoint = this.walkPoints[this.macro.Position.next]
                    rotationUtils.polarRotateTo({x: walkPoint.Point[0], y: walkPoint.Point[2], z: walkPoint.Point[2]}, 200, true, true, {changePitch: false, extraYaw: 0.0})
                    rotationUtils.setPitch(75 + this.macro.Obsidian.ofset, 200)
                    this.turnToSide = true
                }
                if(this.macro.Obsidian.speedBoost) {
                    let walkPoint = this.walkPoints[this.macro.Position.next]
                    //if(!this.turnToSide) {
                        rotationUtils.polarRotateTo({x: walkPoint.Point[0], y: walkPoint.Point[2], z: walkPoint.Point[2]}, 200, true, true, {changePitch: false, extraYaw: 90.0})
                        rotationUtils.setPitch(75 + this.macro.Obsidian.ofset, 200)
                        //return
                    //}

                    /*
                        rotationUtils.setYaw(walkPoint.Yaw)
                        rotationUtils.setPitch(walkPoint.Pitch - 20 + this.macro.Obsidian.ofset)
                    */
                }
            }
        })

        register("packetReceived", (packet, event) => {
            if(!this.toggle) return
            let x = packet.func_148932_c() //getX()
            let y = packet.func_148928_d() //getY()
            let z = packet.func_148933_e() //getZ()
            /*
                ChatLib.chat(x)
                ChatLib.chat(y)
                ChatLib.chat(z)
            */
            if(this.macro.state === "ETHERWARPING") {
                this.onEtherwarpClick({x: x, y: y, z: z})
            }
        }).setFilteredClasses([net.minecraft.network.play.server.S08PacketPlayerPosLook])

        register("command", () => {
            this.toggleMacro()
        }).setName("obi")
    }

    toggleMacro() {
        this.toggle = !this.toggle
        if(this.toggle) {
            if(finder.drill() && finder.etherwarp()) {
                finder.bluecheese()
                this.macro.state = "WARPING"
                this.macro.Etherwarp.Number = 0
                this.macro.Warp.Location = 0
                this.macro.Warp.LastCheck = new Date().getTime()

                this.settingNuker = global.exports.settingGet.getSetting(this.configName, "Nuker mode")
                this.settingInstaMine = global.exports.settingGet.getSetting(this.configName, "Can in insta mine obsidian")
                if(this.atObsidianLocation()) {
                    this.onReachArea()
                }

                ChatLib.chat(polarPrefix + " Obsidian Macro: " + this.toggle)
            } else {
                ChatLib.chat(polarPrefix + " Obsidian Macro: " + "Missing Item's")
                if(!finder.drill()) ChatLib.chat("- Drill")
                if(!finder.etherwarp()) ChatLib.chat("- Etherwarp")
                this.toggle = false
            }
        } else {
            LeftClick.setState(false)
            ChatLib.chat(polarPrefix + " Obsidian Macro: " + this.toggle)
        }
    }

    onEtherwarpClick(Location) {
        let warpPoint = this.warpPoints[this.macro.Warp.Location]
        if(mathUtils.disFrToFr(Location.x, Location.y, Location.z,warpPoint[0],warpPoint[1],warpPoint[2]) < 12) {
            this.macro.Warp.Location += 1
            warpPoint = this.warpPoints[this.macro.Warp.Location]
            ChatLib.chat("NEXR")
        }

        if(this.macro.Warp.Location === this.warpPoints.length) {
            this.macro.state = "DROPPING"
            Player.setHeldItemIndex(finder.slotDrill)
            return
        }
        rotationUtils.polarRotateTo({x: warpPoint[0], y: warpPoint[1], z: warpPoint[2]}, 200)
        itemUtils.onRotationEndRightClick()
    }

    onSpeedBoost() {
        this.macro.state = "WAITING"
        LeftClick.setState(false)
        if(finder.slotBlueCheese === undefined) {
            itemUtils.rightClick(0)
            this.macro.state = "MINING"
            return
        }
        new Thread(() => {
            Player.setHeldItemIndex(finder.slotBlueCheese)
            Thread.sleep(200)
            itemUtils.rightClick(0)
            Thread.sleep(300)
            Player.setHeldItemIndex(finder.slotDrill)
            this.macro.state = "MINING"
        }).start()
    }

    onFinishSpeedBoost() {
    }

    atEndSpawn() {
        if(Player.getY() > 100.0 && Player.getY() < 102.0 && Player.getX() > -507.0 && Player.getX() < -500.0 && Player.getZ() > -277.0 && Player.getZ() < -267.0) {
            return true
        }
        return false
    }

    atObsidianLocation() {
        if(Player.getY() > 121 && Player.getY() < 123) {
            return true
        }
        return false
    }

    atNextWalkPoint() {
        let nextPoint = this.walkPoints[this.macro.Position.next]
        if(mathUtils.disToPlyFlat(nextPoint.Point[0], nextPoint.Point[2]) < 2) {
            return true
        }
        return false
    }

    onReachArea() {
        this.macro.state = "MINING"
        this.macro.Obsidian.speedBoost = false
        this.onSpeedBoost()
        this.onUpdateClosest()
        this.onNextWalkPoint()
    }

    onUpdateClosest() {
        let inputArray = []
        for(let i = 0; i < this.walkPoints.length; i++) {
            inputArray.push(this.walkPoints[i].Point)
        }
        this.macro.Position.current = getClosest(inputArray ,"array", true)
    }

    onNextWalkPoint() {
        this.macro.Position.current = this.macro.Position.next
        this.macro.Obsidian.ofset = (10 - (20 * Math.random()))
        if(this.macro.Position.current + 1 === this.walkPoints.length) {
            this.turnToSide = !this.turnToSide
            this.macro.Position.next = 0
            return
        }
        this.macro.Position.next = this.macro.Position.current + 1
    }

    onNukeBlock() {
    }

    destroyBlock() {
    }

    stopDestroyBlock() {
    }
}

global.exports.obsidianMacro = new obsidianMacro()