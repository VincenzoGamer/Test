let { WalkLeft, WalkRight } = global.exports
let { fillJavaArray } = global.exports
let { keyBind, distanceRotation, sendPacket, C07PacketPlayerDigging, EnumFacing, polarPrefix, toBlockPos, disToPly, getClosest, rotationUtils } = global.exports
let { lookAt, Shift, cancelWalk, WalkForward, disToPlyFlat, itemUtils, mathUtils, finder, lookAtRayCast } = global.exports
import { raytraceBlocks } from "Bloomcore/utils/Utils.js"
import Vector3 from "Bloomcore/utils/Vector3.js"
import RenderLib from "RenderLib";
import Skyblock from "BloomCore/Skyblock";

const configPowderMacro = new global.configModuleClass(
    "Powder Macro",
    "Crystal Hollows",
    false,
    [
        new global.settingSlider("Look time", 1000, 100, 2000),
        new global.settingSlider("Look width", 80, 10, 270),
        new global.settingToggle("Click powder chest", false)
    ],
    [
        "&bPowder Macro",
        "Mines hardstone in the Crystal Hollows and opens the chests that spawn",
        "Requirements: Anything that break hardstone"
    ]
)

global.modules.push(configPowderMacro)

class autoPowder {
    constructor() {
        this.configName = "Powder Macro"

        this.toggle = false
        this.macro = {
            state: "MINING",
            direction: "RIGHT",
            prevDirection: "LEFT",
            motion: "UP",
            previousMotion: "MIDDLE",
            macroDirection: {yaw: 0.0, pitch: 0.0},
            Chest: {
                state: "WAITING"
            },
            moving: false,
            onChestWoggle: {
                time: 0.0,
                direction: "UP"
            },
            killState: {
                state: "KILLING",
                killTime: 0.0
            }
        }

        this.nukerBlock = fillJavaArray([1,14,15,35,16,21,56,73,74,129,159])
        this.whitelistNuker = fillJavaArray([null,null,null,null,null,null,null])

        register("command", () => {
            itemUtils.useItem(7)
        }).setName("tests")

        keyBind.keyBindPowderMacro.registerKeyPress(() => {this.toggleMacro()})

        register("tick", () => {

            if(!this.toggle) return

            while(this.whitelistNuker.size() >= 8) {
                this.whitelistNuker.remove(0)
            }
            this.whitelistNuker.add(null)

            for(let i = 0; i < this.spawnedChests.length; i++) {
                if(new Date().getTime() - this.spawnedChests[i].spawntime > 55000) {
                    if(this.spawnedChests[i].location.x === this.targetChest.location.x && this.spawnedChests[i].location.y === this.targetChest.location.y && this.spawnedChests[i].location.z === this.targetChest.location.z) {
                        this.onLockPick()
                        return
                    }
                    this.spawnedChests.splice(i,1)
                }
            }

            if(this.macro.state != "KILLING_MOBS" && this.onScanMobs().value && new Date().getTime() - this.macro.killState.killTime > 2000) {
                this.onStartKilling()
            }

            this.onChestMark()

            if(this.macro.state === "MINING") {

                Shift.setState(true)

                this.nukeBlock()

                if(this.macro.direction === "RIGHT") {
                    this.macro.prevDirection = this.macro.direction
                    this.macro.direction = "WAITING"
                    WalkRight.setState(true)
                    WalkLeft.setState(false)
                    new Thread(() => {
                        this.onStartRotation()
                        let halfWidth = Player.getPlayer().field_70177_z + (this.lookWidth/2.00000001)
                        let checkedTurn = false
                        while(true) {
                            if(!this.toggle || this.macro.state != "MINING") return
                            if(this.macro.direction != "WAITING") break

                            this.shouldMove()
                            let diff = new Date().getTime() - this.startTime
                            Thread.sleep(1)
                            if(diff > 0.0 && diff < this.lookTime * 0.6) {
                                Player.getPlayer().field_70177_z += (this.lookWidth*0.8/this.lookTime*2.2)
                            }
                            if(diff >= this.lookTime * 0.6 && diff < this.lookTime) {
                                Player.getPlayer().field_70177_z += (this.lookWidth*0.2/this.lookTime*5.5)
                            }
                            if(diff >= this.lookTime) break
                            if(mathUtils.diffNumber(Player.getPlayer().field_70177_z, halfWidth) < 1 && !checkedTurn) {
                                checkedTurn = true
                                this.shouldTurn()
                            }
                        }
                        
                        if(this.onEndRotation()) {
                            this.macro.direction = "LEFT"
                        }
                    }).start()
                }

                if(this.macro.direction === "LEFT") {
                    this.macro.prevDirection = this.macro.direction
                    this.macro.direction = "WAITING"
                    WalkRight.setState(false)
                    WalkLeft.setState(true)
                    new Thread(() => {
                        this.onStartRotation()
                        let halfWidth = Player.getPlayer().field_70177_z - (this.lookWidth/2.00000001)
                        let checkedTurn = false
                        while(true) {
                            if(!this.toggle || this.macro.state != "MINING") return
                            if(this.macro.direction != "WAITING") break
                            this.shouldMove()
                            let diff = new Date().getTime() - this.startTime
                            Thread.sleep(1)
                            if(diff > 0.0 && diff < this.lookTime * 0.6) {
                                Player.getPlayer().field_70177_z -= (this.lookWidth*0.8/this.lookTime*2.2)
                            }
                            if(diff >= this.lookTime * 0.6 && diff < this.lookTime) {
                                Player.getPlayer().field_70177_z -= (this.lookWidth*0.2/this.lookTime*5.5)
                            }
                            if(diff >= this.lookTime) break
                            if(mathUtils.diffNumber(Player.getPlayer().field_70177_z, halfWidth) < 1 && !checkedTurn) {
                                checkedTurn = true
                                this.shouldTurn()
                            }
                        }

                        if(this.onEndRotation()) {
                            this.macro.direction = "RIGHT"
                        }
                    }).start()
                }
            }

            if(this.macro.state === "CHEST_MINING") {

                if(this.macro.Chest.state === "LOOKING") {
                    this.macro.Chest.state = "WAITING"
                    this.targetChest = this.spawnedChests[0]
                    new Thread(() => {
                        cancelWalk("n")
                        rotationUtils.doRotation({x: this.targetChest.CTChest.getX() + 0.5, y: this.targetChest.CTChest.getY() + 0.5, z: this.targetChest.CTChest.getZ() + 0.5}, 300, false)
                        this.macro.Chest.state = "WALKING_CHEST"
                        this.onWalkToChest()
                        if(this.canSolveChest(this.targetChest?.CTChest)) {
                            this.procesSolve()
                            return
                        }
                    }).start()
                }

                if(this.macro.Chest.state === "WALKING_CHEST") {
                    this.nukeBlock()

                    if(this.canSolveChest(this.targetChest?.CTChest)) {
                        this.procesSolve()
                        return
                    }

                    WalkForward.setState(true)
                    if(new Date().getTime() - this.macro.onChestWoggle.time > 200) {
                        this.macro.onChestWoggle.time = new Date().getTime()
                        rotationUtils.rotateFlatTo({x: this.targetChest.CTChest.getX() + 0.5, y: this.targetChest.CTChest.getY() + 0.5, z: this.targetChest.CTChest.getZ() + 0.5}, 100)
                        if(this.macro.onChestWoggle.direction === "UP") {
                            rotationUtils.setPitch(-26.0, 75 + Math.random() * 100)
                            this.macro.onChestWoggle.direction = "DOWN"
                            return
                        }
                        rotationUtils.setPitch(28.0, 75 + Math.random() * 100)
                        this.macro.onChestWoggle.direction = "UP"
                    }
                }
            }

            if(this.macro.state === "KILLING_MOBS") {
                if(this.macro.killState.state === "KILLING") {
                    cancelWalk("no")
                    this.macro.killState.state = "WAITING"
                    new Thread(() => {
                        let entity = this.onScanEntities().entity
                        if(entity != null) {
                            Player.setHeldItemIndex(finder.slotFireVeil)
                            Thread.sleep(200)
                            itemUtils.rightClick(0)
                            Thread.sleep(300)
                            this.onStopKilling()
                        }
                    }).start()
                }
            }
        })

        register("renderWorld", () => {
            if(this.renderBlock != undefined) {
                RenderLib.drawEspBox(this.renderBlock.getX() + 0.5, this.renderBlock.getY(), this.renderBlock.getZ() + 0.5, 1, 1, 0, 1, 0, 1, true)
            }

            if(this.targetChest != undefined) {
                RenderLib.drawEspBox(this.targetChest.CTChest.getX() + 0.5, this.targetChest.CTChest.getY(), this.targetChest.CTChest.getZ() + 0.5, 1, 1, 0, 1, 0, 1, true)
            }
        })

        register("chat", (event) => {
            if(!this.toggle) return
            let msg = ChatLib.getChatMessage(event, false)

            if(msg === "You uncovered a treasure chest!") {
                this.onChestMark()
            }

            if(msg === "You have successfully picked the lock on this chest!" && !this.clickChest) {
                this.onLockPick()
            }
        })

        register("packetReceived", (packet,event) => {
            if(this.macro.Chest.state != "OPEN_CHEST" || this.macro.state != "CHEST_MINING" || !this.toggle || this.clickChest) return
            if(packet.func_179749_a().toString() === "CRIT") {
                if(Math.abs(packet.func_149220_d() - (this.targetChest?.location?.x + 0.5)) < 0.7 && Math.abs(packet.func_149226_e() - (this.targetChest?.location?.y + 0.5)) < 0.7 && Math.abs(packet.func_149225_f() - (this.targetChest?.location?.z + 0.5)) < 0.7) {
                    rotationUtils.onStopRotation()
                    rotationUtils.rotateTo({x: packet.func_149220_d(), y: packet.func_149226_e(), z: packet.func_149225_f()}, 100, false)
                }
            }
        }).setFilteredClasses([net.minecraft.network.play.server.S2APacketParticles])

        register("command", () => {
            this.toggleMacro()
        }).setName("powder")
    }

    toggleMacro() {
        this.toggle = !this.toggle
        if(this.toggle) {
            if((!finder.pickaxe() && !finder.drill()) || !finder.fireveil() || Skyblock.area != "Crystal Hollows") {
                finder.drill()
                ChatLib.chat(polarPrefix + "Powder Macro: Missing Item's")
                if(!finder.drill()) ChatLib.chat("- drill or pickaxe")
                if(!finder.fireveil()) ChatLib.chat("- fireveil")
                if(Skyblock.area != "Crystal Hollows") ChatLib.chat("- be in the Crystal Hollows")
                this.toggle = false
                return
            }
            ChatLib.chat(polarPrefix + "Powder Macro: " + this.toggle)

            this.macro.state = "MINING"
            this.macro.direction = "RIGHT"
            this.macro.prevDirection = "LEFT"
            this.macro.motion = "UP"
            this.macro.previousMotion = "MIDDLE"
            this.macro.Chest.state = "LOOKING"
            this.macro.macroDirection = {yaw: Player.getYaw(), pitch: Player.getPitch()}
            this.macro.moving = false
            this.existingChests = []
            
            let chests = World.getAllTileEntitiesOfType(net.minecraft.tileentity.TileEntityChest)
            for(let i = 0; i < chests.length; i++) {
                this.existingChests.push([chests[i].getX(), chests[i].getY(), chests[i].getZ()])
            }

            this.spawnedChests = []
            this.targetChest = undefined
            this.clickChest = global.exports.settingGet.getSetting(this.configName, "Click powder chest")

            this.lookTime = global.exports.settingGet.getSetting(this.configName, "Look time")
            this.lookWidth = global.exports.settingGet.getSetting(this.configName, "Look width")
            this.startTime = new Date().getTime() - this.lookTime*0.4

            this.macro.killState.state = "KILLING"
            this.macro.killState.killTime = new Date().getTime()

            this.equipDrill()
        } else {
            ChatLib.chat(polarPrefix + "Powder Macro: " + this.toggle)
            this.renderBlock = undefined
            this.targetChest = undefined
            rotationUtils.onStopRotation()
        }
    }

    nukeBlock() {
        const plyX = Player.getX()
        const plyY = Player.getY()
        const plyZ = Player.getZ()

        let nukeBlock = undefined
        let rotationBlocks = []
        for(let x = -1; x <= 1; x++) {
            for(let z = -1; z <= 1; z++) {
                for(let y = 0; y <= 2; y++) {
                    let block = World.getBlockAt(plyX + x, plyY + y, plyZ + z)
                    if(!this.whitelistNuker.contains(toBlockPos(block)) && this.nukerBlock.contains(block.type.getID())) {
                        rotationBlocks.push(block)
                    }
                }
            }
        }

        nukeBlock = getClosest(rotationBlocks, "blockct", false)
        this.destroyBlock(nukeBlock)
        if(nukeBlock != undefined) {
            return
        }

        rotationBlocks = []

        for(let y = 0; y <= 2; y++) {
            for(let x = -6; x <= 6; x++) {
                for(let z = -6; z <= 6; z++) {
                    let block = World.getBlockAt(plyX + x, plyY + y, plyZ + z)
                    if(!this.whitelistNuker.contains(toBlockPos(block)) && this.nukerBlock.contains(block.type.getID()) && disToPly(block.getX() + 0.5, block.getY() + 0.5, block.getZ() + 0.5) < 4.5 && rotationUtils.getRotationLength({x: block.getX() + 0.5, y: block.getY() + 0.5, z: block.getZ() + 0.5}, false) < 40) {
                        rotationBlocks.push(block)
                    }
                }
            }
        }

        nukeBlock = getClosest(rotationBlocks, "blockct", false)
        this.destroyBlock(nukeBlock)
    }

    destroyBlock(block) {
        if(block === undefined) return
        let pos = toBlockPos(block)
        sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, pos, EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
        Player.getPlayer().func_71038_i()
        this.renderBlock = block
        this.whitelistNuker.add(pos)
        while(this.whitelistNuker.size() > 7) {
            this.whitelistNuker.remove(0)
        }
    }

    stopDestroyBlock(block) {
        if(block === undefined) return
        let pos = toBlockPos(block)
        sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, pos, EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
        this.renderBlock = undefined
    }

    onStartRotation() {
        this.macro.moving = true
        this.startMove = new Date().getTime()
        WalkForward.setState(true)
    }

    shouldMove() {
        if(this.canMove()) {
            WalkForward.setState(true)
            return
        }
        this.macro.moving = false
        WalkForward.setState(false)
    }

    canMove() {
        let rayCastPath = raytraceBlocks(null, null, 3.0, null, false, false)
        for(let i = 0; i < rayCastPath.length; i++) {
            let last = rayCastPath[i]
            let id = World.getBlockAt(last[0], last[1], last[2]).type.getID()
            if(id != 0.0) {
                break
            }
            if(i === (rayCastPath.length-1)) {
                return true
            }
        }
        return false
    }

    shouldTurn() {
        let onTurn = this.canTurn()
        if(onTurn.type === "STRUCTURE" || onTurn.type === "GEMSTONE" || onTurn.type === "AIR") {
            this.macro.direction = this.macro.prevDirection
            return true
        }
        return false
    }

    canTurn() {
        let rayCastPath = raytraceBlocks(null, null, 10, null, false, false)
        for(let i = 0; i < rayCastPath.length; i++) {
            let cast = rayCastPath[i]
            if(World.getBlockAt(cast[0], cast[1], cast[2]).type.getID() != 0) {
                break
            }
            if(i === (rayCastPath.length-1)) {
                return {value: true, type: "AIR"}
            }
        }

        rayCastPath = raytraceBlocks(null, null, 6, null, false, false)
        let obstruction = [0.0,95.0,160.0,168.0]
        for(let i = 0; i < rayCastPath.length; i++) {
            let cast = rayCastPath[i]
            let id = World.getBlockAt(cast[0], cast[1], cast[2]).type.getID()
            if(!this.nukerBlock.contains(id) && !obstruction.toString().includes(id.toString()) && cast[1] >= Player.getY() && cast[1] <= Player.getY() + 3) { 
                return {value: true, type: "STRUCTURE", id: id}
            }
            if(i === (rayCastPath.length-1)) {
                break
            }
        }

        // rayCastPath = raytraceBlocks(null, null, 3, null, false, false)
        // for(let i = 0; i < rayCastPath.length; i++) {
        //     let cast = rayCastPath[i]
        //     let id = World.getBlockAt(cast[0], cast[1], cast[2]).type.getID()
        //     if((id === 160.0 || id === 95.0 || id === 168.0) && cast[1] >= Player.getY() && cast[1] <= Player.getY() + 3) {
        //         return {value: true, type: "GEMSTONE"}
        //     }
        //     if(i === (rayCastPath.length-1)) {
        //         break
        //     }
        // }

        return {value: false, type: "NONE"}
    }

    onEndRotation() {
        this.startTime = new Date().getTime()

        switch(this.macro.motion) {
            case("UP"):
            case("DOWN"):
                this.macro.previousMotion = this.macro.motion
                this.macro.motion = "MIDDLE"
                break
            case("MIDDLE"):
                this.macro.motion = this.macro.previousMotion === "UP" ? "DOWN" : "UP";
                this.macro.previousMotion = "MIDDLE"
                break
        }

        switch(this.macro.motion) {
            case("UP"):
                rotationUtils.setPitch(-12, 200)
                break
            case("DOWN"):
                rotationUtils.setPitch(12, 200)
                break
            case("MIDDLE"):
                rotationUtils.setPitch(0, 200)
                break
        }

        if(this.macro.direction != "WAITING") {
            return false
        }
        return true
    }

    onWalkToChest() {
        this.macro.onChestWoggle.time = new Date().getTime() - 500
    }

    canSolveChest(Chest) {
        if((disToPly(Chest?.getX() + 0.5, Chest?.getY() + 0.5, Chest?.getZ() + 0.5) < 4.0 && disToPlyFlat(Chest?.getX() + 0.5, Chest?.getZ() + 0.5) < 2.0)) {
            Shift.setState(false)
            return true
        }
        return false
    }

    procesSolve() {
        if(this.renderBlock != undefined) {
            this.stopDestroyBlock(this.renderBlock)
        }
        this.equipBlueCheese()
        cancelWalk("no")
        this.macro.Chest.state = "OPEN_CHEST"
        if(this.clickChest) {
            new Thread(() => {
                rotationUtils.onStopRotation()
                lookAtRayCast(this.targetChest?.CTChest?.getX(), this.targetChest?.CTChest?.getY(), this.targetChest?.CTChest?.getZ(), 100, false, false)
                let start = new Date().getTime()
                while((Player.lookingAt()?.getX() != this.targetChest?.CTChest?.getX() || Player.lookingAt()?.getY() != this.targetChest?.CTChest?.getY() || Player.lookingAt()?.getZ() != this.targetChest?.CTChest?.getZ()) && this.toggle) {
                    if(new Date().getTime() - start > 1000) {
                        ChatLib.chat(polarPrefix + "Took to long stopping")
                        break
                    } 
                    Thread.sleep(1)
                }
                itemUtils.rightClick(0)
                this.onLockPick()
            }).start()
        }
    }

    canReachChest(Chest) {
        if(disToPly(Chest.getX() + 0.5, Chest.getY() + 0.5, Chest.getZ() + 0.5) < 20.0 && Chest.getY() - Player.getY() >= 0.0 && Chest.getY() - Player.getY() <= 3.0 && World.getBlockAt(Chest.getX(), Player.getY()-1, Chest.getZ()).type.getID() != 0.0) {
            return true
        }
        return false
    }

    onLockPick() {
        this.targetChest = null
        this.spawnedChests.shift()
        if(this.spawnedChests.length > 0.0) {
            this.targetChest = this.spawnedChests[0]
            this.macro.Chest.state = "LOOKING"
            return
        } else {
            new Thread(() => {
                Thread.sleep(500)
                rotationUtils.onStopRotation()
                rotationUtils.setYaw(this.macro.macroDirection.yaw, 200)
                rotationUtils.setPitch(this.macro.macroDirection.pitch, 200)
                while(!rotationUtils.end.isDone && this.toggle) {
                    Thread.sleep(1)
                }
                this.equipDrill()
                this.macro.state = "MINING"
                this.macro.direction = "RIGHT"
                this.macro.Chest.state = "LOOKING"
                this.startTime = new Date().getTime() - this.lookTime*0.4
            }).start()
        }
    }

    onChestMark() {
        let chests = World.getAllTileEntitiesOfType(net.minecraft.tileentity.TileEntityChest)
        for(let i = 0; i < chests.length; i++) {
            if(!this.existingChests.toString().includes([chests[i].getX(), chests[i].getY(), chests[i].getZ()].toString())) {
                this.onChestSpawn(chests[i])
            }
        }
    }

    onChestSpawn(Chest) {
        this.existingChests.push([Chest.getX(), Chest.getY(), Chest.getZ()])
        if(this.canReachChest(Chest)) {
            cancelWalk("none")
            this.spawnedChests.push({
                spawntime: new Date().getTime(),
                location: {
                    x: Chest.getX(),
                    y: Chest.getY(),
                    z: Chest.getZ()
                },
                CTChest: Chest
            })
            
            this.macro.state = "CHEST_MINING"
            if(this.spawnedChests.length === 1.0) {
                this.macro.macroDirection = { yaw: Player.getYaw(), pitch: Player.getPitch() }
                this.macro.Chest.state = "LOOKING"
            }
        }
    }

    onScanMobs() {
        return this.onScanEntities()
    }

    onScanEntities() {
        let mcClasses = [net.minecraft.entity.monster.EntityMagmaCube, net.minecraft.entity.monster.EntitySlime, net.minecraft.entity.monster.EntityGolem]
        let entities = World.getAllEntities()
        for(let i = 0; i < entities.length; i++) {
            for(let f = 0; f < mcClasses.length; f++) {
                if(entities[i].entity instanceof mcClasses[f] && disToPly(entities[i].getX(), entities[i].getY(), entities[i].getZ()) < 4) {
                    return { value: true, entity: entities[i].entity }
                }
            }
        }
        return { value: false, entity: null }
    }

    onStartKilling() {
        this.macro.state = "KILLING_MOBS"
    }

    onStopKilling() {
        this.macro.killState.state = "KILLING"
        this.macro.killState.killTime = new Date().getTime()
        this.onLockPick()
        this.equipDrill()
    }

    equipDrill() {
        if(finder.slotDrill != undefined) {
            Player.setHeldItemIndex(finder.slotDrill)
            return
        }
        Player.setHeldItemIndex(finder.slotPickaxe)
    }

    equipBlueCheese() {
        if(finder.bluecheese()) {
            Player.setHeldItemIndex(finder.slotBlueCheese)
        }
    }
}

global.exports.powderMacro = new autoPowder()