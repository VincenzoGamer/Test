import Skyblock from "BloomCore/Skyblock";

let { polarPrefix, keyBind, fillJavaArray } = global.exports

const configXRay = new global.configModuleClass(
    "Crystal X-ray",
    "Crystal Hollows",
    false,
    [
        new global.settingToggle("Enabled", false),
        new global.settingToggle("Structures", true),
        new global.settingToggle("Mithril", true),
        new global.settingToggle("Gemstones", true),
        new global.settingToggle("Path's", true)
    ],
    [
        "X-ray made for the Crystal Hollow's"
    ]
)

global.modules.push(configXRay)

let Blocks = Java.type("net.minecraft.init.Blocks")
class xray {
    constructor() {
        this.configName = "Crystal X-ray"
        this.toggle = false

        this.Blocksid = {
            "stained_glass": 160,
            "stained_glass_pane": 95,
            "dirt": 3,
            "cobblestone": 4,
            "oak_stairs": 53,
            "dark_oak_stairs": 134,
            "slab": 42,
            "double_slab": 43,
            "slab2": 44,
            "slab3": 126,
            "log": 17,
            "log2": 162,
            "obsidian": 49,
            "farmland": 60,
            "Prismarine": 168,
            "Stone_Brick_Stairs": 109
        }

        this.BlocksObj = {
            "stained_glass": Blocks.field_150399_cn,
            "stained_glass_pane": Blocks.field_150397_co,
            "dirt": Blocks.field_150346_d,
            "cobblestone": Blocks.field_150347_e,
            "oak_stairs": Blocks.field_150476_ad,
            "dark_oak_stairs": Blocks.field_150401_cl,
            "stone_slab": Blocks.field_150333_U,
            "stone_slab2": Blocks.field_180389_cP,
            "wooden_slab": Blocks.field_150376_bx,
            "log": Blocks.field_150364_r,
            "log2": Blocks.field_150363_s,
            "obsidian": Blocks.field_150343_Z,
            "farmland": Blocks.field_150458_ak,
            "Prismarine": Blocks.field_180397_cI
        }

        this.blockList = fillJavaArray([this.BlocksObj.stained_glass])
        keyBind.keyBindXRay.registerKeyPress(() => {this.toggleMacro()})
    }

    toggleMacro() {
        this.toggle = !this.toggle
        if(this.toggle) {
            if(Skyblock.area != "Crystal Hollows") {
                ChatLib.chat(polarPrefix + "X-ray: " + this.toggle)
                let sStructure = global.exports.settingGet.getSetting(this.configName, "Structures")
                let sGemstone = global.exports.settingGet.getSetting(this.configName, "Gemstones")
                let sMithril = global.exports.settingGet.getSetting(this.configName, "Mithril")
                let sPath = global.exports.settingGet.getSetting(this.configName, "Path's")
                this.blockList = fillJavaArray([this.BlocksObj.stained_glass, this.BlocksObj.stained_glass_pane])
                if(sStructure) {
                    this.blockList.add(this.BlocksObj.stone_slab)
                    this.blockList.add(this.BlocksObj.stone_slab2)
                    this.blockList.add(this.BlocksObj.cobblestone)
                    this.blockList.add(this.BlocksObj.log)
                    this.blockList.add(this.BlocksObj.log2)
                }
                if(sGemstone) {
                    this.blockList.add(this.BlocksObj.stained_glass)
                    this.blockList.add(this.BlocksObj.stained_glass_pane)
                }
                if(sMithril) {
                    this.blockList.add(this.BlocksObj.Prismarine)
                }
                if(sPath) {
                    this.blockList.add(this.BlocksObj.farmland)
                    this.blockList.add(this.BlocksObj.oak_stairs)
                    this.blockList.add(this.BlocksObj.dark_oak_stairs)
                    this.blockList.add(this.BlocksObj.obsidian)
                    this.blockList.add(this.BlocksObj.stone_slab)
                    this.blockList.add(this.BlocksObj.stone_slab2)
                    this.blockList.add(this.BlocksObj.dirt)
                    this.blockList.add(this.BlocksObj.wooden_slab)
                }
                global.exports.xrayconfig.blocks = this.blockList
                global.exports.xrayconfig.toggle = this.toggle
                Client.getMinecraft().field_71438_f.func_72712_a()
            } else {
                ChatLib.chat(polarPrefix + "X-ray: Be in the Crystal Hollows")
                this.toggle = false
                global.exports.xrayconfig.toggle = this.toggle
            }
        } else {
            ChatLib.chat(polarPrefix + "X-ray: " + this.toggle)
            global.exports.xrayconfig.toggle = this.toggle
            Client.getMinecraft().field_71438_f.func_72712_a()
        }
    }
}

class xRayConfig {
    constructor() {
        this.blocks = fillJavaArray([null])
        this.toggle = false
    }
}

global.exports.xrayconfig = new xRayConfig()
global.exports.xray = new xray()