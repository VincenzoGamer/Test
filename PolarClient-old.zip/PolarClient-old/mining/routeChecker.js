import Skyblock from "BloomCore/Skyblock";
import { raytraceBlocks } from "Bloomcore/utils/Utils.js"
import Vector3 from "Bloomcore/utils/Vector3.js"
let { gemstone, polarPrefix, fillJavaArray, disFrToFr } = global.exports

class routeChecker {
    constructor() {
        this.a = fillJavaArray([1,14,15,16,21,56,73,74,129,95,160,0,168,159,35])
        this.cords = []

        register("command", (x) => {
            if(x === undefined) {
                ChatLib.chat(polarPrefix + "Command usage -> /check <gemstone>")
            }

            else if(x.toString().toLocaleLowerCase() === "gemstone" && Skyblock.area === "Crystal Hollows") {
                new Thread(() => {
                    ChatLib.chat(polarPrefix + "Checking Gemstone Route, might take a while...")
                    let start = Date.now()
                    let array = this.getBlocks("gemstone")
                    ChatLib.chat(polarPrefix + "Finished getting blocks, now scanning them...")
                    let found = false
                    let lastI = []
                    for(let i = 0; i < array.length; i++) {
                        let cords = array[i]
                        for(let f = 0; f < cords.length; f++) {
                            let cord = cords[f]
                            let id = World.getBlockAt(cord[0],cord[1],cord[2]).type.getID()
                            if(!this.a.contains(id)) {
                                lastI.push(i + 1)
                                found = true
                                break
                            }
                        }
                    }
                    ChatLib.chat(polarPrefix + "In total took: " + (Date.now() - start)/1000 + " seconds")
                    if(found) {
                        ChatLib.chat(polarPrefix + "The Route was obstructed :thumbsdowncat: at " + lastI.toString())
                    } else {
                        ChatLib.chat(polarPrefix + "The Route is good :thumbsupcat:")
                    }
                }).start()
            }

            else {
                ChatLib.chat(polarPrefix + "Command usage -> /check [gemstone/armadillo]")
            }
        }).setName("check")
    }

    getBlocks(macro) {
        if(macro === "gemstone") {
            let cords = gemstone.cords
            let array = []
            for(let i = 0; i < cords.length; i++) {
                    let cord = cords[i]
                    if(i != 0) {
                        let pX = cords[i-1][0]
                        let pY = cords[i-1][1] + 1.54
                        let pZ = cords[i-1][2]
                        let dis = disFrToFr(pX + 0.5, pY + 1, pZ + 0.5, cord[0] + 0.5, cord[1] + 0.5, cord[2] + 0.5)
                        array.push(raytraceBlocks([pX + 0.5,pY + 1,pZ + 0.5], new Vector3(cord[0] + 0.5 - pX, cord[1] + 0.5 - pY, cord[2] + 0.5 - pZ), dis, null, false, false))
                    }
            }
            return array
        }
    }
}

global.exports.routeChecker = new routeChecker()