let {keyBind} = global.exports
let { fillJavaArray } = global.exports
let { C07PacketPlayerDigging, EnumFacing, C0APacketAnimation, mc, cords, setting, polarPrefix, sendPacket, ArrayLists, C09PacketHeldItemChange} = global.exports
let { disToPly } = global.exports
let { toBlockPos, toPosBlock } = global.exports
let { finder } = global.exports
let { disFrToFr } = global.exports
import { raytraceBlocks } from "Bloomcore/utils/Utils.js"
import Vector3 from "Bloomcore/utils/Vector3.js"
import RenderLib from "RenderLib";

const configRouteNuker = new global.configModuleClass(
    "Route Nuker",
    "Crystal Hollows",
    false,
    [
        new global.settingToggle("20bps Nuking Speed", false),
        new global.settingToggle("Big tunnel mode", false),
        new global.settingToggle("No Nuker", false),
        new global.settingToggle("Armadillo Route")
    ],
    [
        "&bRoute Nuker",
        "The Route Nuker mines out the blocks between the Route coordinates at a base of 10bps.",
        "If you want to use the Route Nuker for the Armadillo Macro, you need to toggle the Armadillo Route",
        "Requirements: Drill/Gauntlet"
    ]
)

global.modules.push(configRouteNuker)

class routeNuker {
    constructor() {

        this.configName = "Route Nuker"

        this.toggle = false;
        this.cords = [[]];
        this.nukerBlocks = fillJavaArray([1,14,15,16,21,56,73,74,129,159,35]);
        this.check = [];
        this.justBroken = [null,null,null,null,null,null,null];
        this.mineX = [];
        this.mineY = [];
        this.mineZ = [];
        this.aotvBlocksX = [];
        this.aotvBlocksY = [];
        this.aotvBlocksZ = [];
        this.block = undefined;
        this.block1 = undefined;
        this.block2 = undefined;
        this.routeIndex = 0;
        this.color = [0,0,1];
        this.previousBlock = undefined
        this.bps20 = false
        this.justBrokenNuker = fillJavaArray([null,null,null,null,null,null])

        this.miningGemstone = false

        this.wait = false
        this.counter = 0
        
        keyBind.keyBindRouteNuker.registerKeyPress(() => {this.toggleMacro()})

        register("Tick", () => {
            if(this.toggle) {

                //ChatLib.chat(this.miningGemstone)
                //if((!Player.getHeldItem().getName().includes("Gauntlet") || !Player.getHeldItem().getName().includes("Drill") || !Player.getHeldItem().getRegistryName().includes("pickaxe")) && this.miningGemstone) {this.miningGemstone = false}

                if(this.routeAssist) return

                if(Player.getHeldItem() === null) {this.previousBlock = undefined; return}
                let name = Player.getHeldItem().getName().toLowerCase()
                if(this.miningGemstone && (name.includes("gauntlet") || name.includes("drill") || name.includes("pickaxe")) && disToPly(this.previousBlock.func_177958_n(), this.previousBlock.func_177956_o(), this.previousBlock.func_177952_p()) < 4.5) {
                    if(toPosBlock(this.previousBlock).type.getID() === 0) {
                        this.miningGemstone = false
                    }
                } else {
                    this.miningGemstone = false
                }

                if(this.previousBlock != undefined && !this.miningGemstone) {
                    //ChatLib.chat("STOP " + this.counter)
                    //sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.previousBlock, EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
                    this.previousBlock = undefined
                }

                if(!this.miningGemstone) {
                    while(this.check.length > 15) {
                        this.check.shift()
                    }

                    if(this.justBroken[0] != null) {
                        this.check.push(this.justBroken[0])
                        this.justBroken.shift()
                        this.justBroken.push(null)
                    } else {
                        this.justBroken.push(null)
                    }

                    while(this.justBroken.length > 10) {
                        while(this.justBroken.length > 10) {
                            if(this.justBroken[0] != null) {
                                this.check.push(this.justBroken[0])
                                this.justBroken.shift()
                            } else {
                                this.justBroken.shift()
                            }
                        }
                    }
                }

                //ChatLib.chat(this.justBroken.toString())
                //}

                if(!this.miningGemstone) {
                    if(Player.getHeldItem() === null) {this.previousBlock = undefined; return}
                    if(name.includes("gauntlet") || name.includes("drill") || name.includes("pickaxe")) {
                            if(this.wait || this.bps20) {
                            this.wait = false
                            let mined = false

                            if(!mined) {
                                for(let i = 0; i < this.check.length; i++) {
                                    //ChatLib.chat(this.check[i])
                                    let block = toPosBlock(this.check[i])
                                    if(this.nukerBlocks.contains(block.type.getID()) && disToPly(block.getX(), block.getY(), block.getZ()) < 4.5) {

                                        if(block.type.getID() === 160 || block.type.getID() === 95) {
                                            //ChatLib.chat("Switched!")
                                            //sendPacket(new C09PacketHeldItemChange(finder.slotDrill))
                                            this.miningGemstone = true
                                        }

                                        //this.counter += 1
                                        //ChatLib.chat("START " + this.counter)

                                        // for(let j = 0; j < this.cords.length; j++) {
                                        //     if(block.getX() === this.cords[j][0] && block.getY() === this.cords[j][1] && block.getZ() === this.cords[j][2]) {
                                        //         this.currentCord = j
                                        //     }
                                        // }

                                        mc.field_71439_g.func_71038_i()
                                        //sendPacket(new C0APacketAnimation())
                                        sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, this.check[i], EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
                                        this.justBroken.push(this.check[i])
                                        this.previousBlock = this.check[i]
                                        this.check.splice(i,1)
                                        mined = true
                                        break
                                    }
                                }
                            }
                            
                            if(!mined) {
                                try {
                                    if(disToPly(this.block.getX(), this.block.getY(), this.block.getZ()) < 4.5 && Player.getPlayer().field_70122_E && this.previousBlock === undefined && !this.justBroken.includes(toBlockPos(this.block)) && this.nukerBlocks.contains(this.block.type.getID())) {
                                        let pos = toBlockPos(this.block)
                                        //this.counter += 1
                                        //ChatLib.chat("START " + this.counter)

                                        if(this.block.type.getID() === 160 || this.block.type.getID() === 95) {
                                            //ChatLib.chat("Switched!")
                                            //sendPacket(new C09PacketHeldItemChange(finder.slotDrill))
                                            this.miningGemstone = true
                                        }

                                        // for(let j = 0; j < this.cords.length; j++) {
                                        //     if(this.block.getX() === this.cords[j][0] && this.block.getY() === this.cords[j][1] && this.block.getZ() === this.cords[j][2]) {
                                        //         this.currentCord = j
                                        //     }
                                        // }

                                        mc.field_71439_g.func_71038_i()
                                        //sendPacket(new C0APacketAnimation())
                                        sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, pos, EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
                                        mined = true
                                        this.justBroken.push(pos)
                                        this.previousBlock = pos

                                        this.routeIndex += 1
                                    }
                                } catch(e) {}
                            }

                            if(!mined && this.bigTunnelMode) {
                                let plyX = Math.floor(Player.getX())
                                let plyY = Math.floor(Player.getY())
                                let plyZ = Math.floor(Player.getZ())
                                let blocks = []
                                for (let x = -6; x <= 6; x++) {
                                    for (let y = 0; y <= 5; y++) {
                                        for (let z = -6; z <= 6; z++) {
                                            let block = World.getBlockAt(plyX + x, plyY + y, plyZ + z)
                                            let pos = toBlockPos(block)
                                            if(this.nukerBlocks.contains(block.type.getID()) && disToPly(plyX + x + 0.5, plyY + y + 0.5, plyZ + z + 0.5) < 3 && Player.getPlayer().field_70122_E && !this.justBrokenNuker.contains(pos) && this.previousBlock === undefined) {
                                                blocks.push(block)
                                            }
                                        }
                                    }
                                }
                                let closest = undefined
                                for(let i = 0; i < blocks.length; i++) {
                                    let block = blocks[i]
                                    if(closest === undefined) closest = block
                                    else if(disToPly(block.getX() + 0.5, block.getY() + 0.5, block.getZ() + 0.5) < disToPly(closest.getX() + 0.5, closest.getY() + 0.5, closest.getZ() + 0.5)) closest = block
                                }

                                if(closest != undefined) {
                                    let pos = toBlockPos(closest)
                                    mc.field_71439_g.func_71038_i()
                                    //sendPacket(new C0APacketAnimation())
                                    sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, pos, EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
                                    mined = true
                                    this.justBrokenNuker.remove(0)
                                    this.justBrokenNuker.add(pos)
                                    this.previousBlock = pos
                                }
                            }
                        } else {
                            this.wait = true
                        }
                    }
                } else {
                    mc.field_71439_g.func_71038_i()
                    //sendPacket(new C0APacketAnimation())
                }
            }
        })

        register("RenderWorld", () => {
            if(this.toggle) {
                if(this.routeIndex < this.mineX.length) {
                    this.routeColor(this.routeIndex)

                    this.block = World.getBlockAt(this.mineX[this.routeIndex], this.mineY[this.routeIndex], this.mineZ[this.routeIndex])
                    RenderLib.drawEspBox(this.mineX[this.routeIndex] + 0.5, this.mineY[this.routeIndex], this.mineZ[this.routeIndex] + 0.5, 1, 1, 1, 5, 5, 1, true);
                    
                    for(let j = 0; j < this.cords.length; j++) {
                        if(this.block.getX() === this.cords[j][0] && this.block.getY() === this.cords[j][1] && this.block.getZ() === this.cords[j][2]) {
                            this.currentCord = j
                        }
                        if(this.block.getX() === this.cords[j][0] && this.block.getY() - 2 === this.cords[j][1] && this.block.getZ() === this.cords[j][2]) {
                            this.currentCord = j
                        }
                    }

                    if(this.routeIndex + 1 < this.mineX.length) {
                        this.block1 = World.getBlockAt(this.mineX[this.routeIndex + 1], this.mineY[this.routeIndex + 1], this.mineZ[this.routeIndex + 1])
                        RenderLib.drawEspBox(this.mineX[this.routeIndex + 1] + 0.5, this.mineY[this.routeIndex + 1], this.mineZ[this.routeIndex + 1] + 0.5, 1, 1, 1, 5, 5, 1, true);
                    }

                    if(this.routeIndex + 2 < this.mineX.length) {
                        this.block2 = World.getBlockAt(this.mineX[this.routeIndex + 2], this.mineY[this.routeIndex + 2], this.mineZ[this.routeIndex + 2])
                        RenderLib.drawEspBox(this.mineX[this.routeIndex + 2] + 0.5, this.mineY[this.routeIndex + 2], this.mineZ[this.routeIndex + 2] + 0.5, 1, 1, 1, 5, 5, 1, true);
                    }
                } else {
                    ChatLib.chat(polarPrefix + " Done with the route!")
                    this.toggleMacro()
                }

                if(this.previousBlock != undefined) {
                    RenderLib.drawInnerEspBox(this.previousBlock.func_177958_n() + 0.5, this.previousBlock.func_177956_o(), this.previousBlock.func_177952_p() + 0.5, 1, 1, 0, 1, 0, 0.2, true)
                }
            }

            if(this.routeIndex < this.mineX.length) {
                try {
                if(!this.nukerBlocks.contains(this.block.type.getID())) {
                    this.routeIndex += 1
                }
                } catch(e) {
                    this.routeIndex += 1
                }
            }

        })
    }

    toggleMacro() {
        this.toggle = !this.toggle
        if(this.toggle) {
            finder.bluecheese()
            if(finder.drill() || finder.pickaxe()) {
            ChatLib.chat(polarPrefix + " Route Nuker: " + this.toggle)
            this.bps20 = global.exports.settingGet.getSetting(this.configName,"20bps Nuking Speed")
            this.routeAssist = global.exports.settingGet.getSetting(this.configName,"No Nuker")
            this.bigTunnelMode = global.exports.settingGet.getSetting(this.configName,"Big tunnel mode")
            this.start()
            } else {
                ChatLib.chat(polarPrefix + " Mining Item needed!")
                this.toggle = false
            }
        } else {
            ChatLib.chat(polarPrefix + " Route Nuker: " + this.toggle)
            this.currentCord = undefined    
            if(this.previousBlock != undefined) {
                //ChatLib.chat("STOP " + this.counter)
                sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.previousBlock, EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
                this.previousBlock = undefined
            }
        }
    }

    getBlocks(macro) {
        this.selectCords()
        if(macro === "armadillo") {
            let cords = this.cords
            let array = []
            for(let i = 0; i < cords.length; i++) {
                    let cord = cords[i]
                    if(i != 0) {
                        let pX = cords[i-1][0]
                        let pY = cords[i-1][1] + 1.54
                        let pZ = cords[i-1][2]
                        let dis = disFrToFr(pX + 0.5, pY + 1, pZ + 0.5, cord[0] + 0.5, cord[1] + 0.5, cord[2] + 0.5)
                        array.push(raytraceBlocks([pX,pY + 1,pZ], new Vector3(cord[0] + 0.5 - pX, cord[1] - pY, cord[2] + 0.5 - pZ), dis, null, false, false))
                    }
            }
            return array
        }

        if(macro === "gemstone") {
            let cords = this.cords
            let array = []
            for(let i = 0; i < cords.length; i++) {
                    let cord = cords[i]
                    if(i != 0) {
                        let pX = cords[i-1][0]
                        let pY = cords[i-1][1] + 1.54
                        let pZ = cords[i-1][2]
                        let dis = disFrToFr(pX + 0.5, pY + 1, pZ + 0.5, cord[0] + 0.5, cord[1] + 0.5, cord[2] + 0.5)
                        array.push(raytraceBlocks([pX + 0.5,pY + 1,pZ + 0.5], new Vector3(cord[0] + 0.5 - pX, cord[1] + 0.5 - pY, cord[2] + 0.5 - pZ), dis, null, false, false))
                    }
            }
            return array
        }
    }

    selectCords() {
        if(!global.exports.settingGet.getSetting(this.configName,"Armadillo Route")) {
            let theSetting = global.exports.settingGet.getSetting("Gemstone Macro","Gemstone Macro Route")
            this.setting = theSetting
            if(theSetting === "&cRuby&f Default - 42 veins") {this.cords = cords.RubyFourth} else
            if(theSetting === "&cRuby&f Default - 68 veins") {this.cords = cords.RubyThird}
        } else {
            let setting = global.exports.settingGet.getSetting("Armadillo Macro","Armadillo Macro Route")
            this.setting = setting
            switch(setting) {
                case "Corner of the Mithril Deposits":
                    this.cords = cords.armadillo1
                    break;
                case "Custom 1":
                    this.cords = cords.armadilloCustom1
                    break;
                case "Custom 2":
                    this.cords = cords.armadilloCustom2
                    break;
                case "Custom 3":
                    this.cords = cords.armadilloCustom3
                    break;
                case "Custom 4":
                    this.cords = cords.armadilloCustom4
                    break;
                case "Custom 5":
                    this.cords = cords.armadilloCustom5
                    break;
            }
        }
    }

    makeArray(range) {
        this.aotvBlocksX = [];
        this.aotvBlocksY = [];
        this.aotvBlocksZ = [];

        for(let i = 0; i < this.cords.length; i++) {
            this.aotvBlocksX.push(this.cords[i][0]);
            this.aotvBlocksY.push(this.cords[i][1]);
            this.aotvBlocksZ.push(this.cords[i][2]);
        }

        this.aotvBlocksX.push(this.aotvBlocksX[0]);
        this.aotvBlocksY.push(this.aotvBlocksY[1]);
        this.aotvBlocksZ.push(this.aotvBlocksZ[2]);

        this.mineX = [];
        this.mineY = [];
        this.mineZ = [];
        if(range === undefined) {
            for (var i = 0; i < this.aotvBlocksX.length - 1; i++) {
                for(let x = -1; x <= 1; x++) {
                    for(let z = -1; z <= 1; z++) {
                        for(let y = 0; y <= 2; y++) {
                            if(x === 0 && z === 0 && y === 0) continue
                            this.mineX.push(this.aotvBlocksX[i] + x)
                            this.mineY.push(this.aotvBlocksY[i] + y)
                            this.mineZ.push(this.aotvBlocksZ[i] + z)
                        }
                    }
                }
                if(i + 1 === this.aotvBlocksX.length - 1) {
                    this.calcBlocks(this.aotvBlocksX[i], this.aotvBlocksY[i], this.aotvBlocksZ[i], this.aotvBlocksX[0], this.aotvBlocksY[0], this.aotvBlocksZ[0]);
                } else {
                    this.calcBlocks(this.aotvBlocksX[i], this.aotvBlocksY[i], this.aotvBlocksZ[i], this.aotvBlocksX[i + 1], this.aotvBlocksY[i + 1], this.aotvBlocksZ[i + 1]);
                }
            }
        } else {
            this.calcBlocks(this.aotvBlocksX[range], this.aotvBlocksY[range], this.aotvBlocksZ[range], this.aotvBlocksX[range + 1], this.aotvBlocksY[range + 1], this.aotvBlocksZ[range + 1]);
            this.calcBlocks(this.aotvBlocksX[range + 1], this.aotvBlocksY[range + 1], this.aotvBlocksZ[range + 1], this.aotvBlocksX[range + 2], this.aotvBlocksY[range + 2], this.aotvBlocksZ[range + 2])
        }

        this.requiredBlocks = new ArrayLists
        for(let i = 0; i < this.mineX.length; i++) {
            let block = World.getBlockAt(this.mineX[i], this.mineY[i], this.mineZ[i])
            let id = block.type.getID()
            if(id === 160.0 || (id === 95 && this.checkBig)) {
                this.requiredBlocks.add(toBlockPos(block))
            }
        }
        //ChatLib.chat(this.mineX.length)
    }

    rangeSphere(x1,y1,z1,x2,y2,z2) {
        let dx = x1 - x2
        let dy = y1 - y2
        let dz = z1 - z2
        let num = Math.sqrt((dx * dx) + (dy * dy) + (dz * dz))
        //ChatLib.chat(num)
        if(num < 4) {
            return true
        }
    }

    start() {
        this.previousBlock = undefined;
        this.miningGemstone = false;
        this.aotvBlocksX = [];
        this.aotvBlocksY = [];
        this.aotvBlocksZ = [];
        this.check = [];
        this.justBroken = [null,null,null,null,null,null,null];
        this.currentCord = 0
        this.mineX = [];
        this.mineY = [];
        this.mineZ = [];
        this.routeIndex = 0;
        this.cords = [[]]
        this.block = undefined;
        this.block1 = undefined;
        this.block2 = undefined;

        this.selectCords()
        this.makeArray()

        for(let i = 0; i < this.mineX.length; i++) {
            let block = World.getBlockAt(this.mineX[i], this.mineY[i], this.mineZ[i])
            for(let j = 0; j < this.cords.length; j++) {
                if(block.getX() === this.cords[j][0] && block.getY() === this.cords[j][1] && block.getZ() === this.cords[j][2]) {
                    this.currentCord = j
                    break
                }
            }
            if(!this.nukerBlocks.contains(block.type.getID())) {
                this.routeIndex += 1
            } else {
                if(this.routeIndex != 0) this.routeIndex -= 1
                break
            }
        }
    }

    routeColor( index ){
        for (var i = 0; i < this.aotvBlocksX.length; i++) {
            if (this.mineX[index] == this.aotvBlocksX[i] && this.mineY[index] == this.aotvBlocksY[i] + 1 && this.mineZ[index] == this.aotvBlocksZ[i]) {
                this.color[0] = 0;
                this.color[1] = 0;
                this.color[2] = 1;
                this.color[3] = 1;
    
                break;
            }
            else {
                this.color[0] = 1;
                this.color[1] = 0;
                this.color[2] = 0;
                this.color[3] = 1;
            }
        }
    }

    calcBlocks(x1, y1, z1, x2, y2, z2) {
        y1 = y1; //dumb 18 fucked up coordinates
        y2 = y2 ;
        this.mineX.push(Math.floor(x1));   
        this.mineY.push(Math.floor(y1));    
        this.mineZ.push(Math.floor(z1));    
        this.mineX.push(Math.floor(x1));   
        this.mineY.push(Math.floor(y1) + 1);    
        this.mineZ.push(Math.floor(z1));    
        this.mineX.push(Math.floor(x1));    
        this. mineY.push(Math.floor(y1) + 2);   
        this.mineZ.push(Math.floor(z1));        
        x1 = x1 + 0.5;
        //y1 = y1 + 0.5;
        y1 = y1 + 2.62 - 0.08; //shifting apparently lowers eye level by 3/32 block, needs testing. **should be fixed need more tests
        z1 = z1 + 0.5;    
        x2 = x2 + 0.5;
        y2 = y2 + 0.5; // either Y or Y + 0.5 depending on what 18's macro looks at. currently his macro looks at Y
        z2 = z2 + 0.5;
        var changeX = (x2 - x1) / 100; // if someone can find a better number based on math than this im all ears. I was just too lazy, 10k should be fine
        var changeY = (y2 - y1) / 100;
        var changeZ = (z2 - z1) / 100;
        var curX = x1;
        var curY = y1;
        var curZ = z1;
        var blockX = Math.floor(curX);
        var blockY = Math.floor(curY);
        var blockZ = Math.floor(curZ);
        for (var counter = 1; counter <= 100; counter++) {
            blockX = Math.floor(curX);
            blockY = Math.floor(curY);
            blockZ = Math.floor(curZ);
            curX += changeX;
            curY += changeY;
            curZ += changeZ;
            if (blockX != Math.floor(curX) || blockY != Math.floor(curY) || blockZ != Math.floor(curZ)) {
                //console.log(blockX + ', ' + blockY + ', ' + blockZ );
                this.mineX.push(blockX);
                this.mineY.push(blockY);
                this.mineZ.push(blockZ);
                this.mineX.push(blockX);
                this.mineY.push(blockY + 1);
                this.mineZ.push(blockZ);
                if (blockX != Math.floor(curX - 0.1)) {
                    this.mineX.push(blockX - 1);
                    this.mineY.push(blockY);
                    this.mineZ.push(blockZ);
                    this.mineX.push(blockX - 1);
                    this.mineY.push(blockY + 1);
                    this.mineZ.push(blockZ);
                }
                if (blockX != Math.floor(curX + 0.1)) {
                    this.mineX.push(blockX + 1);
                    this.mineY.push(blockY);
                    this.mineZ.push(blockZ);
                    this.mineX.push(blockX + 1);
                    this.mineY.push(blockY + 1);
                    this.mineZ.push(blockZ);
                }
                if (blockY != Math.floor(curY - 0.1)) {
                    this.mineX.push(blockX);
                    this.mineY.push(blockY - 1);
                    this.mineZ.push(blockZ);
                    this.mineX.push(blockX);
                    this.mineY.push(blockY);
                    this.mineZ.push(blockZ);
                }
                if (blockY != Math.floor(curY + 0.1)) {
                    this.mineX.push(blockX);
                    this.mineY.push(blockY + 1);
                    this.mineZ.push(blockZ);
                    this.mineX.push(blockX);
                    this.mineY.push(blockY + 2);
                    this.mineZ.push(blockZ);
                }
                if (blockZ != Math.floor(curZ - 0.1)) {
                    this.mineX.push(blockX);
                    this.mineY.push(blockY);
                    this.mineZ.push(blockZ - 1);
                    this.mineX.push(blockX);
                    this.mineY.push(blockY + 1);
                    this.mineZ.push(blockZ - 1);
                }
                if (blockZ != Math.floor(curZ + 0.1)) {
                    this.mineX.push(blockX);
                    this.mineY.push(blockY);
                    this.mineZ.push(blockZ + 1);
                    this.mineX.push(blockX);
                    this.mineY.push(blockY + 1);
                    this.mineZ.push(blockZ + 1);
                }
                //console.log(coordsJ.length);
            }
    
        }
    }
}

global.exports.route = new routeNuker()