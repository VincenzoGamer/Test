import Skyblock from "BloomCore/Skyblock";
let { SettingSelector, SettingSlider, SettingToggle, ConfigModuleClass, ModuleToggle, getKeyBind, ModuleManager } = global.settingSelection
let { MathUtils, ChatUtils, Utils, TimeHelper, Rotations, MovementHelper, MouseUtils } = global.export

class AntiAfk {
    constructor() {
        this.Enabled = false;
        getKeyBind("Anti Afk", "Polar Client - Misc").registerKeyPress(() => this.toggle());
        this.LOCATIONS = {
            ISLAND: 0,
            SKYBLOCK: 1,
            MAINLOBBY: 2,
            LIMBO: 3
        }
        this.location;
        this.counter = 0;
        this.maxTime = 150;
        this.warp = false;
        this.timerLook = new TimeHelper()
        this.timerMove = new TimeHelper()
        register("tick", () => {
            if(!this.Enabled) return;
            this.counter++;
            switch(this.location) {
                case this.LOCATIONS.ISLAND:
                    if(this.timerLook.reachedRandom()) {
                        let pitch = Player.getPitch();
                        let change = Math.abs(-2 + Math.random() * 3);
                        if(pitch > 40) pitch -= change;
                        else if(pitch < 20) pitch += change;
                        Rotations.rotateToAngles(Player.getYaw() + (-2 + Math.random() * 3), pitch);
                        this.timerLook.reset();
                        this.timerLook.setRandomReached(30000, 60000);
                    }
                    if(this.timerMove.reachedRandom()) {
                        MovementHelper.setKeysForStraightLine(MathUtils.calculateAngles(Utils.convertToVector([Player.getX() + (-1 + Math.random() * 2), Player.getY(), Player.getZ() + (-1 + Math.random() * 2)])).yaw, false);
                        Client.scheduleTask(1 + Math.round(Math.random()), () => MovementHelper.stopMovement());
                        this.timerMove.reset();
                        this.timerMove.setRandomReached(30000, 60000);
                    }
                    break;
                case this.LOCATIONS.SKYBLOCK:
                    if(this.counter === this.maxTime) {
                        ChatLib.say("/warp island");
                        this.timerMove.reset();
                        this.timerLook.reset();
                    }
                    break;
                case this.LOCATIONS.MAINLOBBY:
                    if(this.counter === this.maxTime) ChatLib.say("/skyblock");
                    break;
                case this.LOCATIONS.LIMBO:
                    if(this.counter === this.maxTime) ChatLib.say("/lobby");
                    break;
            }
        })

        register("step", () => {
            let previous = this.location;
            this.location = this.getLocation();
            if(this.location != previous) {
                this.counter = 0;
                MovementHelper.stopMovement();
                Rotations.stopRotate();
                return;
            }
        }).setDelay(1)
    }

    toggle() {
        this.Enabled = !this.Enabled;
        ChatUtils.sendModMessage("Anti Afk: " + (this.Enabled ? "&aEnabled" : "&cDisabled"))
        this.Enabled ? MouseUtils.unGrabMouse() : MouseUtils.reGrabMouse();
        this.counter = 0;
        this.timerLook.setRandomReached(30000, 60000);
        this.timerMove.setRandomReached(30000, 60000);
    }

    getLocation() {
        return Skyblock.inSkyblock ? (Skyblock.area === "Private Island" ? this.LOCATIONS.ISLAND : this.LOCATIONS.SKYBLOCK) : (MathUtils.getDistanceToPlayer(-23.5, 31.0, 21.5).distance < 4.0 ? this.LOCATIONS.LIMBO : this.LOCATIONS.MAINLOBBY);
    }
}

new AntiAfk();