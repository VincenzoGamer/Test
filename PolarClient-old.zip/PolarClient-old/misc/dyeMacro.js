/* @ Plus @ */
let { PolarPathFinder, MovementHelper, Rotations, ChatUtils, MathUtils, RenderUtils, Utils } = global.export;

class DyeMacro {
    constructor() {
        this.ModuleName = "Nyanza Dye Macro"
        this.Enabled = false;
        this.render = false;

        register("command", () => {
            this.toggle();
        }).setName("konamidirepenis");

        register("command", () => {
            this.render = !this.render;
        }).setName("renderdirepenis")

        this.current = {pos: [], index: 0};
        this.route = [[272,189,650], [242,189,657], [261,189,662], [274,201,676]];

        register("renderWorld", () => {
            if(!this.render) return;
            RenderUtils.renderCordsWithNumbers(this.route);
        })

        register("tick", () => {
            if(!this.Enabled) return;
            if(MathUtils.getDistanceToPlayer(this.current.pos).distance < 4.0) {
                let nextIndex = this.current.index + 1;
                if(nextIndex === this.route.length) nextIndex = 0;
                this.current = {pos: Utils.convertToVector(this.route[nextIndex]).getBlockPos(), index: nextIndex }
                PolarPathFinder.findPath(Utils.getPlayerNode().getBlockPos(), this.current.pos);
            }
            if(!PolarPathFinder.currentNode) return this.stopMacro("Could find a path to the next waypoint?", true);
            let lookVec = Utils.convertToVector(PolarPathFinder.currentNode.lookPoint)
            let angleYaw = MathUtils.calculateAngles(lookVec).yaw;
            if(Math.abs(angleYaw) < 90) MovementHelper.setKeysForStraightLine(angleYaw);
            else MovementHelper.stopMovement();
            Rotations.rotateTo(lookVec, 2.0, true, 11.9);
        })
    }

    toggle() {
        this.Enabled = !this.Enabled;
        this.sendMacroMessage(this.Enabled ? "&aEnabled": "&cDisabled");
        if(this.Enabled) {
            let object = this.getClosest();
            this.current = {pos: object.c, index: object.i};
            PolarPathFinder.findPath(Utils.getPlayerNode().getBlockPos(), this.current.pos);
        }
        if(!this.Enabled) {
            this.stopMacro();
        }
    }

    getClosest() {
        let closest = null;
        let lowest;
        let lowestIndex;
        this.route.forEach((point, index) => {
            let distance = MathUtils.getDistanceToPlayer(point).distance;
            if(!closest || distance < lowest) {
                lowest = distance;
                lowestIndex = index;
                closest = point;
            }
        })
        return {c: Utils.convertToVector(closest).getBlockPos(), i: lowestIndex};
    }

    stopMacro(msg=null, disableMessage=false) {
        if(msg) this.sendMacroMessage(msg);
        if(disableMessage) this.sendMacroMessage("&cDisabled");
        this.Enabled = false;
        MovementHelper.stopMovement();
        Rotations.stopRotate();
    }

    sendMacroMessage(msg) {
        ChatUtils.sendModMessage(this.ModuleName + ": " + msg);
    }
}

new DyeMacro();