const configRender = new global.configModuleClass(
    "Route Rendering",
    "Misc",
    false,
    [
        new global.settingToggle("Gemstone Macro Route", true),
        new global.settingToggle("Foraging Macro Route", true)
    ],
    [
        "&bRoute Rendering",
        "Controlles all the Rendering of all Macro's"
    ]
)

global.modules.push(configRender)