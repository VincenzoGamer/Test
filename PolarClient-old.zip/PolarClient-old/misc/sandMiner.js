import RenderLib from "RenderLib";
import Skyblock from "BloomCore/Skyblock";
let { disFrToFr, disToPly } = global.exports
let { lookAt, lookAtHoriSet } = global.exports
let { ArrayLists, C07PacketPlayerDigging, EnumFacing, LeftClick, Sprint, WalkForward, mc, polarPrefix, sendPacket } = global.exports
let { degreeRannge, rotaPitchRange } = global.exports
let { toBlockPos, toPosBlock, finder, keyBind} = global.exports

const configSandMiner = new global.configModuleClass(
    "Sand Miner",
    "Misc",
    false,
    [
        new global.settingToggle("40bps sand Mining", false),
        new global.settingToggle("Sprinting while macroing", true)
    ],
    [
        "&bSand Miner",
        "Mines sand on the Farming Island's, makes 5mil an hour with a 2mil setup",
        "Requirements: Shovle, God Potion"
    ]
)

global.modules.push(configSandMiner)

class sandMinerClass {
    constructor() {
        this.toggle = false
        this.current = 0
        this.cooldown = new ArrayLists
        this.cords = [[184,76,-399],[190,76,-389],[193,76,-377],[195,76,-363],[198,76,-353],[204,76,-348],[212,76,-352],[209,76,-360],[207,76,-370],[209,76,-376],[215,76,-381],[214,76,-389],[205,76,-399],[192,76,-401]]

        keyBind.keyBindSandMiner.registerKeyPress(() => {this.toggleMacro()})

        register("renderWorld", () => {
            if(Skyblock.area == "The Farming Islands" && !this.toggle) {
                // for(let i = 0; i < this.cords.length; i++) {
                //     Tessellator.drawString(i + 1, this.cords[i][0] + 0.5, this.cords[i][1] + 0.5, this.cords[i][2] + 0.5)
                //     RenderLib.drawInnerEspBox(this.cords[i][0] + 0.5, this.cords[i][1], this.cords[i][2] + 0.5, 1, 1, 0, 1, 0, 0.2, true)
                // }
                Tessellator.drawString("Sand Macro Location", 201.5, 77, -375.5)
                RenderLib.drawInnerEspBox(201.5, 76, -375.5, 1, 1, 0, 1, 0, 0.2, true)
            }

            // if(this.previous != undefined) {
            //     let block = toPosBlock(this.previous)
            //     RenderLib.drawInnerEspBox(block.getX() + 0.5, block.getY(), block.getZ() + 0.5, 1, 1, 0, 0, 1, 0.3, true)
            // }
        })

        register("worldLoad", () => {
            if(this.toggle) {
                ChatLib.chat(polarPrefix + " Disabled Sand")
                this.toggleMacro()
            }
        })

        register("tick", () => {
            if(this.toggle) {

                //if(this.previous != undefined) {
                    //ChatLib.chat("STOP")
                    //sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.previous, EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
                    //this.cooldown.add(this.previous)
                    //this.previous = undefined
                    while(this.cooldown.size() > 10) {
                        this.cooldown.remove(0)
                    }
                //}

                //if(this.previous === undefined) {

                    mc.field_71439_g.func_71038_i()
                    this.nukeBlock()
                    if(this.morebps) {
                        this.nukeBlock()
                    }
                    //this.nukeBlock()
                //}

                if(this.getDisToNearest() < 4) {
                    if(this.current == (this.cords.length - 1)) {
                        this.current = 0
                    } else {
                        this.current += 1
                    }
                }
            }
        })

        register("step", () => {
            if(this.toggle) {
                WalkForward.setState(true)
                if(this.sprinting) {
                    Sprint.setState(true)
                } else {
                    Sprint.setState(false)
                }
                lookAtHoriSet(this.cords[this.current][0], this.cords[this.current][1] - 1, this.cords[this.current][2], 100, 27)
            }
        }).setFps(10)
    }

    toggleMacro() {
        this.toggle = !this.toggle
        if(this.toggle) {
            if(Skyblock.area === "The Farming Islands" && disFrToFr(201.5, 77, -375.5, Player.getX(), Player.getY(), Player.getZ()) < 20 && finder.shovel()) {
                ChatLib.chat(polarPrefix + " Sand Miner: " + this.toggle)
                Player.setHeldItemIndex(finder.slotShovel)
                this.morebps = global.exports.settingGet.getSetting("Sand Miner","40bps sand Mining") 
                this.sprinting = global.exports.settingGet.getSetting("Sand Miner","Sprinting while macroing")
                this.previous = undefined
                this.getNearest()
            } else {
                
                this.toggle = false
                if(Skyblock.area != "The Farming Islands") {
                    ChatLib.chat(polarPrefix + " Be in the Farming island's")
                    return
                }
                if(disFrToFr(201.5, 77, -375.5, Player.getX(), Player.getY(), Player.getZ()) > 20) ChatLib.chat(polarPrefix + " Not on the Farming Islands or Not in range")
                if(!finder.shovel()) ChatLib.chat(polarPrefix + " Missing Shovel")
            }
        } else {
            ChatLib.chat(polarPrefix + " Sand Miner: " + this.toggle)
            WalkForward.setState(false)
            LeftClick.setState(false)

            // if(this.previous != undefined) {
            //     //ChatLib.chat("STOP")
            //     sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.previous, EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
            // }
            this.previous = undefined
        }
    }

    nukeBlock() {
        this.callCords()
        let blocks = []
        for (let x = -6; x <= 6; x++) {
            for (let y = -1; y < 0; y++) {
                for (let z = -6; z <= 6; z++) {
                    let block = World.getBlockAt(this.plyX + x, this.plyY + y, this.plyZ + z)
                    if(block.type.getID() === 12 && disToPly(this.plyX + x + 0.5, this.plyY + y + 0.5, this.plyZ + z + 0.5) < 4.5 && !this.cooldown.contains(toBlockPos(block))) {
                        blocks.push(block)
                    }
                }
            }
        }

        let closest = undefined
        for(let i = 0; i < blocks.length; i++) {
            if(closest === undefined) {
                closest = blocks[i]
            } else {
                let blocksLengthDegree = degreeRannge(blocks[i].getX() + 0.5, blocks[i].getY() + 1, blocks[i].getZ() + 0.5)
                let closestBlockLengthDegree = degreeRannge(closest.getX() + 0.5, closest.getY() + 1, closest.getZ() + 0.5)
                let blocksLengthRota = rotaPitchRange(blocks[i].getX() + 0.5, blocks[i].getY() + 1, blocks[i].getZ() + 0.5)
                let closestBlockLengthRota = rotaPitchRange(closest.getX() + 0.5, closest.getY() + 1, closest.getZ() + 0.5)
                if(Math.sqrt(blocksLengthDegree*blocksLengthDegree + blocksLengthRota*blocksLengthRota) < Math.sqrt(closestBlockLengthDegree*closestBlockLengthDegree + closestBlockLengthRota*closestBlockLengthRota)) {
                    closest = blocks[i]
                }   
            }
        }

        if(closest != undefined) {
            //ChatLib.chat("START")
            // ChatLib.chat(toBlockPos(closest))
            sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, toBlockPos(closest), EnumFacing.func_176733_a(Client.getMinecraft().field_71439_g.field_70177_z)))
            this.previous = toBlockPos(closest)
            this.cooldown.add(this.previous)
        }
    }

    getNearest() {
        this.callCords()
        this.current = this.closest(this.cords, true)
    }

    callCords() {
        this.plyX = Math.floor(Player.getX())
        this.plyY = Math.floor(Player.getY())
        this.plyZ = Math.floor(Player.getZ())
    }

    getDisToNearest() {
        this.callCords()
        return disFrToFr(this.plyX, this.plyY, this.plyZ, this.cords[this.current][0], this.cords[this.current][1], this.cords[this.current][2])
    }

    closest(array, index) {
        let closest = undefined
        let num = undefined
        for(let i = 0; i < array.length; i++) {
            if(closest === undefined) {
                closest = array[i]
                num = i
            } else if(disToPly(closest[0], closest[1], closest[2]) > disToPly(array[i][0], array[i][1], array[i][2])) {
                closest = array[i]
                num = i
            }
        }
        if(index) {
            return num
        } else {
            return closest
        }
    }
}

global.exports.sandMiner = new sandMinerClass()