/* @ Exclude @ */

/*
let { SettingSelector, SettingSlider, SettingToggle, ConfigModuleClass, ModuleToggle, getKeyBind, ModuleManager } = global.settingSelection

let { ChatUtils, Vector, MovementHelper } = global.export

global.modules.push(
    new ConfigModuleClass(
        "Freecam",
        "Render",
        [
            new SettingSlider("Speed", 1, 0, 8)
        ],
        [
            "Nyooooom"
        ]
    )
)

class freecam {
    constructor() {
        this.ModuleName = "Freecam"
        this.enabled = false

        getKeyBind(this.ModuleName, "Polar Client - Render").registerKeyPress(() => {
            this.enabled = !this.enabled

            if (this.enabled) {
                this.sendMacroMessage(`§9Enabled`)
                this.lastPos = new Vector(Player.getX(), Player.getY(), Player.getZ())
                this.lastMotion = new Vector(Player.getMotionX(), Player.getMotionY(), Player.getMotionZ())
                this.lastRotation = { yaw: Player.getRawYaw(), pitch: Player.getPitch() }
                this.lastSprint = Player.isSprinting()
            }
            else {
                this.sendMacroMessage("§cDisabled")

                // Position
                Player.getPlayer().func_70107_b(this.lastPos.x, this.lastPos.y, this.lastPos.z)
                // Motion
                Player.getPlayer().field_70159_w = this.lastMotion.x
                Player.getPlayer().field_70181_x = this.lastMotion.y
                Player.getPlayer().field_70179_y = this.lastMotion.z
                // Rotation
                Player.getPlayer().field_70177_z = this.lastRotation.yaw
                Player.getPlayer().field_70125_A = this.lastRotation.pitch
                // Sprint
                MovementHelper.setKey("sprint", this.lastSprint)
            }
        })

        // Settings
        this.speed = ModuleManager.getSetting(this.ModuleName, "Speed")
        register("step", () => {
            this.speed = ModuleManager.getSetting(this.ModuleName, "Speed")
        }).setFps(5)

        register("tick", () => {
            if (!this.enabled) return

            const mult = Player.getPlayer().field_71158_b.field_78900_b !== 0 && Player.getPlayer().field_71158_b.field_78902_a !== 0 ? this.speed * 0.98 : this.speed
            Player.getPlayer().field_70159_w *= mult
            Player.getPlayer().field_70179_y *= mult
        })

        register("worldUnload", () => this.enabled = false)

        register("packetSent", (packet, event) => {
            if (this.enabled) cancel(event)
        }).setFilteredClasses([
            net.minecraft.network.play.client.C03PacketPlayer.class,
            net.minecraft.network.play.client.C0APacketAnimation.class,
            net.minecraft.network.play.client.C02PacketUseEntity.class,
            net.minecraft.network.play.client.C0BPacketEntityAction.class,
            net.minecraft.network.play.client.C08PacketPlayerBlockPlacement.class
        ])
    }

    sendMacroMessage(msg) {
        ChatUtils.sendModMessage(this.ModuleName + ": " + msg)
    }
}

new freecam()
*/