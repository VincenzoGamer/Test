let { Utils, S2FPacketSetSlot, S30PacketWindowItems } = global.export
/**
 * I will add other values as well, since it is a pretty neat class
 */
class skyblockUtils {
    constructor() {
        Utils.registerChat((msg, type) => {
            this.checkEvents(msg, type);
        })

        this.triggers = [];

        register("command", (x) => {
            this.triggers.forEach(trigger => {
                if(trigger[0].toLowerCase() === x.toString().toLowerCase()) trigger[1]();
            })
        }).setName("triggerevent")
    }

    register=(triggertype, func) => this.triggers.push([triggertype, func]);

    /**
     * @param {String} msg 
     */
    checkEvents(msg, type) {
        let triggertype = "";
        if(type == "0") {
            if(msg.startsWith(" ☠ You")) triggertype = "death";
            else if(msg.startsWith("This ability is on cooldown for")) triggertype = "boostcooldown";
            else if(msg.startsWith("You can't use this while") || msg.startsWith("You can't fast travel while")) triggertype = "incombat";
            else if(msg.startsWith("Oh no! Your")) triggertype = "pickonimbusbroke";
            else if(msg.startsWith("You uncovered a treasure")) triggertype = "chestspawn";
            else if(msg.startsWith("You have successfully picked")) triggertype = "chestsolve";
            else if(msg.startsWith("Inventory full?")) triggertype = "fullinventory";
            else if(msg.toString().includes("Mining Speed Boost is now available!")) triggertype = "boostready";
            else if(msg.includes("You used your Mining Speed Boost Pickaxe Ability!")) triggertype = "boostused";
            else if(msg.includes("Your Mining Speed Boost has expired!")) triggertype = "boostgone";
            else if(!msg.startsWith("[") && msg.includes(" Commission Complete! ")) triggertype = "commissiondone";
            //else if(!msg.startsWith("[") && (msg.includes("is empty! Refuel it by talking to a Drill Mechanic!") || msg.includes("has too little fuel to keep"))) triggertype = "emptydrill";
        }
        if(type == "2") {
            for(let i = 0; i <= 200; i++) {
                let word = msg.charAt(i) + msg.charAt(i + 1);
                if(word != "Dr") continue;
                let fuel = "";
                for(let j = -14; j <= 0; j++) {
                    let letter = msg.charAt(i + j)?.removeFormatting();
                    if(letter === "," || letter === " ") continue;
                    if(letter === "/" || letter === undefined) break;
                    fuel += letter;
                }
                if(parseInt(fuel.removeFormatting()) < 100) triggertype = "emptydrill";
                break;
            }
        }
        this.triggers.forEach(trigger => {
            if(trigger[0].toLowerCase() === triggertype) trigger[1]();
        })
    }
}

global.export.SkyblockUtils = new skyblockUtils();