let { RenderUtils, MathUtils, MovementHelper, Rotations, Vec3, TimeHelper, Utils } = global.export

class polarPathFinder {
    constructor() {
        this.PathFinder = Java.type("com.polar.wrapper.pathfinder.PathFinder");
        this.NodeData = Java.type("com.polar.wrapper.pathfinder.NodeData");
        this.Node = Java.type("com.polar.wrapper.pathfinder.Node");
        this.BP = Java.type("net.minecraft.util.BlockPos");
        this.Double = Java.type("java.lang.Double");
        this.Boolean = Java.type("java.lang.Boolean");

        this.path = [];
        this.points = [];
        this.currentNode = null;
        this.previousNumber = null;
        this.changeNumber = 0;
        this.changeIndex = 0;
        this.nodeTimer = new TimeHelper();
        this.disFlat = 1.0;
        this.dis = 4.0;

        register("renderWorld", () => {
            if(this.points.length != 0.0) RenderUtils.renderPathfindingLines(this.points);
        })

        register("tick", () => {
            if(!this.currentNode) return;
            this.currentNode = this.choseLookPoint(this.currentNode);
            let nextNode = this.path[this.currentNode.number + 1];
            if(this.currentNode != undefined) {
                let rangeNode = MathUtils.getDistanceToPlayer(this.currentNode.point)
                if(rangeNode.distance <= this.dis && rangeNode.distanceFlat <= this.disFlat) {
                    this.currentNode = this.choseLookPoint(nextNode);
                    this.nodeTimer.reset();
                }
            } else {
                this.currentNode = null;
            }
        })
    }

    convertToArray(nodes) {
        let array = []
        nodes.forEach((node) => {
           array.push([node.x - 0.5, node.y, node.z - 0.5]);
        })
        return array
    }

    findStartNode() {
        let closest = null
        let lowest;
        this.path.forEach((node) => {
            let range = MathUtils.getDistanceToPlayer(node.point);
            if(!closest || range.distance < lowest) {
                closest = node;
                lowest = range.distance;
            }
        })
        this.currentNode = this.choseLookPoint(closest);
        this.nodeTimer.reset();
        this.previousNumber = closest.number;
    }

    /**
     * @param {Node} node 
     */
    choseLookPoint(node) {
        if(!node || node === undefined) return node
        node.lookPoint = [node.x, node.y + 1.75, node.z];
        let next1Node = this.path[node.number + 1];
        let next2Node = this.path[node.number + 2];
        if(next1Node != undefined) {
            if(!World.getWorld().func_72933_a(Player.asPlayerMP().getEyePosition(1), new Vec3(next1Node.x, next1Node.y + 2.9, next1Node.z))) {
                if(next2Node === undefined) node.lookPoint = [next1Node.x, next1Node.y + 1.75, next1Node.z];
                else if(World.getWorld().func_72933_a(Player.asPlayerMP().getEyePosition(1), new Vec3(next2Node.x, next2Node.y + 2.94, next2Node.z))) node.lookPoint = [next1Node.x, next1Node.y + 1.75, next1Node.z];
                else node.lookPoint = [next2Node.x, next2Node.y + 1.75, next2Node.z];
            }
        }
        return node
    }

    reachedEnd() {
        return this.currentNode.number + 1 >= this.path.length
    }

    getCurrentNode() {
        return this.currentNode;
    }

    timePassedSinceNodeChange() {
        return this.nodeTimer.getTimePassed();
    }

    clearPath() {
        this.path = [];
        this.points = [];
        this.currentNode = null;
        this.changeNumber = -1;
        this.changeIndex = 0;
    }

    /**
     * @param {BlockPos} start 
     * @param {BlockPos} end 
     */
    findPath(start, end, customs=[], etherwarp=false) {
        this.clearPath();
        if(start === null || end === null) return false; 
        let startData = new this.NodeData(start.toMCBlock(), new this.Double(2.0), new this.Boolean(false));
        let endData = new this.NodeData(end.toMCBlock(), new this.Double(2.0), new this.Boolean(false));
        let pathFinder = this.addCustoms(new this.PathFinder(startData, endData), customs, etherwarp);
        this.path = this.convertToNodeArray(pathFinder.calculatePath());
        if(this.path.length === 0.0) {
            this.path = []
            return false;
        }
        this.path.push(new Node(new this.Node(endData, new this.Double(2.0), new this.Double(2.0), null), this.path.length, false))
        this.findStartNode();
        this.points = this.convertToArray(this.path);
        return true;
    }

    convertToNodeArray(nodes) {
        let array = []
        if(!nodes) return array;
        nodes.forEach((node, index) => {
            if(node.data.isCustomNode) {
                array.push(new Node(node, index, true));
            }
            array.push(new Node(node, index, false));
        })
        return array
    }

    addCustoms(finder, array, etherwarp) {
        for(let i = 0; i < array.length/2; i++) {
            finder.addCustomMarker(array[i*2].toMCBlock(), array[(i*2) + 1].toMCBlock());
            if(etherwarp) finder.addCustomMarker(array[(i*2) + 1].toMCBlock(), array[i*2].toMCBlock());
        }
        return finder;
    }
}

class Node {
    constructor(node, number, parent) {
        const access = parent ? "parent" : "pos";
        this.x = node.data[access].func_177958_n() + 0.5;
        this.y = node.data[access].func_177956_o();
        this.z = node.data[access].func_177952_p() + 0.5;
        this.point = [this.x, this.y, this.z];
        this.pos = new BlockPos(node.data[access]);
        this.node = node;
        this.number = number;
        this.lookPoint;
    }

    setLookPoint(point) {
        this.lookPoint = point;
    }
}

global.export.PolarPathFinder = new polarPathFinder()