global.exports.disToPly = (x,y,z) => {
    let dX = Player.getX() - x
    let dZ = Player.getZ() - z
    let dY = Player.getY() + 1.6 - y
    let dis = Math.sqrt((dX * dX) + (dZ * dZ))
    let dis2 = Math.sqrt((dis * dis) + (dY * dY))
    return dis2
}

global.exports.disToPlyFlat = (x,z) => {
    let dX = Player.getX() - x
    let dZ = Player.getZ() - z
    let dis = Math.sqrt((dX * dX) + (dZ * dZ))
    return dis
}

global.exports.disToPlyY = (y) => {
    let dY = Player.getY() - y
    let dis = Math.sqrt((dY * dY))
    return dis
}

global.exports.disFrToFr = (x,y,z,x1,y1,z1) => {
    let dX = x1 - x
    let dZ = z1 - z
    let dY = y1 - y
    let dis = Math.sqrt((dX * dX) + (dZ * dZ))
    let dis2 = Math.sqrt((dis * dis) + (dY * dY))
    return dis2
}

global.exports.disFrToFrFlat = (x,z,x1,z1) => {
    let dX = x1 - x
    let dZ = z1 - z
    let dis = Math.sqrt((dX * dX) + (dZ * dZ))
    return dis
}


global.exports.disFrToFrY = (y1,y2) => {
    let dY = y1 - y2
    return Math.sqrt((dY * dY))
}