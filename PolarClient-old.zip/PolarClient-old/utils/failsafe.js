let { disToPly, disToPlyY } = global.exports
let { lookAt, lookAt2 } = global.exports
let { polarPrefix, Shift, toggle, WalkForward } = global.exports
let { toBlockPos } = global.exports
let { getPointsOnBlock } = global.exports
let { autoMine }  = global.exports
let { finder }  = global.exports

let mc = Client.getMinecraft()
let LClick = mc.getClass().getDeclaredMethod("func_147116_af")
LClick.setAccessible(true)

class failsafe {
    constructor() {
        this.toggle = false
        this.cooldown = 0
        this.targetPlayer = undefined
        this.point = []
        this.first = false

        register("WorldLoad", () => {
            this.cooldown = 0
        })

        register("Tick", () => {
            if(this.toggle) {
                this.cooldown += 1
                if(this.cooldown === 1) {
                    this.cords = World.getBlockAt(Math.floor(Player.getX()), Math.floor(Player.getY() - 1), Math.floor(Player.getZ()))
                    this.nearestPlayer()
                    if(this.targetPlayer != undefined) {
                        lookAt(this.targetPlayer.getX(), this.targetPlayer.getY() + 1.6, this.targetPlayer.getZ(), 300, false, false)
                    }
                }
                else if(this.cooldown === 7.0) {
                    this.nearestPlayer()
                    if(this.targetPlayer != undefined) {
                        lookAt(this.targetPlayer.getX(), this.targetPlayer.getY() + 1.7, this.targetPlayer.getZ(), 300, false, false)
                    }
                }
                else if(this.cooldown < 10.0) {
                    Shift.setState(true)
                }
                else if(this.cooldown < 13) {
                    Shift.setState(false)
                }
                else if(this.cooldown < 16.0) {
                    Shift.setState(true)
                }
                else if(this.cooldown < 19) {
                    Shift.setState(false)
                }
                else if(this.cooldown === 20) {
                    this.nearestPlayer()
                    if(this.targetPlayer != undefined) {
                        lookAt(this.targetPlayer.getX(), this.targetPlayer.getY() + 1.4, this.targetPlayer.getZ(), 100, false, false)
                    }
                }
                else if(this.cooldown < 26) {
                    LClick.invoke(mc)
                } 
                else if(this.cooldown === 27) {
                    this.nearestPlayer()
                    if(this.targetPlayer != undefined) {
                        lookAt(this.targetPlayer.getX(), this.targetPlayer.getY() + 1.3, this.targetPlayer.getZ(), 100, false, false)
                    }
                }
                else if(this.cooldown < 32) {
                    LClick.invoke(mc)
                }
                else if(this.cooldown === 36) {
                    this.nearestPlayer()
                    if(this.targetPlayer != undefined) {
                        lookAt(this.targetPlayer.getX(), this.targetPlayer.getY() + 1.6, this.targetPlayer.getZ(), 100, false, false)
                    }
                }
                else if(this.cooldown === 40) {
                    WalkForward.setState(true)
                    Shift.setState(true)
                }
                else if(this.cooldown === 45) {
                    WalkForward.setState(false)
                }
                else if(this.cooldown === 54) {
                    Shift.setState(false)
                }
                else if(this.cooldown === 61) {
                    ChatLib.say("go away please")
                }
                else if(this.cooldown === 73) {
                    finder.etherwarp()
                    Player.setHeldItemIndex(finder.slotWarp)
                    let pos = toBlockPos(this.cords)
                    this.rayTrace(pos)
                    let point = this.gPoint
                    lookAt(point.field_72450_a, point.field_72448_b, point.field_72449_c, 300, true, true)
                }
                else if(this.cooldown === 90) {
                    this.toggleMacro()

                    if(toggle.mithrilMacro || toggle.commisionMacro) {
                        autoMine.toggleMacro()
                    }
                }
            }
        })

        register("Command", () => {
            this.toggleMacro()
        }).setName("fail")
    }

    toggleMacro() {
        this.toggle = !this.toggle
        if(this.toggle) {
            ChatLib.chat(polarPrefix + " Started the failsafe")
        } else {
            this.cooldown = 0
            ChatLib.chat(polarPrefix + " Stopped the failsafe")
        }
    }


    nearestPlayer() {
        let players = World.getAllPlayers()
        let closest = undefined
        for(let i = 0; i < players.length; i++) {
            if(players[i].getName() != Player.getName() && disToPlyY(players[i].getY()) < 4) {
                if(closest === undefined) {
                    closest = players[i]
                }
                if(disToPly(closest.getX(), closest.getY(), closest.getZ()) > disToPly(players[i].getX(), players[i].getY(), players[i].getZ())) {
                    closest = players[i]
                }
        }
        }
        this.targetPlayer = closest
    }

    rayTrace(pos) {
        let found = false
        getPointsOnBlock(pos).forEach(point => {
            if(!found) {
                let rayTraceResult = World.getWorld().func_72933_a(Player.getPlayer().func_174824_e(1), point)
                if(rayTraceResult != null) {
                    if(rayTraceResult && rayTraceResult.func_178782_a().equals(pos)) {
                        this.gPoint = point
                        found = true
                    }
                }
            }
            })
            return found
        }
}

global.exports.failSafe = new failsafe()