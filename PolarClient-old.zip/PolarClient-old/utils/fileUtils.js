class fileUtils {
    constructor() {
        this.files = [
            "gemstonecustomcords.json"
        ]
        this.createFiles(this.files)

        this.updateGemstone()
    }

    createFiles(files) {
        files.forEach(file => {
            if(!FileLib.exists("PolarConfig", file)) {
                if(file === "gemstonecustomcords.json") {
                    FileLib.append("PolarConfig",file,'{\n"custom1": [],\n"custom1type": "none",\n"custom2": [],\n"custom2type": "none",\n"custom3": [],\n"custom3type": "none",\n"custom4": [],\n"custom4type": "none",\n"custom5": [],\n"custom5type": "none"\n}')
                    this.updateGemstone()
                }
            }
        })
    }

    updateGemstone() {
        var cordsjson = FileLib.read("PolarConfig", "gemstonecustomcords.json");
        this.gemstonecords = JSON.parse(cordsjson)
    }

    writeGemstone(data) {
        let json = JSON.stringify(data, null, 2);
        FileLib.write("PolarConfig", "gemstonecustomcords.json", json);
    }
}

global.exports.fileUtils = new fileUtils()