class itemFinder {
    constructor() {
        this.slotBlueCheese = false
    }
    drill() {
        this.bluecheese()
        this.slotDrill = this.goThruInv(["Drill","Gemstone Gauntlet","Pickonimbus 2000","Titanium Pickaxe","Mithril Pickaxe"], false, true)
        return this.goThruInv(["Drill","Gemstone Gauntlet","Pickonimbus 2000","Titanium Pickaxe"], false, false)
    }

    shovel() {
        this.slotShovel = this.goThruInv(["Shovel"], false, true)
        return this.goThruInv(["Shovel"], false, false)
    }

    range() {
        this.slotRange = this.goThruInv(["Frozen Scythe", "Juju Shortbow", "Terminator", "Spirit Sceptre", "Spirit Bow","Aurora Staff"], false, true)
        return this.goThruInv(["Frozen Scythe", "Juju Shortbow", "Terminator", "Spirit Sceptre", "Spirit Bow","Aurora Staff"], false, false)
    }

    fireveil() {
        this.slotFireVeil = this.goThruInv(["Fire Veil Wand"], false, true)
        return this.goThruInv(["Fire Veil Wand"], false, false)
    }

    hyperion() {
        this.slotHyperion = this.goThruInv(["Wither Impact"], true, true)
        return p = this.goThruInv(["Wither Impact"], true, false)
    }

    etherwarp() {
        this.slotWarp = this.goThruInv(["Ether Transmission"], true, true)
        return this.goThruInv(["Ether Transmission"], true, false)
    }

    pickaxe() {
        this.slotPickaxe = this.goThruInv(["Pickaxe","2000"], false, true)
        return this.goThruInv(["Pickaxe","2000"], false, false)
    }

    pidgeon() {
        this.slotPidgeon = this.goThruInv(["Pigeon"], false, true)
        return this.goThruInv(["Royal Pigeon"], false, false)
    }

    bluecheese() {
        this.slotBlueCheese = undefined
        this.slotBlueCheese = this.goThruInv(["Blue Cheese"], true, true)
        return this.goThruInv(["Blue Cheese"], true, false)
    }

    healingWand() {
        this.slotHealingWand = this.goThruInv(["Wand"], false, true)
        return this.goThruInv(["Wand"], false, false)
    }

    soulWhip() {
        this.slotSoulWhip = this.goThruInv(["Soul Whip"], false, true)
        return this.goThruInv(["Soul Whip"], false, false)
    }

    axe() {
        this.slotAxe = this.goThruInv(["Axe","Treecapitator"], false, true)
        return this.goThruInv(["Axe","Treecapitator"], false, false)
    }

    swordOfBadHealth() {
        this.slotSwordOfBadHealth = this.goThruInv(["Sword of Bad Health"], false, true)
        return this.goThruInv(["Sword of Bad Health"], false, false)
    }

    weirdTuba() {
        this.slotWeirdTuba = this.goThruInv(["Weird Tuba", "Weirder Tuba"], false, true)
        return this.goThruInv(["Weird Tuba", "Weirder Tuba"], false, false)
    }

    overflux() {
        this.slotOverflux = this.goThruInv(["Orb"], false, true)
        return this.goThruInv(["Orb"], false, false)
    }

    rod() {
        this.slotRod = this.goThruInv(["Rod"], false, true)
        return this.goThruInv(["Rod"], false, false)
    }

    katana() {
        this.slotKatana = this.goThruInv(["Katana"], false, true)
        return this.goThruInv(["Katana"], false, false)
    }

    findAll() {
        if(this.etherwarp() && this.range() && this.drill() && this.pickaxe()) {
            return true
        } else {
            return false
        }
    }

    goThruInv(textArray, lore, slot) {
        for(let f = 0; f < textArray.length; f++) {
            let plyInv = Player.getInventory()
            for(let i = 0; i < 8; i++) {
                if(i === this.slotBlueCheese) continue
                let stack = plyInv.getStackInSlot(i)
                if(stack != null) {

                    if(lore) {
                        let itemLore = stack.getLore()
                        for(let l = 0; l < itemLore.length; l++) {
                            if(itemLore[l].includes(textArray[f])) {
                                if(!slot) {
                                    return true
                                } else {
                                    return i
                                }
                            }
                        }
                    }

                    if(!lore) {
                        let local = i
                        let itemName = stack.getName()

                        if(!this.slotBlueCheese) {
                            this.slotBlueCheese = undefined
                        }

                        if(itemName.includes(textArray[f]) && local != this.slotBlueCheese) {
                            if(!slot) {
                                return true
                            } else {
                                return i
                            }
                        }
                    }

                }
            }
    }
        return false
    }
}

global.exports.finder = new itemFinder()