let { serverUtils, rotationUtils } = global.exports

class itemUtils {
    constructor() {
        this.clickMouse = Client.getMinecraft().getClass().getDeclaredMethod("func_147116_af")
        this.clickMouse.setAccessible(true)
        this.rightClickMouse = Client.getMinecraft().getClass().getDeclaredMethod("func_147121_ag")
        this.rightClickMouse.setAccessible(true)
        this.mc = Client.getMinecraft()
    }
    rightClick(delay) {
        Client.scheduleTask(delay, () => {
            this.rightClickMouse.invoke(Client.getMinecraft())
        })
    }

    leftClick(delay) {
        Client.scheduleTask(delay, () => {
            this.clickMouse.invoke(Client.getMinecraft())
        })
    }

    useItem(slot) {
        serverUtils.sendPacket(new serverUtils.C09PacketHeldItemChange(slot))
        serverUtils.sendPacket(new serverUtils.C08PacketPlayerBlockPlacement(new serverUtils.BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(slot).getItemStack(), 0, 0, 0))
        serverUtils.sendPacket(new serverUtils.C09PacketHeldItemChange(Player.getHeldItemIndex()))
    }

    onRotationEndRightClick() {
        new Thread(() => {
            let start = Date.now()
            while(!rotationUtils.end.isDone && Date.now() - start < 2000) {
                Thread.sleep(10)
            }
            ChatLib.chat("CLICKED")
            this.rightClick(2)
        }).start()
    }

    onRotationEndLeftClick() {
        new Thread(() => {

        }).start()
    } 
}

global.exports.itemUtils = new itemUtils()