let ArrayLists = Java.type("java.util.ArrayList");

global.exports.fillJavaArray = (array) => {
    let javaArray = new ArrayLists
    for(let i = 0; i < array.length; i++) {
        javaArray.add(array[i])
    }
    return javaArray
}