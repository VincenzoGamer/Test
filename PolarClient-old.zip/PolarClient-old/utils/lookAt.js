let { finder } = global.exports
let { polarPrefix, sendPacket, C09PacketHeldItemChange, BP, setPitch, setYaw } = global.exports

let mc = Client.getMinecraft()
let Shift = new KeyBind(mc.field_71474_y.field_74311_E);
let rightClick = mc.getClass().getDeclaredMethod("func_147121_ag")
rightClick.setAccessible(true)
let LClick = mc.getClass().getDeclaredMethod("func_147116_af")
LClick.setAccessible(true)

//for Poligon :sob: gn
global.exports.lookAt = (x, y, z, ms, aotv, crouch) => {
    new Thread(() => {
        try {
            let eyes = Player.getPlayer().func_174824_e(1)
            let diffX = x - eyes.field_72450_a
            let diffZ = z - eyes.field_72449_c
            let diffY
            if(crouch) {
                diffY = y - (Player.getY() + 1.53999996185303)
            } else {
                diffY = y - (Player.getY() + 1.62000000476837)
            }

            let dist = Math.sqrt(diffX * diffX + diffZ * diffZ)
            let pitch = -Math.atan2(dist, diffY)
            let yaw = Math.atan2(diffZ, diffX)
            pitch = ((pitch * 180.0) / Math.PI + 90.0) * - 1.0 - Player.getPlayer().field_70125_A
            
            pitch %= 180
            while (pitch >= 180)
              pitch -= 180
            while (pitch < -180)
              pitch += 180 

            yaw = (yaw * 180.0) / Math.PI - 90.0 - Player.getPlayer().field_70177_z

            //if(/*(diffZ > 0.0 && diffX < 0.0) ||*/ (diffZ < 0.0 && diffX < 0.0)) yaw += 180
            
            yaw %= 360.0
            while (yaw >= 180.0)
              yaw -= 360.0
            while (yaw <= -180.0)
              yaw += 360.0

            let finishedLook = false
            for(i = 0; i < ms; i++) {
                if(looking) {
                    let newPitch = Player.getPlayer().field_70125_A + (pitch / ms)
                    if(newPitch < 90.0 && newPitch > -90.0 && !finishedLook) {Player.getPlayer().field_70125_A += pitch / ms}
                    else finishedLook = true
                    Player.getPlayer().field_70177_z += yaw / ms
                    Thread.sleep(1)
                } else {
                    break
                }
            }
            
            if(aotv && looking) {
                if(crouch != false) {
                    Shift.setState(true)
                }
                Thread.sleep(100)
                if(looking) {
                    Thread.sleep(100)
                    try {
                    rightClick.invoke(mc)
                    } catch(e) {
                        ChatLib.chat(e)
                        ChatLib.chat(polarPrefix + " Error")
                    }
                }
                Thread.sleep(100)
                if(crouch != false) {
                    Shift.setState(false)
                }
            }
        } catch (e) {
            ChatLib.chat(e)
        } 
    }).start()
}

global.exports.lookAtRightClick = (x, y, z, ms, click) => {
    new Thread(() => {
        try {
            let eyes = Player.getPlayer().func_174824_e(1)
            let diffX = x - eyes.field_72450_a
            let diffZ = z - eyes.field_72449_c
            let diffY = y - eyes.field_72448_b

            let dist = Math.sqrt(diffX * diffX + diffZ * diffZ)
            let pitch = -Math.atan2(dist, diffY)
            let yaw = Math.atan2(diffZ, diffX)
            pitch = ((pitch * 180.0) / Math.PI + 90.0) * - 1.0 - Player.getPlayer().field_70125_A

            // pitch %= 360.0
            // while (pitch >= 180.0)
            //   pitch -= 360.0
            // while (pitch < -180.0)
            //   pitch += 360.0
            pitch %= 180
            while (pitch >= 180)
              pitch -= 180
            while (pitch < -180)
              pitch += 180 

            yaw = (yaw * 180.0) / Math.PI - 90.0 - Player.getPlayer().field_70177_z

            //if((diffZ > 0.0 && diffX < 0.0) || (diffZ < 0.0 && diffX < 0.0)) yaw += 180
            
            yaw %= 360.0
            while (yaw >= 180.0)
              yaw -= 360.0
            while (yaw < -180.0)
              yaw += 360.0

            let finishedLook = false
            for(i = 0; i < ms; i++) {
                if(looking) {
                    let newPitch = Player.getPlayer().field_70125_A + (pitch / ms)
                    if(newPitch < 90.0 && newPitch > -90.0 && !finishedLook) {Player.getPlayer().field_70125_A += pitch / ms}
                    else finishedLook = true
                    Player.getPlayer().field_70177_z += yaw / ms
                    Thread.sleep(1)
                } else break
            }
            if(click) {
                rightClick.invoke(mc)
            }
        } catch (e) {
            ChatLib.chat(e)
        } 
    }).start()
}

global.exports.lookAt2 = (x, y, z, ms, aotv, crouch) => {
    global.exports.cancelLook()
    new Thread(() => {
        try {
            let eyes = Player.getPlayer().func_174824_e(1)
            let diffX = x - eyes.field_72450_a
            let diffZ = z - eyes.field_72449_c
            let diffY
            if(crouch) {
                diffY = y - (Player.getY() + 1.53999996185303)
            } else {
                diffY = y - (Player.getY() + 1.62000000476837)
            }

            let dist = Math.sqrt(diffX * diffX + diffZ * diffZ)
            let pitch = -Math.atan2(dist, diffY)
            let yaw = Math.atan2(diffZ, diffX)
            pitch = ((pitch * 180.0) / Math.PI + 90.0) * - 1.0 - Player.getPlayer().field_70125_A

            pitch %= 360
            while (pitch >= 360)
              pitch -= 360
            while (pitch <= -360)
              pitch += 360 

            yaw = (yaw * 180.0) / Math.PI - 90.0 - Player.getPlayer().field_70177_z

            //if((diffZ > 0.0 && diffX > 0.0) || (diffZ < 0.0 && diffX > 0.0)) yaw += 180
            
            yaw %= 360.0
            while (yaw >= 180.0)
              yaw -= 360.0
            while (yaw <= -180.0)
              yaw += 360.0

              let finishedLook = false
            for(i = 0; i < ms; i++) {
                let newPitch = Player.getPlayer().field_70125_A + (pitch / ms)
                if(newPitch < 90.0 && newPitch > -90.0 && !finishedLook) {Player.getPlayer().field_70125_A += pitch / ms}
                else finishedLook = true
                Player.getPlayer().field_70177_z += yaw / ms
                Thread.sleep(1)
            }
            
            if(aotv) {
                if(!crouch) {
                    Thread.sleep(100)
                    rightClick.invoke(mc)
                    //sendPacket(new net.minecraft.network.play.client.C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(Player.getHeldItemIndex()).getItemStack(), 0, 0, 0))
                } else {
                    Shift.setState(true)
                    Thread.sleep(100)
                    sendPacket(new net.minecraft.network.play.client.C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(Player.getHeldItemIndex()).getItemStack(), 0, 0, 0))
                    Thread.sleep(100)
                    Shift.setState(false)
                }
            }
            global.exports.startLook()
            } catch (e) {
                ChatLib.chat(e)
            } 
    }).start()
}

global.exports.lookAt2Packet = (x, y, z, ms, aotv, crouch) => {
    global.exports.cancelLook()
    new Thread(() => {
        try {
            let eyes = Player.getPlayer().func_174824_e(1)
            let diffX = x - eyes.field_72450_a
            let diffZ = z - eyes.field_72449_c
            let diffY
            if(crouch) {
                diffY = y - (Player.getY() + 1.53999996185303)
            } else {
                diffY = y - (Player.getY() + 1.62000000476837)
            }

            let dist = Math.sqrt(diffX * diffX + diffZ * diffZ)
            let pitch = -Math.atan2(dist, diffY)
            let yaw = Math.atan2(diffZ, diffX)
            pitch = ((pitch * 180.0) / Math.PI + 90.0) * - 1.0 - Player.getPlayer().field_70125_A

            pitch %= 180
            while (pitch >= 180)
              pitch -= 180
            while (pitch < -180)
              pitch += 180 

            yaw = (yaw * 180.0) / Math.PI - 90.0 - Player.getPlayer().field_70177_z

            
            yaw %= 360.0
            while (yaw >= 180.0)
              yaw -= 360.0
            while (yaw < -180.0)
              yaw += 360.0

            let finishedLook = false
            for(i = 0; i < ms; i++) {
                let newPitch = Player.getPlayer().field_70125_A + (pitch / ms)
                if(newPitch < 90.0 && newPitch > -90.0 && !finishedLook) {Player.getPlayer().field_70125_A += pitch / ms}
                else finishedLook = true
                Player.getPlayer().field_70177_z += yaw / ms
                Thread.sleep(1)
            }

            if(aotv) {
                if(!crouch) {
                    Thread.sleep(100)
                    //rightClick.invoke(mc)
                    sendPacket(new net.minecraft.network.play.client.C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(Player.getHeldItemIndex()).getItemStack(), 0, 0, 0))
                } else {
                    Shift.setState(true)
                    Thread.sleep(100)
                    sendPacket(new net.minecraft.network.play.client.C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(Player.getHeldItemIndex()).getItemStack(), 0, 0, 0))
                    Thread.sleep(100)
                    Shift.setState(false)
                }
            }
            global.exports.startLook()
        } catch (e) {
            ChatLib.chat(e)
        } 
    }).start()
}


global.exports.killAuraLook = (x, y, z) => {

    let plyYaw = Player.getYaw()
    let plyPitch = Player.getPitch()
    let hoekYaw2
    let hoekPitch2
    let AngleYaw2
    if(x === undefined || y === undefined || z === undefined) {
        ChatLib.chat(polarPrefix + " put in cords nigga")
    } else {
    let PlayerAngleYaw = Player.getPlayer().field_70177_z
    PlayerAngleYaw %= 360
    let dX = Player.getX() - x + 0.000001
    let dZ = Player.getZ() - z + 0.000001
    let dY = (Player.getY() + 1.62) - y
    let dis = Math.sqrt((dX * dX) + (dZ * dZ))
    if(dX < 0.0 && dZ < 0.0) {
        AngleYaw2 = radians_to_degrees(Math.atan(dZ/dX)) + 180
    } else if(dZ < 0.0 && dX > 0.0) {
        AngleYaw2 = radians_to_degrees(Math.atan(dZ/dX)) + 360
    } else if(dZ > 0.0 && dX < 0.0) {
        AngleYaw2 = radians_to_degrees(Math.atan(dZ/dX)) + 180
    } else if(dZ > 0.0 && dX > 0.0){
        AngleYaw2 = radians_to_degrees(Math.atan(dZ/dX))
    }
    hoekYaw2 = AngleYaw2 - PlayerAngleYaw + 90
    if(hoekYaw2 > 180) {
        hoekYaw2 -= 360
    } if(hoekYaw2 < -180) {
        hoekYaw2 += 360
    }
    hoekPitch2 = radians_to_degrees(Math.atan(dY/dis)) - Player.getPlayer().field_70125_A
    new Thread(() => {
            Player.getPlayer()?.field_70177_z += hoekYaw2
            Player.getPlayer()?.field_70125_A += hoekPitch2
            Thread.sleep(1)
            try {
                LClick.invoke(mc)
            } catch(e) {}
            setPitch(plyPitch)
            setYaw(plyYaw)
    }).start()
}
}

global.exports.lookAtHori = (x, y, z, ms) => {
        let eyes = Player.getPlayer().func_174824_e(1)
        let diffX = x - eyes.field_72450_a
        let diffZ = z - eyes.field_72449_c
        let diffY = y - eyes.field_72448_b

        let dist = Math.sqrt(diffX * diffX + diffZ * diffZ)
        let pitch = -Math.atan2(dist, diffY)
        let yaw = Math.atan2(diffZ, diffX)
        pitch = ((pitch * 180.0) / Math.PI + 90.0) * - 1.0 - Player.getPlayer().field_70125_A

        pitch %= 180
        while (pitch >= 180)
          pitch -= 180
        while (pitch < -180)
          pitch += 180 

        yaw = (yaw * 180.0) / Math.PI - 90.0 - Player.getPlayer().field_70177_z

        yaw %= 360.0
        while (yaw >= 180.0)
          yaw -= 360.0
        while (yaw < -180.0)
          yaw += 360.0


        let newYaw = (Player.getPlayer().field_70177_z + yaw + 0.0001)
        new Thread(() => {
            for(i = 0; i < ms; i++) {
                if(looking) {          
                    setPitch(-1)
                    Player.getPlayer().field_70177_z += yaw / ms
                    Thread.sleep(1)
                } else break
            }
        }).start()
        //ChatLib.chat("newyaw: " + newYaw)
        return newYaw
    }

global.exports.lookAtHoriSet = (x, y, z, ms, pitch1) => {
    new Thread(() => {
        //try {
            let eyes = Player.getPlayer().func_174824_e(1)
            let diffX = x - eyes.field_72450_a
            let diffZ = z - eyes.field_72449_c
            let diffY = y - eyes.field_72448_b

            let dist = Math.sqrt(diffX * diffX + diffZ * diffZ)
            let pitch = -Math.atan2(dist, diffY)
            let yaw = Math.atan2(diffZ, diffX)
            pitch = ((pitch * 180.0) / Math.PI + 90.0) * - 1.0 - Player.getPlayer().field_70125_A
            pitch %= 180
            while (pitch >= 180)
              pitch -= 180
            while (pitch < -180)
              pitch += 180 

            yaw = (yaw * 180.0) / Math.PI - 90.0 - Player.getPlayer().field_70177_z

            
            yaw %= 360.0
            while (yaw >= 180.0)
              yaw -= 360.0
            while (yaw < -180.0)
              yaw += 360.0

            for(i = 0; i < ms; i++) {
                if(looking) {
                    setPitch(pitch1)
                    Player.getPlayer().field_70177_z += yaw / ms
                    Thread.sleep(1)
                } else break
            }
        // } catch (e) {
        //     ChatLib.chat(e)
        // } 
    }).start()
}

let looking = true
global.exports.cancelLook = () => {
    looking = false
}

global.exports.startLook = () => {
    looking = true
}

global.exports.returnLook = () => {
    return looking
}

function radians_to_degrees(radians) {
    var pi = Math.PI;
    return radians * (180/pi);
}