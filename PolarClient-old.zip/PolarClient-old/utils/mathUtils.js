class mathUtils {
    diffNumber(num1, num2) {
        if (num1 > num2) {
          return num1 - num2
        } else {
          return num2 - num1
        }
    }

    disToPly(x,y,z) {
        let dX = Player.getX() - x
        let dZ = Player.getZ() - z
        let dY = Player.getY() + 1.6 - y
        let dis = Math.sqrt((dX * dX) + (dZ * dZ))
        let dis2 = Math.sqrt((dis * dis) + (dY * dY))
        return dis2
    }
    
    disToPlyFlat(x,z) {
        let dX = Player.getX() - x
        let dZ = Player.getZ() - z
        let dis = Math.sqrt((dX * dX) + (dZ * dZ))
        return dis
    }

    disFrToFr(x,y,z,x1,y1,z1) {
        let dX = x1 - x
        let dZ = z1 - z
        let dY = y1 - y
        let dis = Math.sqrt((dX * dX) + (dZ * dZ))
        let dis2 = Math.sqrt((dis * dis) + (dY * dY))
        return dis2
    }
    
    disFrToFrFlat(x,z,x1,z1) {
        let dX = x1 - x
        let dZ = z1 - z
        let dis = Math.sqrt((dX * dX) + (dZ * dZ))
        return dis
    }
    
    disToPlayerCT(entity) {
        let dX = Player.getX() - entity.getX()
        let dZ = Player.getZ() - entity.getZ()
        let dY = Player.getY() + 1.6 - entity.getY()
        let dis = Math.sqrt((dX * dX) + (dZ * dZ))
        let dis2 = Math.sqrt((dis * dis) + (dY * dY))
        return dis2
    }

    disToPlayerMC(entity) {
        let dX = Player.getX() - entity.field_70165_t
        let dZ = Player.getZ() - entity.field_70161_v
        let dY = Player.getY() + 1.6 - entity.field_70163_u
        let dis = Math.sqrt((dX * dX) + (dZ * dZ))
        let dis2 = Math.sqrt((dis * dis) + (dY * dY))
        return dis2
    }
}

global.exports.mathUtils = new mathUtils()