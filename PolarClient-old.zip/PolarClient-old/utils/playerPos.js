global.exports.playerPos = {
    playerX:Math.floor(Player.getX()),
    playerY:Math.floor(Player.getY()),
    playerZ:Math.floor(Player.getZ())
}