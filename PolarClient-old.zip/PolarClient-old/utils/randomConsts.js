import request from "requestV2/index";

let { disToPly } = global.exports

global.exports.polarPrefix = "&0[&cPolar Client&0]&r ";
global.exports.mc = Client.getMinecraft();

let configjson
try {
    configjson = FileLib.read("PolarConfig", "config.json");
    global.exports.config = JSON.parse(configjson);
    for(let i = 0; i < global.exports.config.length; i++) {
        global.exports.config[i].getKeyCode();
    }
} catch(e) {
    ChatLib.chat(global.exports.polarPrefix + " Your config was corrupted, fixed it!")
    global.exports.MakeNewKeys()
}

global.exports.MakeNewKeys = () => {
    //General
    global.exports.config.keyFairySoulAura = 0

    //Fishing
    global.exports.config.keyFishingMacro = 0
   
    //Foraging
    global.exports.config.keyHubForagingMacro = 0
   
    //Combat
    global.exports.config.keyKillAura = 0
    global.exports.config.keyGhostMacro = 0
    global.exports.config.keyQolSwap = 0
    global.exports.config.keyHelmetSwapper = 0
    global.exports.config.keyArmorSwapper = 0
   
    //Mining
    global.exports.config.keyMiningMacro = 0
    global.exports.config.keyCommMacro = 0
    global.exports.config.keyBindMithrilMacro = 0
    global.exports.config.keyHardStoneNuker = 0
    global.exports.config.keyGemstoneMacro = 0
    global.exports.config.keyRouteNuker = 0
    global.exports.config.keyLobbySwapper = 0
    global.exports.config.keyAutoCompactSacks = 0
    global.exports.config.keySandMiner = 0
    global.exports.config.keyPowderMacro = 0
    global.exports.config.keyArmadilloMacro = 0
    global.exports.config.keyXRay = 0
   
    //Dungeons
    global.exports.config.keyHBlock = 0
    global.exports.config.keyVBlock = 0
    global.exports.config.keyGhostBlock = 0
    global.exports.config.keySecretAura = 0

    //Farming
    global.exports.config.keyFarmingMacro = 0

    FileLib.write("PolarConfig", "config.json", JSON.stringify(global.exports.config));
}

var cordsjson = FileLib.read("PolarConfig", "cords.json");
global.exports.cords = JSON.parse(cordsjson)

var togglejson = FileLib.read("PolarConfig", "publicDataSaver.json");
global.exports.toggle = JSON.parse(togglejson);

global.exports.LClick = global.exports.mc.getClass().getDeclaredMethod("func_147116_af")
global.exports.RClick = global.exports.mc.getClass().getDeclaredMethod("func_147121_ag")
global.exports.LClick.setAccessible(true)
global.exports.RClick.setAccessible(true)

global.exports.WalkRight = new KeyBind(global.exports.mc.field_71474_y.field_74366_z);
global.exports.WalkLeft = new KeyBind(global.exports.mc.field_71474_y.field_74370_x);
global.exports.WalkBackward = new KeyBind(global.exports.mc.field_71474_y.field_74368_y);
global.exports.WalkForward = new KeyBind(global.exports.mc.field_71474_y.field_74351_w);
global.exports.Sprint = new KeyBind(global.exports.mc.field_71474_y.field_151444_V);
global.exports.Shift = new KeyBind(global.exports.mc.field_71474_y.field_74311_E);
global.exports.WalkJump = new KeyBind(global.exports.mc.field_71474_y.field_74314_A);
global.exports.LeftClick = new KeyBind(global.exports.mc.field_71474_y.field_74312_F);
global.exports.Attack = new KeyBind(global.exports.mc.field_71474_y.field_74312_F);

global.exports.BP = Java.type("net.minecraft.util.BlockPos");
global.exports.C09PacketHeldItemChange = Java.type("net.minecraft.network.play.client.C09PacketHeldItemChange");
global.exports.C0BPacketEntityAction = Java.type("net.minecraft.network.play.client.C0BPacketEntityAction")
global.exports.EnumFacing = Java.type("net.minecraft.util.EnumFacing");
global.exports.C07PacketPlayerDigging = Java.type("net.minecraft.network.play.client.C07PacketPlayerDigging");
global.exports.C0APacketAnimation = Java.type("net.minecraft.network.play.client.C0APacketAnimation");
global.exports.ArrayLists = Java.type("java.util.ArrayList");

global.exports.sendPacket = (packet) => {
    global.exports.mc.field_71439_g.field_71174_a.func_147297_a(packet)
}

global.exports.writeCords = () => {
    let json = JSON.stringify(global.exports.cords, null, 2);
    FileLib.write("PolarConfig", "cords.json", json);
}

global.exports.inCrystal = () => {
    let list = TabList.getNames()
    let found = false
    for(let g = 0; g < list.length; g++) {
        if(list[g].includes("Crystal Hollows")) {
            found = true
            break
        }
    }
    if(found) {
        return true
    } else {
        return false
    }
}

global.exports.diffNumber = (num1, num2) => {
    if (num1 > num2) {
      return num1 - num2
    } else {
      return num2 - num1
    }
  }

global.exports.getClosest = (input,type,index) => {
    if(type === "entity") {
        let indexNum = 0
        let closest = undefined
        for(let i = 0; i < input.length; i++) { 
            let closest = undefined
            if(closest === undefined) {
                closest = input[i]
                indexNum = i
            }
            else if(global.exports.disToPly(input[i].getX(), input[i].getY(), input[i].getZ()) < global.exports.disToPly(closest.getX(), closest.getY(), closest.getZ())) {
                closest = input[i]
                indexNum = i
            }
        }
        if(index) return indexNum
        return closest
    }
    if(type === "array") {
        let indexNum = 0
        let closest = undefined
        for(let i = 0; i < input.length; i++) {
            if(closest === undefined) {
                closest = input[i]
                indexNum = i
            }
            else if(global.exports.disToPly(input[i][0], input[i][1], input[i][2]) < global.exports.disToPly(closest[0], closest[1], closest[2])) {
                closest = input[i]
                indexNum = i
            }
        }
        if(index) return indexNum
        return closest
    }
    if(type === "entitymc") {
        let indexNum = 0
        let closest = undefined
        for(let i = 0; i < input.length; i++) {
            if(closest === undefined) {
                closest = input[i]
                indexNum = i
            }
            else if(global.exports.disToPly(input[i].field_70165_t, input[i].field_70163_u, input[i].field_70161_v) < global.exports.disToPly(closest.field_70165_t, closest.field_70163_u, closest.field_70161_v)) {
                closest = input[i]
                indexNum = i
            }
        }
        if(index) return indexNum
        return closest
    }
    if(type === "blockct") {
        let indexNum = 0
        let closest = undefined
        for(let i = 0; i < input.length; i++) {
            if(closest === undefined) {
                closest = input[i]
                indexNum = i
            }
            else if(global.exports.disToPly(input[i].getX() + 0.5, input[i].getY() + 0.5, input[i].getZ() + 0.5) < global.exports.disToPly(closest.getX() + 0.5, closest.getY() + 0.5, closest.getZ() + 0.5)) {
                closest = input[i]
                indexNum = i
            }
        }
        if(index) return indexNum
        return closest
    }
}
global.exports.ctEntityPlayer = () => {
    let players = World.getAllPlayers()
    let playerName = Player.getName()
    for(let i = 0; i < players.length; i++) {
        if(players[i].getName() === playerName) return players[i]
    }
    return null
}

let fagots = ["floatingsand","aurorafenn","implodent","pie5","zgrillbz","creepstick","umtofly","itsfrag"]
global.exports.fagotSpotted = () => {
    let list = TabList.getNames()
    let found = false
    for(let g = 0; g < list.length; g++) {
        //ChatLib.chat(list[g])
        for(let i = 0; i < fagots.length; i++) {
            if(list[g].toLowerCase().includes(fagots[i])) {
                found = true
                ChatLib.chat("fagot: " + fagots[i])
                break
            }
        }
    }
    if(found) {
        return true
    } else {
        return false
    }
}

global.exports.cancelWalk = (exception) => {
    if(exception != "backward") {global.exports.WalkBackward.setState(false)}
    if(exception != "forward") {global.exports.WalkForward.setState(false)}
    if(exception != "left") {global.exports.WalkLeft.setState(false)}
    if(exception != "right") {global.exports.WalkRight.setState(false)}

    if(exception === "backward") {global.exports.WalkBackward.setState(true)}
    if(exception === "forward") {global.exports.WalkForward.setState(true)}
    if(exception === "left") {global.exports.WalkLeft.setState(true)}
    if(exception === "right") {global.exports.WalkRight.setState(true)}
}

global.exports.myBP = class myBp {
    constructor(x,y,z) {
        this.posX = x
        this.posY = y
        this.posZ = z
    }
}

global.exports.writeSave = () => {
    let json = JSON.stringify(global.exports.toggle, null, 2);
    FileLib.write("PolarConfig", "publicDataSaver.json", json);
}

global.exports.setting = (catacory, name) => {
    try {
        return settings.getSetting(catacory,name)
    } catch(e) {
        return null
    }
}

global.exports.commissions = ["Rampart's Quarry Titanium","Rampart's Quarry Mithril","Royal Mines Mithril","Royal Mines Titanium","Cliffside Veins Mithril","Cliffside Veins Titanium","Titanium Miner","Mithril Miner","Lava Springs Titanium","Lava Springs Mithril","Upper Mines Titanium","Upper Mines Mithril","Goblin Slayer","Ice Walker Slayer"]

global.exports.setYaw = (Yaw) => {
    global.exports.mc.func_71410_x().field_71439_g.field_70177_z=Yaw
}
    
global.exports.setPitch = (Pitch) => {
    global.exports.mc.func_71410_x().field_71439_g.field_70125_A=Pitch
}

let islandNames = ["Hub","Crystal Hollows","Dwarven Mines"]
global.exports.currentIsland = () => {
        try {
            let list = TabList.getNames()
            for(let g = 0; g < list.length; g++) {
                for(let i = 0; i < islandNames.length; i++) {
                    if(list[g].includes(islandNames[i])) {
                        return islandNames[i]
                    }
                }
            }
            return false
        } catch(e) {
            return false
        }
}

let balls = 2
global.exports.firstEnable = (input) => {
    if(input != undefined) {
        balls = input
    }
    return balls
}

jsonWebhook = FileLib.read("PolarConfig", "webhook.json");
global.exports.configWebhook = JSON.parse(jsonWebhook);

global.exports.writeWebhook = () => {
    let tempJson = JSON.stringify(global.exports.configWebhook);
    FileLib.write("PolarConfig", "webhook.json", tempJson);
}

global.exports.sendMessage = (urlYes,message) => {
    request({
        url: urlYes,
        method: "POST",
        headers: {
            'Content-type': 'application/json',
            "User-Agent":"Mozilla/5.0",
        },
        body: {
          content: message,
        }
    }).catch(error => {
        ChatLib.chat("Webhook Error! \nMake sure you have your webhook set right!")
    })
}

// Origional is from illegal map, Ily https://github.com/UnclaimedBloom6/IllegalMap
global.exports.dungeonFloor = (floor) => {
    let scoreboard = Scoreboard.getLines().map(a => { return ChatLib.removeFormatting(a) })
    for (let line of scoreboard) {
        let match = line.match(/ ⏣ The Catac.+ombs \((.+)\)/)
        if (match) {
            return parseInt(match[1].replace(/[^\d]/g, ""))
        }
    }
    return floor
}

global.exports.RClickItem = (slot) => {
    if(slot === undefined) {
        try {
            global.exports.RClick.invoke(global.exports.mc)
        } catch (error) {
            global.exports.sendPacket(new net.minecraft.network.play.client.C08PacketPlayerBlockPlacement(new global.exports.BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(Player.getHeldItemIndex()).getItemStack(), 0, 0, 0))
        }
    }
    else {
        let current = Player.getHeldItemIndex()
        global.exports.sendPacket(new C09PacketHeldItemChange(slot))
        global.exports.sendPacket(new net.minecraft.network.play.client.C08PacketPlayerBlockPlacement(new global.exports.BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(slot).getItemStack(), 0, 0, 0))
        global.exports.sendPacket(new C09PacketHeldItemChange(current))
    }
}

global.exports.LClickItem = () => {
    Client.scheduleTask(0, () => {
        global.exports.LClick.invoke(global.exports.mc)
    })
} 

global.exports.movePlayer = (player, rangeToMove) => {
    let x = player.getX();
    let y = player.getY() + 1.62;
    let z = player.getZ();

    let yawDegrees = player.getYaw();
    let pitchDegrees = player.getPitch();

    let yaw = yawDegrees * (Math.PI / 180);
    let pitch = pitchDegrees * (Math.PI / 180);

    let newX = x + rangeToMove * Math.cos(pitch) * Math.sin(yaw);
    let newY = y - rangeToMove * Math.sin(pitch);
    let newZ = z + rangeToMove * Math.cos(pitch) * Math.cos(yaw);

    return { newX, newY, newZ };
}

global.exports.itemMacro = (name) => {
    for (let i = 0; i < 9; i++) {
        if(ChatLib.removeFormatting(Player.getInventory().getStackInSlot(i)?.getName()).includes(name)) {
            let current = Player.getHeldItemIndex()
            global.exports.sendPacket(new global.exports.C09PacketHeldItemChange(i))
            global.exports.sendPacket(new net.minecraft.network.play.client.C08PacketPlayerBlockPlacement(new global.exports.BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(i).getItemStack(), 0, 0, 0))
            global.exports.sendPacket(new global.exports.C09PacketHeldItemChange(current))
            return true
        }
    }
    ChatLib.chat(global.exports.polarPrefix + " Didn't find: " + name)
    return false
}