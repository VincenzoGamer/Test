let sides = [[0.5, 0.01, 0.5 ], [0.5, 0.99, 0.5], [0.01, 0.5, 0.5], [0.99, 0.5, 0.5], [0.5, 0.5, 0.01], [0.5, 0.5, 0.99]]
global.exports.getPointsOnBlock = (bp) => {
    let returnArray = []
    sides.forEach(side => {
            x = side[0]
            y = side[1]
            z = side[2]
            returnArray.push(new net.minecraft.util.Vec3(bp).func_72441_c(x, y, z))
    })  
    return returnArray
}

global.exports.rayTrace = (pos) => {
    global.exports.getPointsOnBlock(pos).forEach(point => {
        let rayTraceResult = World.getWorld().func_72933_a(Player.getPlayer().func_174824_e(1), point)
        if(rayTraceResult && rayTraceResult.func_178782_a().equals(pos)) {
            return true
        }
    })
    return false
}