import RenderLib from "RenderLib";
import Async from "Async"
import { raytraceBlocks } from "Bloomcore/utils/Utils.js"
import Vector3 from "Bloomcore/utils/Vector3.js"
let { Shift, mc, polarPrefix, fillJavaArray, radians_to_degrees, diffNumber, lookAt2, BP, startLook, cancelLook, lookAt, rotationUtils, itemUtils } = global.exports

let rightClick = mc.getClass().getDeclaredMethod("func_147121_ag")
rightClick.setAccessible(true)
let sidesFromFork = [[0.01, 0.5, 0.5,"WEST"], [0.99, 0.5, 0.5,"EAST"], [0.5, 0.5, 0.01,"NORTH"], [0.5, 0.5, 0.99,"SOUTH"], [0.5, 0.01, 0.5,"BOTTEM"], [0.5, 0.99, 0.5,"TOP"]]   

function floatToInt(floatNumber) {
    return Math.ceil(floatNumber + 0.5)
}

global.exports.intToFloat = (intNumber) => {
    return parseFloat(intNumber.toFixed(2))
}

class vector {
    constructor(x,y,z) {
        this.x = x
        this.y = y
        this.z = z
    }
}

let test = undefined
let test2 = fillJavaArray([])

global.exports.returnPointOnBlock = (x=0,y=0,z=0,crouch,ofsetX,ofsetZ) => {
        let plyX = global.exports.intToFloat(Player.getX()) + ofsetX
        let plyY = Player.getY() + 1.62
        let plyZ = global.exports.intToFloat(Player.getZ()) + ofsetZ
        if(crouch) plyY -= 0.08
        plyY = global.exports.intToFloat(plyY)
        let returnArray = []
        returnArray.push(new vector(x + 0.5, y + 0.5, z + 0.5))
        for(let f = 0; f < sidesFromFork.length; f++) {
            if((plyY > y && f === 0) || (World.getBlockAt(x,y-1,z).type.getID() != 0 && f === 0)) continue
            if((plyY < y + 1 && f === 1) || (World.getBlockAt(x,y+1,z).type.getID() != 0 && f === 1)) continue
            if((plyX > x + 1 && f === 2) || (World.getBlockAt(x-1,y,z).type.getID() != 0 && f === 2)) continue
            if((plyX < x && f === 3) || (World.getBlockAt(x+1,y,z).type.getID() != 0 && f === 3)) continue
            if((plyZ > z + 1 && f === 4) || (World.getBlockAt(x,y,z-1).type.getID() != 0 && f === 4)) continue
            if((plyZ < z && f === 5) || (World.getBlockAt(x,y,z+1).type.getID() != 0 && f === 5)) continue
            for (i = 0; i <= 8; i++) {
                let x1 = sidesFromFork[f][0]
                let y1 = sidesFromFork[f][1]
                let z1 = sidesFromFork[f][2]
                if(y1 != 0.5) {
                    x1 = ((0.8) * i/8) + 0.10
                    for(let z2 = 0; z2 <= 8; z2++) {
                        returnArray.push(new vector(x + x1, y + y1, z + z1 + ((0.1 * z2) + 0.10)))
                    }
                }
                if(x1 != 0.5) {
                    z1 = ((0.8) * i/8) + 0.10
                    for(let y2 = 0; y2 <= 8; y2++) {
                        returnArray.push(new vector(x + x1, y + y1 + ((0.1 * y2) + 0.10), z + z1))
                    }
                }
                if(z1 != 0.5) {
                    y1 = ((0.8) * i/8) + 0.10
                    for(let x2 = 0; x2 <= 8; x2++) {
                        returnArray.push(new vector(x + x1 + ((0.1 * x2) + 0.10), y + y1, z + z1))
                    }
                }
            } 
        }
        return returnArray
}

function makeThePoint(x,y,z,crouch) {
    let returnArray = global.exports.returnPointOnBlock(x,y,z,crouch,0.00,0.00)
    const plyX = global.exports.intToFloat(Player.getX())
    let plyY = Player.getY() + 1.62
    const plyZ = global.exports.intToFloat(Player.getZ())
    if(crouch) plyY -= 0.08
    plyY = global.exports.intToFloat(plyY)
    
    for(let f = 0; f < returnArray.length; f++) {
        let point = returnArray[f]
        let tempArray = []
        const dX = global.exports.intToFloat(point.x - plyX)
        const dY = global.exports.intToFloat(point.y - plyY)
        const dZ = global.exports.intToFloat(point.z - plyZ)
        tempArray = raytraceBlocks([plyX,plyY,plyZ],new Vector3(dX,dY,dZ),60,blockCheckFunc,true)
        if(tempArray === null) continue
        try {
            if(tempArray[0] === x && tempArray[1] === y && tempArray[2] === z) {
                test2 = tempArray
                test = point
                break
            }
        } catch(e) {}
    }
}

function blockCheckFunc(block) {
    if(World.getBlockAt(block.getX(), block.getY(), block.getZ()).type.getID() != 0.0) {
        return true
    }
    return false
}

global.exports.checkAdjacentBlock = (x1, y1, z1, x2, y2, z2) => {
    if(World.getBlockAt(x1,y1,z1).type.getID() != 0.0) return false
    const offsets = [
      [1, 0, 0], 
      [-1, 0, 0],
      [0, 1, 0], 
      [0, -1, 0],
      [0, 0, 1], 
      [0, 0, -1] 
    ];
    for(let i = 0; i < offsets.length; i++) {
        let offset = offsets[i]
        let adjacentX = x1 + offset[0];
        let adjacentY = y1 + offset[1];
        let adjacentZ = z1 + offset[2];
      if (adjacentX === x2 && adjacentY === y2 && adjacentZ === z2) {
        return true;
      }
    }
    return false;
}

let shifted = false
global.exports.lookAtRayCast = (x,y,z,ms,click,crouchValue) => {
    shifted = false
    cancelLook()
    let pointArray = null
    test = null
    
    makeThePoint(x,y,z,crouchValue)
    if(test === null) {
        return true
    } else {
        pointArray = test
    }

    let x1 = pointArray.x
    let y1 = pointArray.y
    let z1 = pointArray.z

    //let time = new Date().getTime()
    if(crouchValue && click) {
        shifted = true
        Shift.setState(true)
    }

    rotationUtils.onStopRotation()
    rotationUtils.doPolarRotation({x: x1, y: y1, z: z1}, ms, crouchValue)

    while(crouchValue && click && !rotationUtils.end.isDone) {
        Thread.sleep(10)
    }
    if(click) {
        Thread.sleep(201)
        itemUtils.rightClick(0)
    }
    if(crouchValue && click) {
        let start = new Date().getTime()
        while(new Date().getTime() - start < 1000 && shifted) {
            Thread.sleep(1)
        }
        Shift.setState(false)
    }
    startLook()
    return false
}

register("packetReceived", (packet, event) => {
    if(shifted) shifted = false
}).setFilteredClasses([net.minecraft.network.play.server.S08PacketPlayerPosLook])