global.exports.degreeRannge = (x,y,z) => {
  let eyes = Player.getPlayer().func_174824_e(1)
  let diffX = x - eyes.field_72450_a
  let diffZ = z - eyes.field_72449_c
  let diffY = y - eyes.field_72448_b
  
  let dist = Math.sqrt(diffX * diffX + diffZ * diffZ)
  let pitch = -Math.atan2(dist, diffY)
  let yaw = Math.atan2(diffZ, diffX)
  pitch = ((pitch * 180.0) / Math.PI + 90.0) * - 1.0 - Player.getPlayer().field_70125_A
  
  pitch %= 180
  while (pitch >= 180)
    pitch -= 180
  while (pitch < -180)
    pitch += 180 
  
  yaw = (yaw * 180.0) / Math.PI - 90.0 - Player.getPlayer().field_70177_z

  yaw %= 360.0
  while (yaw >= 180.0)
    yaw -= 360.0
  while (yaw < -180.0)
    yaw += 360.0

  return Math.sqrt(yaw * yaw)
}

global.exports.distanceRotation = (x,y,z,crouch=false) => {
  let eyes = Player.getPlayer().func_174824_e(1)
  let diffX = x - Player.getX()//eyes.field_72450_a
  let diffZ = z - Player.getZ()//eyes.field_72449_c
  let diffY = y - Player.getY() + 1.62001//eyes.field_72448_b

  if(crouch) diffY - 0.080001
  
  let dist = Math.sqrt(diffX * diffX + diffZ * diffZ)
  let pitch = -Math.atan2(dist, diffY)
  let yaw = Math.atan2(diffZ, diffX)
  pitch = ((pitch * 180.0) / Math.PI + 90.0) * - 1.0 - Player.getPlayer().field_70125_A
  
  pitch %= 180
  while (pitch >= 180)
    pitch -= 180
  while (pitch < -180)
    pitch += 180 
  
  yaw = (yaw * 180.0) / Math.PI - 90.0 - Player.getPlayer().field_70177_z

  yaw %= 360.0
  while (yaw >= 180.0)
    yaw -= 360.0
  while (yaw < -180.0)
    yaw += 360.0

  return Math.sqrt(yaw * yaw + pitch * pitch)
}



global.exports.rotaPitchRange = (x,y,z) => {
    let eyes = Player.getPlayer().func_174824_e(1)
    let diffX = x - eyes.field_72450_a
    let diffZ = z - eyes.field_72449_c
    let diffY = y - eyes.field_72448_b

    let dist = Math.sqrt(diffX * diffX + diffZ * diffZ)
    let pitch = -Math.atan2(dist, diffY)
    let yaw = Math.atan2(diffZ, diffX)
    pitch = ((pitch * 180.0) / Math.PI + 90.0) * - 1.0 - Player.getPlayer().field_70125_A

    pitch %= 180
    while (pitch >= 180)
      pitch -= 180
    while (pitch < -180)
      pitch += 180 

    yaw = (yaw * 180.0) / Math.PI - 90.0 - Player.getPlayer().field_70177_z

    
    yaw %= 360.0
    while (yaw >= 180.0)
      yaw -= 360.0
    while (yaw < -180.0)
      yaw += 360.0

    return Math.sqrt(pitch * pitch)
}

global.exports.degreeRanngeRaw = (x,y,z) => {
    let eyes = Player.getPlayer().func_174824_e(1)
    let diffX = x - eyes.field_72450_a
    let diffZ = z - eyes.field_72449_c
    let diffY = y - eyes.field_72448_b

    let dist = Math.sqrt(diffX * diffX + diffZ * diffZ)
    let pitch = -Math.atan2(dist, diffY)
    let yaw = Math.atan2(diffZ, diffX)
    pitch = ((pitch * 180.0) / Math.PI + 90.0) * - 1.0 - Player.getPlayer().field_70125_A

    pitch %= 180
    while (pitch >= 180)
      pitch -= 180
    while (pitch < -180)
      pitch += 180 

    yaw = (yaw * 180.0) / Math.PI - 90.0 - Player.getPlayer().field_70177_z

    
    yaw %= 360.0
    while (yaw >= 180.0)
      yaw -= 360.0
    while (yaw < -180.0)
      yaw += 360.0

    return yaw
}

global.exports.degreeRanngeOri = (x,y,z) => {
    let eyes = Player.getPlayer().func_174824_e(1)
    let diffX = x - eyes.field_72450_a
    let diffZ = z - eyes.field_72449_c
    let diffY = y - eyes.field_72448_b

    let dist = Math.sqrt(diffX * diffX + diffZ * diffZ)
    let pitch = -Math.atan2(dist, diffY)
    let yaw = Math.atan2(diffZ, diffX)
    pitch = ((pitch * 180.0) / Math.PI + 90.0) * - 1.0 - Player.getPlayer().field_70125_A

    pitch %= 180
    while (pitch >= 180)
      pitch -= 180
    while (pitch < -180)
      pitch += 180 

    yaw = (yaw * 180.0) / Math.PI - 90.0 - Player.getPlayer().field_70177_z

    
    yaw %= 360.0
    while (yaw >= 180.0)
      yaw -= 360.0
    while (yaw < -180.0)
      yaw += 360.0

    return Math.sqrt(yaw * yaw)
}

global.exports.rotaPitchRangeRaw = (x,y,z) => {
    let hoekPitch2
    let dX = Player.getX() - x + 0.00001
    let dZ = Player.getZ() - z + 0.00001
    let dY = Player.getY() - y + 1.6
    let dis = Math.sqrt((dX * dX) + (dZ * dZ))
    hoekPitch2 = global.exports.radians_to_degrees(Math.atan(dY/dis)) - Player.getPlayer().field_70125_A
    return hoekPitch2
}

global.exports.radians_to_degrees = (radians) => {
    var pi = Math.PI;
    return radians * (180/pi);
}