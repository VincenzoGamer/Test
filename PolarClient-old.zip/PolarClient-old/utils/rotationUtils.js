/*
    I hate messy code :sob:
*/

class rotationUtils {
    constructor() {
        this.rotationId = 0.0

        this.end = {
            yaw: 0.0,
            pitch: 0.0,
            isDone: false
        }
    }

    setPitch(pitch, ms=0, inThread=true) {
        if(ms > 0) {
            let change = this.calculatePitch(pitch)
            if(inThread) {
                new Thread(() => {
                    this.doPitchRotation(change, pitch, ms)
                }).start()
                return
            }

            this.doPitchRotation(change, pitch, ms)
        }
        Client.getMinecraft().func_71410_x().field_71439_g.field_70125_A = pitch
    }

    setYaw(yaw, ms=0, inThread=true) {
        if(ms > 0) {
            let change = this.calculateYaw(yaw)
            if(inThread) {
                new Thread(() => {
                    this.doYawRotation(change, yaw, ms)
                }).start()
                return
            }

            this.doYawRotation(change, yaw, ms)
        }
        Client.getMinecraft().func_71410_x().field_71439_g.field_70177_z = yaw
    }

    rotateTo(location, lookspeed, crouch=false, inThread=true,delay=0) {
        if(inThread) {
                if(delay != 0) {
                    Client.scheduleTask((delay), () => {
                        new Thread(() => {
                            this.doRotation(location, lookspeed, crouch)
                        }).start()
                    })
                    return
                }
                new Thread(() => {
                    this.doRotation(location, lookspeed, crouch)
                }).start()
            return
        }

        if(delay != 0) {
            Client.scheduleTask((delay), () => {
                this.doRotation(location, lookspeed, crouch)
            })
            return
        }
        this.doRotation(location, lookspeed, crouch)
    }

    polarRotateTo(location, ms, inThread=true, crouch=false, special={changePitch: true, extraYaw: 0.0}) {
        if(inThread) {
            new Thread(() => {
                this.doPolarRotation(location, ms, crouch, special)
            }).start()
            return
        }
        this.doPolarRotation(location, ms, crouch)
        return
    }

    rotateFlatTo(location, ms, inThread=true) {
        if(inThread) {
            new Thread(() => {
                this.doFlatRotation(location, ms)
            }).start()
            return
        }

        this.doFlatRotation(location, ms)
    }

    doYawRotation(yawChange, end, ms) {
        this.end.isDone = false
        let rotationId = this.rotationId
        for(let i = 0; i <= ms; i++) {
            if(rotationId != this.rotationId) return
            Thread.sleep(1)
            Client.getMinecraft().func_71410_x().field_71439_g.field_70177_z -= yawChange/ms
        }
        Client.getMinecraft().func_71410_x().field_71439_g.field_70177_z = end
        this.end.isDone = true
    }

    doPitchRotation(pitchChange, end, ms) {
        this.end.isDone = false
        let rotationId = this.rotationId
        for(let i = 0; i <= ms; i++) {
            if(rotationId != this.rotationId) return
            Thread.sleep(1)
            Client.getMinecraft().func_71410_x().field_71439_g.field_70125_A -= pitchChange/ms
        }
        Client.getMinecraft().func_71410_x().field_71439_g.field_70125_A = end
        this.end.isDone = true
    }

    doRotation(location, ms, crouch=false) {
        let rotationId = this.rotationId
        let angles = this.calculateAngles(location, crouch)
        let yaw = angles.yaw
        let pitch = angles.pitch
        let finishedLook = false
        for(i = 0; i <= ms; i++) {
            if(rotationId != this.rotationId) return
            let newPitch = Player.getPlayer().field_70125_A + (pitch/ms)
            if(newPitch < 90.0 && newPitch > -90.0 && !finishedLook) Player.getPlayer().field_70125_A += (pitch/ms)
            else finishedLook = true
            Player.getPlayer().field_70177_z += (yaw/ms)
            Thread.sleep(1)
        }
    }

    doPolarRotation(location, ms, crouch=false, special={changePitch: true, extraYaw: 0.0}) {
        this.end.isDone = false
        let angles = this.calculateAngles(location, crouch)
        let start = {
            yaw: Player.getPlayer().field_70177_z,
            pitch: Player.getPlayer().field_70125_A
        }
        let end = {
            yaw: Player.getPlayer().field_70177_z + angles.yaw + special.extraYaw,
            pitch: Player.getPlayer().field_70125_A + angles.pitch
        }
        let startTime = new Date().getTime()
        let endTime = new Date().getTime() + ms
        let rotationid = this.rotationId

        this.end = {
            yaw: end.yaw,
            pitch: end.pitch
        }
        new Thread(() => {
            while(!this.update(start, end, startTime, endTime, special)) {
                if(rotationid != this.rotationId) return
                Thread.sleep(1)
            }
            this.end.isDone = true
        }).start()
    }

    doFlatRotation(location, ms) {
        let rotationId = this.rotationId
        let angles = this.calculateAngles(location, false)
        let yaw = angles.yaw
        for(i = 0; i <= ms; i++) {
            if(rotationId != this.rotationId) return
            Player.getPlayer().field_70177_z += (yaw/ms)
            Thread.sleep(1)
        }
    }

    getRotationLength(location, crouch=false) {
        let angles = this.calculateAngles(location, crouch)
        let yaw = angles.yaw
        let pitch = angles.pitch
        return Math.sqrt((pitch * pitch) + (yaw * yaw))
    }

    update(start, end, startTime, endTime, special={changePitch: true, extraYaw: 0.0}) {
        if(new Date().getTime() <= endTime) {
            Player.getPlayer().field_70177_z = this.interpolate(start.yaw, end.yaw, startTime, endTime)
            if(special.changePitch) Player.getPlayer().field_70125_A = this.interpolate(start.pitch, end.pitch, startTime, endTime)
            return false
        }
        Player.getPlayer().field_70177_z = end.yaw
        if(special.changePitch) Player.getPlayer().field_70125_A = end.pitch
        return true
    }

    interpolate(start, end, startTime, endTime) {
        let pastTime = new Date().getTime() - startTime
        let relativeProgress = pastTime/(endTime-startTime)
        return (end-start) * this.easeOutCubic(relativeProgress) + start
    }

    easeOutCubic(number) {
        return Math.max(0.0, Math.min(1.0, 1 - Math.pow(1.0 - number, 3.0)))
    }

    calculateYaw(yaw) {
        let change = Player.getYaw() - yaw
        if(change > 180) change -= 360
        if(change < -180) change += 360
        return change
    }

    calculatePitch(pitch) {
        let change = Player.getPitch() - pitch
        return change
    }

    calculateAngles(location, crouch) {
        let diffX = location.x - Player.getX()
        let diffZ = location.z - Player.getZ()
        let plyY = Player.getY() + 1.62
        if(crouch) plyY - 0.08
        let diffY = location.y - plyY
        let dist = Math.sqrt(diffX * diffX + diffZ * diffZ)
        let pitch_ = -Math.atan2(dist, diffY)
        let yaw_ = Math.atan2(diffZ, diffX)
        pitch_ = ((pitch_ * 180.0) / Math.PI + 90.0) * - 1.0 - Player.getPlayer().field_70125_A
        pitch_ %= 180
        while (pitch_ >= 180)
          pitch_ -= 180
        while (pitch_ < -180)
          pitch_ += 180 
        yaw_ = (yaw_ * 180.0) / Math.PI - 90.0 - Player.getPlayer().field_70177_z
        yaw_ %= 360.0
        while (yaw_ >= 180.0)
          yaw_ -= 360.0
        while (yaw_ <= -180.0)
          yaw_ += 360.0
        return {yaw: yaw_, pitch: pitch_}
    }

    onStopRotation() {
        this.rotationId += 1
    }
}

global.exports.rotationUtils = new rotationUtils()