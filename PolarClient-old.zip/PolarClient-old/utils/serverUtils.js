class serverUtils {
    constructor() {
        this.BP = Java.type("net.minecraft.util.BlockPos");
        this.C09PacketHeldItemChange = Java.type("net.minecraft.network.play.client.C09PacketHeldItemChange");
        this.C0BPacketEntityAction = Java.type("net.minecraft.network.play.client.C0BPacketEntityAction")
        this.EnumFacing = Java.type("net.minecraft.util.EnumFacing");
        this.C07PacketPlayerDigging = Java.type("net.minecraft.network.play.client.C07PacketPlayerDigging");
        this.C0APacketAnimation = Java.type("net.minecraft.network.play.client.C0APacketAnimation");
        this.C08PacketPlayerBlockPlacement = Java.type("net.minecraft.network.play.client.C08PacketPlayerBlockPlacement")
    }
    sendPacket(packet) {
        Client.getMinecraft().field_71439_g.field_71174_a.func_147297_a(packet)
    }
}

global.exports.serverUtils = new serverUtils()