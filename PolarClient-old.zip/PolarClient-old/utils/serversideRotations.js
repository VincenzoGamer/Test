class serversideRotation {
    constructor() {
        this.toggle = false
        this.yaw = 0.0
        this.pitch = 0.0
        this.prevYaw = 0.0
        this.prevPitch = 0.0

        register("renderEntity", (entity) => {
            if(entity.getEntity() === Player.getPlayer() && this.toggle) {
                Player.getPlayer().field_70761_aq = this.yaw
                Player.getPlayer().field_70759_as = this.yaw
            }
        })
    }

    reset() {
        this.toggle = false
    }

    setAngles(yaw,pitch) {
        this.toggle = true
        this.yaw = yaw
        this.pitch = pitch
    }
}

global.exports.serversideRotations = new serversideRotation()