let { firstEnable, setting, toggle } = global.exports;

let speedMithril = 0
let speedGemstone = 0
global.exports.speedCalc = (type ,name, metadata, speedBoost, firstCheck, precisionMiner, ofset) => {
    let miningOfset

    if(toggle.commisionMacro) {
        if(speedBoost) {
            miningOfset = parseInt(global.exports.settingGet.getSetting("Commision Macro","Additional mining ticks").toString())
        } else {
            miningOfset = parseInt(global.exports.settingGet.getSetting("Commision Macro","Additional mining ticks").toString())
        }
    }
    else if(toggle.gemStoneMacro) {
        if(speedBoost) {
            miningOfset = parseInt(global.exports.settingGet.getSetting("Gemstone Macro","Additional mining ticks").toString())
        } else {
            miningOfset = parseInt(global.exports.settingGet.getSetting("Gemstone Macro","Additional mining ticks").toString())
        }
    } else {
        if(speedBoost) {
            miningOfset = parseInt(global.exports.settingGet.getSetting("Mining Extra's","Extra amount of ticks while Mining (With SpeedBoost)").toString())
        } else {
            miningOfset = parseInt(global.exports.settingGet.getSetting("Mining Extra's","Extra amount of ticks while Mining (Without SpeedBoost)").toString())
        }
    }

    if(ofset != undefined) {
        miningOfset += ofset
    }

    let miningSpeed
    if(type === "gem") {
        miningSpeed = speedGemstone
        let itemNameCurrent = Player.getHeldItem().getName()
        if(itemNameCurrent.removeFormatting().includes("Drill") && !speedBoost) {
            miningOfset -= 1
        }
    }
    if(type === "mithril") {
        miningSpeed = speedMithril
    }

    if(precisionMiner) {
        miningSpeed = Math.floor(miningSpeed * 1.3)
    }

    if(speedBoost) {
        let set = global.exports.settingGet.getSetting("Mining Extra's","I have Peak Of The Mountain 5")
        if(set) {
            miningSpeed = (miningSpeed * 4)
        } else {
            miningSpeed = (miningSpeed * 3)
        }
    }
    if(!firstCheck) {
        if(name === "Prismarine") {
            let greenMithrilS = (Math.ceil((800*30)/miningSpeed) + miningOfset)
            if(miningSpeed > 5334) {return (4 + miningOfset)} else {return greenMithrilS}
        }
        if(name === "Wool") {
            let crayMithrilS = (Math.ceil((500*30)/miningSpeed) + miningOfset)
            let blueMithrilS = (Math.ceil((1500*30)/miningSpeed) + miningOfset)
            if(metadata === 7 && miningSpeed > 3334) {return (4 + miningOfset)} else if(metadata === 7){return crayMithrilS}
            if(metadata === 3 && miningSpeed > 10001) {return (4 + miningOfset + 1)} else if(metadata === 3){return blueMithrilS} 

        }
        if(name === "Stained Clay") {
            let crayMithrilS = (Math.ceil((500*30)/miningSpeed) + miningOfset)
            if(metadata === 9 && miningSpeed > 3334) {return (4 + miningOfset)} else if(metadata === 9) {return crayMithrilS}
        }
        if(name === "Stone") {
            let titaniumS = (Math.ceil((2000*30)/miningSpeed) + miningOfset)
            if(metadata === 4 && miningSpeed > 13334) {return (4 + miningOfset + 1)} else if(metadata === 4){return titaniumS}
        }
        /*
            if(name === "Stained Glass") {
                let easyBigS = (Math.ceil((3200*30)/miningSpeed) + miningOfset)
                let topazBigS = (Math.ceil((4000*30)/miningSpeed) + miningOfset)
                let rubyBigS = (Math.ceil((2500*30)/miningSpeed) + miningOfset)
                let jasperBigs = (Math.ceil((5000*30)/miningSpeed) + miningOfset)
                if((metadata === 1 || metadata === 10 || metadata === 5 || metadata === 3) === true && miningSpeed > 21334) {return (4 + miningOfset)} else if((metadata === 1 || metadata === 10 || metadata === 5 || metadata === 3) === true) {return easyBigS}
                if(metadata === 4 && miningSpeed > 26667) {return (4 + miningOfset)} else if(metadata === 4) {return topazBigS}
                if(metadata === 14 && miningSpeed > 16667) {return (4 + miningOfset)} else if(metadata === 14) {return rubyBigS}
                if(metadata === 2 && miningSpeed > 33334) {return (4 + miningOfset)} else if(metadata === 2) {return jasperBigs}
            }
        */
        if(name === "Stained Glass Pane" || name === "Stained Glass") {
            let easySmallS = (Math.ceil((3000*30)/miningSpeed) + miningOfset)
            let topazSmallS = (Math.ceil((3800*30)/miningSpeed) + miningOfset)
            let rubySmallS = (Math.ceil((2300*30)/miningSpeed) + miningOfset)
            let jasperSmalls = (Math.ceil((4800*30)/miningSpeed) + miningOfset)
            if((metadata === 1 || metadata === 10 || metadata === 5 || metadata === 3) === true && miningSpeed > 20001) {return  (4 + miningOfset)} else if((metadata === 1 || metadata === 10 || metadata === 5 || metadata === 3) === true) {return easySmallS}
            if(metadata === 4 && miningSpeed > 25334) {return (4 + miningOfset)} else if(metadata === 4) {return topazSmallS}
            if(metadata === 14 && miningSpeed > 15334) {return (4 + miningOfset)} else if(metadata === 14) {return rubySmallS}
            if(metadata === 2 && miningSpeed > 32001) {return (4 + miningOfset)} else if(metadata === 2) {return jasperSmalls}
        }
    } else if(firstCheck) {
        if(miningSpeed1 > 0) {
            return true
        } else {
            return false
        }
    }
    else {
        ChatLib.chat("Error!")
    }
}

global.exports.setSpeeds = (Mithril, Gemstone) => {
    //ChatLib.chat("here")
    speedMithril = Mithril
    speedGemstone = Gemstone
}