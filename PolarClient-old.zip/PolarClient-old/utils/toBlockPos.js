let BP = Java.type("net.minecraft.util.BlockPos");

global.exports.toBlockPos = (block) => {
    let pos = new BP(block.getX(), block.getY(), block.getZ())
    return pos
}

global.exports.toPosBlock = (pos) => {
    let block = World.getBlockAt(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p())
    return block
}