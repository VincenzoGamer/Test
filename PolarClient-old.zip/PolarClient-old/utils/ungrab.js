let Mouse = Java.type("org.lwjgl.input.Mouse")

class MouseGrab {
    constructor() {
        this.isUngrabbed = false
        this.doesGameWantUngrabbed
        this.originalFocusPauseSetting
    }

    ungrabMouse() {
        if (!Mouse.isGrabbed() || Client.isInGui()) return
        let m = Client.getMinecraft().func_71410_x()
        this.originalFocusPauseSetting = m.field_71474_y.field_82881_y
        m.field_71474_y.field_82881_y = false
        this.doesGameWantUngrabbed = Mouse.isGrabbed()
        m.field_71417_B.func_74373_b()
        m.field_71415_G = false
        this.isUngrabbed = true
    }

    regrabMouse() {
        if (Mouse.isGrabbed() || Client.isInGui()) return
        let m = Client.getMinecraft().func_71410_x()
        m.field_71474_y.field_82881_y = this.originalFocusPauseSetting
        if (!this.doesGameWantUngrabbed) {
            m.field_71417_B.func_74372_a()
            this.doesGameWantUngrabbed = true
        }
        this.isUngrabbed = false
    }
}

global.exports.ungrab =  new MouseGrab()